-- phpMyAdmin SQL Dump
-- version 3.5.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 01, 2014 at 09:39 PM
-- Server version: 5.5.33-31.1
-- PHP Version: 5.3.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `tuanbt_qlcuahang_haiau`
--

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_category`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_category` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `picture` binary(255) DEFAULT NULL,
  `enable` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

--
-- Dumping data for table `taphoahaiau_category`
--

INSERT INTO `taphoahaiau_category` (`id`, `name`, `picture`, `enable`) VALUES
(28, 'Đường', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(29, 'Mì gói', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(30, 'Kem đánh răng', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(31, 'Bàn chải đánh răng', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(32, 'Thiết bị điện', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(33, 'Gia vị khác', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1),
(34, 'Dầu ăn', '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_collect_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_collect_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_customer_collect_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_collect_general`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_collect_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_collect_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_config`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `param` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `taphoahaiau_config`
--

INSERT INTO `taphoahaiau_config` (`id`, `param`, `value`) VALUES
(5, 'DISCOUNT', '0'),
(6, 'ROW_PER_PAGE', '12'),
(7, 'GUEST_VISIT', '9247'),
(8, 'EVERY_5_MINUTES', '2000'),
(9, 'THEME', 'grey'),
(10, 'NAME', 'TẠP HÓA HẢI ÂU'),
(11, 'ADDRESS', 'Phú Quới Long Hồ Vĩnh Long'),
(12, 'PHONE', '0919 153 189'),
(13, 'CATEGORY_AUTO', '3'),
(14, 'SWITCH_BOARD_CALL', '1'),
(15, 'RECEIPT_VIRTUAL_DOUBLE', '0'),
(16, 'N_MONTH_LOG', '1');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_course`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcategory` int(25) DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `price1` bigint(20) NOT NULL,
  `price2` bigint(20) NOT NULL,
  `price3` bigint(20) NOT NULL,
  `price4` bigint(20) NOT NULL,
  `picture` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_discount` int(11) NOT NULL DEFAULT '1',
  `enable` int(11) NOT NULL,
  `prepare` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `foreign_field` (`idcategory`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=435 ;

--
-- Dumping data for table `taphoahaiau_course`
--

INSERT INTO `taphoahaiau_course` (`id`, `idcategory`, `name`, `shortname`, `unit`, `price1`, `price2`, `price3`, `price4`, `picture`, `is_discount`, `enable`, `prepare`) VALUES
(399, 31, 'Bàn chải đánh răng Colgate', 'Bàn chải đánh răng Colgate', 'Cây', 9000, 9000, 9000, 9000, '', 0, 1, 0),
(400, 31, 'Bàn chải đánh răng P/S', 'Bàn chải đánh răng P/S', 'Cây', 8000, 8000, 8000, 8000, '', 0, 1, 1),
(401, 31, 'Bàn chải đánh răng thường', 'Bàn chải đánh răng thường', 'Cây', 3000, 3000, 3000, 3000, '', 0, 1, 0),
(402, 28, 'đường cát trắng nhiển', 'đường cát trắng nhiển', 'Kg', 16000, 16000, 16000, 16000, '', 0, 1, 0),
(403, 28, 'Đường cát trắng to', 'Đường cát trắng to', 'Kg', 15500, 15500, 15500, 15500, '', 0, 1, 0),
(404, 28, 'đường cát vàng', 'đường cát vàng', 'Kg', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(405, 28, 'đường mía', 'đường mía', 'Kg', 15000, 15000, 15000, 15000, '', 0, 1, 0),
(406, 28, 'đường cát ( nguyên cây )', 'đường cát ( nguyên cây )', 'Cây', 150000, 150000, 150000, 150000, '', 0, 1, 1),
(407, 30, 'Kem đánh răng PS', 'Kem đánh răng PS', 'Cây', 18000, 18000, 18000, 18000, '', 0, 1, 0),
(408, 30, 'Kem đánh răng Colgate', 'Kem đánh răng Colgate', 'Cây', 19000, 19000, 19000, 19000, '', 0, 1, 0),
(409, 29, 'Mì kokomi', 'Mì kokomi', 'Gói', 3000, 3000, 3000, 3000, '', 0, 1, 0),
(410, 29, 'Mì colasa', 'Mì colasa', 'Gói', 2500, 2500, 2500, 2500, '', 0, 1, 1),
(411, 29, 'Mì Gấu đỏ', 'Mì Gấu đỏ', 'Gói', 3000, 3000, 3000, 3000, '', 0, 1, 0),
(412, 29, 'Mì hảo hảo', 'Mì hảo hảo', 'Gói', 3500, 3500, 3500, 3500, '', 0, 1, 0),
(413, 32, 'Máy quạt', 'Máy quạt', 'Cái', 150000, 150000, 150000, 150000, '', 0, 1, 1),
(414, 32, 'Nồi cơm điện 1lit', 'Máy quạt', 'Cái', 200000, 200000, 200000, 200000, '', 0, 1, 0),
(415, 32, 'Bình thủy điện', 'Bình thủy điện', 'Cái', 140000, 140000, 140000, 140000, '', 0, 1, 0),
(416, 32, 'Bóng đèn dài 8 tất', 'Bóng đèn dài 8 tất', 'Cái', 30000, 30000, 30000, 30000, '', 0, 1, 1),
(417, 32, 'Bóng đèn 1m2', 'Bóng đèn 1m2', 'Cái', 40000, 40000, 40000, 40000, '', 0, 1, 1),
(418, 32, 'Bóng đèn chữ U loai 3U', 'Bóng đèn chữ U loai 3U', 'Cái', 45000, 45000, 45000, 45000, '', 0, 1, 0),
(419, 32, 'Bóng đèn chữ U loai 5U', 'Bóng đèn chữ U loai 5U', 'Cái', 140000, 140000, 140000, 140000, '', 0, 1, 0),
(420, 29, 'Mì kokomi thùng', 'Mì kokomi thùng', 'Thùng', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(421, 29, 'Mì colosa thùng', 'Mì colosa thùng', 'Thùng', 50000, 50000, 50000, 50000, '', 0, 1, 0),
(422, 29, 'Mì gấu đỏ thùng', 'Mì gấu đỏ thùng', 'Thùng', 60000, 60000, 60000, 60000, '', 0, 1, 0),
(423, 29, 'Mì hảo hảo thùng', 'Mì hảo hảo thùng', 'Thùng', 70000, 70000, 70000, 70000, '', 0, 1, 0),
(424, 33, 'Bột ngọt vedan', 'Bột ngọt vedan', 'Bịch', 17000, 17000, 17000, 17000, '', 0, 1, 0),
(425, 33, 'Bột ngọt vedan bịt nhỏ', 'Bột ngọt vedan bịt nhỏ', 'Bịch', 5000, 5000, 5000, 5000, '', 0, 1, 0),
(426, 33, 'Hạt nêm Knorr', 'Hạt nêm Knorr', 'Bịch', 9000, 9000, 9000, 9000, '', 0, 1, 0),
(427, 33, 'Hạt nêm aji ngon', 'Hạt nêm aji ngon', 'Bịch', 8000, 8000, 8000, 8000, '', 0, 1, 1),
(428, 33, 'Muối iot', 'Muối iot', 'Bịch', 3000, 3000, 3000, 3000, '', 0, 1, 0),
(429, 33, 'Muối bọt', 'Muối bọt', 'Bịch', 2000, 2000, 2000, 2000, '', 0, 1, 1),
(430, 33, 'Nước tương Tam Thái Tử', 'Nước tương Tam Thái Tử', 'Chai', 7000, 7000, 7000, 7000, '', 0, 1, 0),
(431, 33, 'Nước mắm Đệ Nhị', 'Nước mắm Đệ Nhị', 'Chai', 16000, 16000, 16000, 16000, '', 0, 1, 0),
(432, 34, 'Dầu ăn cái lân 0,5 lít', 'Dầu ăn cái lân 0,5 lít', 'Chai', 17000, 17000, 17000, 17000, '', 0, 1, 0),
(433, 34, 'Dầu ăn cái lân 1 lít', 'Dầu ăn cái lân 1 lít', 'Chai', 32000, 32000, 32000, 32000, '', 0, 1, 0),
(434, 34, 'Dầu ăn simly 1 lít', 'Dầu ăn simly 1 lít', 'Chai', 35000, 35000, 35000, 35000, '', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_customer` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `card` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `discount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taphoahaiau_customer`
--

INSERT INTO `taphoahaiau_customer` (`id`, `name`, `type`, `card`, `phone`, `address`, `note`, `discount`) VALUES
(1, 'Khách lẻ', 0, '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_domain`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_domain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taphoahaiau_domain`
--

INSERT INTO `taphoahaiau_domain` (`id`, `name`) VALUES
(1, 'Thu ngân');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_employee`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `job` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `gender` tinyint(2) NOT NULL,
  `phone` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `salary_base` int(11) NOT NULL,
  `card` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `taphoahaiau_employee`
--

INSERT INTO `taphoahaiau_employee` (`id`, `name`, `job`, `gender`, `phone`, `address`, `salary_base`, `card`) VALUES
(2, 'Nhân viên', 'Bán hàng', 1, '', '', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_guest`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_guest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(16) CHARACTER SET latin1 NOT NULL,
  `entry_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `exit_time` varchar(32) CHARACTER SET latin1 NOT NULL,
  `agent` varchar(16) CHARACTER SET latin1 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=150 ;

--
-- Dumping data for table `taphoahaiau_guest`
--

INSERT INTO `taphoahaiau_guest` (`id`, `ip`, `entry_time`, `exit_time`, `agent`) VALUES
(149, '115.78.94.118', '1383319305', '1383322905', '115.78.94.118');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_order_import`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_order_import` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `description` varchar(50) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_order_import_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=364 ;

--
-- Dumping data for table `taphoahaiau_order_import`
--

INSERT INTO `taphoahaiau_order_import` (`id`, `idsupplier`, `date`, `description`) VALUES
(362, 14, '2014-03-01', ''),
(363, 14, '2014-03-03', '');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_order_import_detail`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_order_import_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idorder` int(11) NOT NULL,
  `idresource` int(11) NOT NULL,
  `count` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_order_import_detail_1` (`idorder`),
  KEY `taphoahaiau_order_import_detail_2` (`idresource`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=676 ;

--
-- Dumping data for table `taphoahaiau_order_import_detail`
--

INSERT INTO `taphoahaiau_order_import_detail` (`id`, `idorder`, `idresource`, `count`, `price`) VALUES
(657, 362, 112, 10, 50000),
(658, 362, 113, 10, 45000),
(659, 362, 114, 10, 50000),
(660, 362, 115, 10, 50000),
(661, 362, 116, 10, 130000),
(662, 362, 117, 10, 12000),
(663, 362, 118, 10, 25000),
(664, 362, 119, 10, 26000),
(665, 362, 120, 10, 5000),
(666, 362, 121, 10, 4000),
(667, 362, 122, 10, 1000),
(668, 362, 123, 10, 115000),
(669, 362, 124, 10, 150000),
(670, 362, 125, 10, 100000),
(671, 363, 120, 50, 5000),
(672, 363, 115, 5, 50000),
(673, 363, 114, 5, 50000),
(674, 363, 113, 5, 45000),
(675, 363, 112, 5, 50000);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idcustomer` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_customer_paid_1` (`idcustomer`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_employee`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_general`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_general` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_term` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_paid_1` (`id_term`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_pay_roll`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `value_base` int(11) NOT NULL,
  `value_sub` int(11) NOT NULL,
  `value_pre` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_paid_pay_roll_1` (`id_employee`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_paid_supplier`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_paid_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `date` date NOT NULL,
  `value` int(11) NOT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_supplier_paid_1` (`idsupplier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_pay_roll`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_pay_roll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_employee` int(11) NOT NULL,
  `date` date NOT NULL,
  `session1` int(11) NOT NULL,
  `session2` int(11) NOT NULL,
  `session3` int(11) NOT NULL,
  `extra` int(11) NOT NULL,
  `late` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id_employee` (`id_employee`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=193 ;

--
-- Dumping data for table `taphoahaiau_pay_roll`
--

INSERT INTO `taphoahaiau_pay_roll` (`id`, `id_employee`, `date`, `session1`, `session2`, `session3`, `extra`, `late`) VALUES
(162, 2, '2014-01-01', 0, 0, 0, 0, 0),
(163, 2, '2014-01-02', 0, 0, 0, 0, 0),
(164, 2, '2014-01-03', 0, 0, 0, 0, 0),
(165, 2, '2014-01-04', 0, 0, 0, 0, 0),
(166, 2, '2014-01-05', 0, 0, 0, 0, 0),
(167, 2, '2014-01-06', 0, 0, 0, 0, 0),
(168, 2, '2014-01-07', 0, 0, 0, 0, 0),
(169, 2, '2014-01-08', 0, 0, 1, 0, 0),
(170, 2, '2014-01-09', 0, 0, 1, 0, 0),
(171, 2, '2014-01-10', 0, 0, 0, 0, 0),
(172, 2, '2014-01-11', 0, 0, 0, 0, 0),
(173, 2, '2014-01-12', 0, 0, 0, 0, 0),
(174, 2, '2014-01-13', 0, 0, 0, 0, 0),
(175, 2, '2014-01-14', 0, 0, 0, 0, 0),
(176, 2, '2014-01-15', 0, 0, 0, 0, 0),
(177, 2, '2014-01-16', 0, 0, 0, 0, 0),
(178, 2, '2014-01-17', 0, 0, 0, 0, 0),
(179, 2, '2014-01-18', 0, 0, 0, 0, 0),
(180, 2, '2014-01-19', 0, 0, 0, 0, 0),
(181, 2, '2014-01-20', 0, 0, 0, 0, 0),
(182, 2, '2014-01-21', 0, 0, 0, 0, 0),
(183, 2, '2014-01-22', 0, 0, 0, 0, 0),
(184, 2, '2014-01-23', 0, 0, 0, 0, 0),
(185, 2, '2014-01-24', 0, 0, 0, 0, 0),
(186, 2, '2014-01-25', 0, 0, 0, 0, 0),
(187, 2, '2014-01-26', 0, 0, 0, 0, 0),
(188, 2, '2014-01-27', 0, 0, 0, 0, 0),
(189, 2, '2014-01-28', 0, 0, 0, 0, 0),
(190, 2, '2014-01-29', 0, 0, 0, 0, 0),
(191, 2, '2014-01-30', 0, 0, 0, 0, 0),
(192, 2, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_r2c`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_r2c` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_course` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `value1` double NOT NULL,
  `value2` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_r2c_1` (`id_course`),
  KEY `taphoahaiau_r2c_2` (`id_resource`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_resource`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_resource` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `idsupplier` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `unit` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `price` int(10) NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `taphoahaiau_resource_1` (`idsupplier`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=126 ;

--
-- Dumping data for table `taphoahaiau_resource`
--

INSERT INTO `taphoahaiau_resource` (`id`, `idsupplier`, `name`, `unit`, `price`, `description`) VALUES
(112, 14, 'Mì kokomi', 'Thùng', 50000, '24 gói'),
(113, 14, 'Mì colosa', 'Thùng', 45000, '24 gói'),
(114, 14, 'Mì gấu đỏ', 'Thùng', 50000, '24 gói'),
(115, 14, 'Mì hảo hảo', 'Thùng', 50000, '24 gói'),
(116, 14, 'Đường cát', 'Cây', 130000, '10kg'),
(117, 14, 'Dầu cái lân 0,5 lít', 'Cái', 12000, ''),
(118, 14, 'Dầu cái lân 1 lít', 'Chai', 25000, ''),
(119, 14, 'Dầu ăn simly', 'Chai', 26000, ''),
(120, 14, 'Bàn chải colgate', 'Cây', 5000, ''),
(121, 14, 'Bàn chải PS', 'Cây', 4000, ''),
(122, 14, 'Bàn chải thường', 'Cây', 1000, ''),
(123, 14, 'Máy quạt', 'Cái', 115000, ''),
(124, 14, 'Nồi cơm điện', 'Cái', 150000, ''),
(125, 14, 'Bình thủy điện', 'Cái', 100000, '');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_session`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idtable` int(11) NOT NULL,
  `iduser` int(11) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemployee` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `note` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `discount_percent` int(11) NOT NULL,
  `surtax` int(11) NOT NULL,
  `payment` int(11) NOT NULL,
  `value` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`),
  KEY `taphoahaiau_session_3` (`idcustomer`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1763 ;

--
-- Dumping data for table `taphoahaiau_session`
--

INSERT INTO `taphoahaiau_session` (`id`, `idtable`, `iduser`, `idcustomer`, `idemployee`, `datetime`, `datetimeend`, `note`, `status`, `discount_value`, `discount_percent`, `surtax`, `payment`, `value`) VALUES
(1758, 1, 4, 1, 2, '2014-03-01 14:00:03', '2014-03-01 14:00:03', '', 1, 0, 0, 0, 0, 0),
(1759, 1, 4, 1, 2, '2014-03-01 14:01:06', '2014-03-01 14:01:06', '', 1, 0, 0, 0, 0, 0),
(1760, 1, 4, 1, 2, '2014-03-01 14:12:07', '2014-03-01 14:12:07', '', 1, 0, 0, 0, 0, 0),
(1761, 4, 4, 1, 2, '2014-03-03 20:17:59', '2014-03-03 20:17:59', '', 1, 0, 0, 0, 0, 0),
(1762, 1, 4, 1, 2, '2014-03-03 20:18:38', '2014-03-03 20:18:38', '', 1, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_session_detail`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_session_detail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idsession` int(11) NOT NULL,
  `idcourse` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idsession` (`idsession`),
  KEY `idcourse` (`idcourse`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3635 ;

--
-- Dumping data for table `taphoahaiau_session_detail`
--

INSERT INTO `taphoahaiau_session_detail` (`id`, `idsession`, `idcourse`, `count`, `price`) VALUES
(3617, 1758, 432, 1, 17000),
(3618, 1758, 399, 1, 9000),
(3619, 1758, 424, 1, 17000),
(3620, 1758, 425, 1, 5000),
(3621, 1759, 415, 1, 140000),
(3622, 1759, 418, 2, 45000),
(3623, 1759, 421, 2, 50000),
(3624, 1759, 399, 1, 9000),
(3625, 1760, 424, 1, 17000),
(3626, 1760, 418, 3, 45000),
(3627, 1760, 404, 1, 15000),
(3628, 1760, 402, 1, 16000),
(3629, 1761, 421, 1, 50000),
(3630, 1761, 432, 3, 17000),
(3631, 1762, 427, 1, 8000),
(3632, 1762, 428, 1, 3000),
(3633, 1762, 422, 1, 60000),
(3634, 1762, 417, 1, 40000);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_store`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(125) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `taphoahaiau_store`
--

INSERT INTO `taphoahaiau_store` (`id`, `name`, `note`) VALUES
(1, 'Kho nhà', 'Ghi chú gì đây ?');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_supplier`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_supplier` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `note` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `debt` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

--
-- Dumping data for table `taphoahaiau_supplier`
--

INSERT INTO `taphoahaiau_supplier` (`id`, `name`, `phone`, `address`, `note`, `debt`) VALUES
(14, 'Nhà cung cấp A', '0706123456', 'P1- TPVL', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_table`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iddomain` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `iduser` int(11) DEFAULT NULL,
  `type` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `iddomain` (`iddomain`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `taphoahaiau_table`
--

INSERT INTO `taphoahaiau_table` (`id`, `iddomain`, `name`, `iduser`, `type`) VALUES
(1, 1, '01', 1, '0'),
(2, 1, '02', 1, '0'),
(3, 1, '03', 1, '0'),
(4, 1, '04', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_table_log`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_table_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idtable` int(11) NOT NULL,
  `datetime` datetime NOT NULL,
  `note` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idtable` (`idtable`),
  KEY `iduser` (`iduser`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6777 ;

--
-- Dumping data for table `taphoahaiau_table_log`
--

INSERT INTO `taphoahaiau_table_log` (`id`, `iduser`, `idtable`, `datetime`, `note`) VALUES
(6733, 4, 1, '2014-02-27 13:21:35', 'Tạo mới giao dịch'),
(6734, 4, 1, '2014-02-27 13:21:35', 'Cập nhật món Cafe  đá  1'),
(6735, 4, 1, '2014-02-27 13:21:37', 'Cập nhật món Cafe  đá  2'),
(6736, 4, 1, '2014-02-27 13:21:41', 'Cập nhật món Cafe  đá  3'),
(6737, 4, 1, '2014-02-27 13:23:40', 'Cập nhật món cafe sữa đá 1'),
(6738, 4, 1, '2014-02-27 13:23:41', 'Cập nhật món cafe sữa đá 2'),
(6739, 1, 1, '2014-02-27 13:23:58', 'tính tiền 48.000'),
(6740, 4, 1, '2014-02-27 13:25:31', 'Tạo mới giao dịch'),
(6741, 4, 1, '2014-02-27 13:25:31', 'Cập nhật món Khăn lạnh 1'),
(6742, 4, 1, '2014-02-27 13:25:32', 'Cập nhật món Khăn lạnh 2'),
(6743, 4, 1, '2014-02-27 13:25:33', 'Cập nhật món Khăn lạnh 3'),
(6744, 1, 1, '2014-02-27 13:26:24', 'tính tiền 8.000'),
(6745, 4, 1, '2014-03-01 14:00:03', 'Tạo mới giao dịch'),
(6746, 4, 1, '2014-03-01 14:00:03', 'Cập nhật món Dầu ăn cái lân 0,5 lít 1'),
(6747, 4, 1, '2014-03-01 14:00:06', 'Cập nhật món Bàn chải đánh răng Colgate 1'),
(6748, 4, 1, '2014-03-01 14:00:11', 'Cập nhật món Bột ngọt vedan 1'),
(6749, 4, 1, '2014-03-01 14:00:14', 'Cập nhật món Bột ngọt vedan bịt nhỏ 1'),
(6750, 1, 1, '2014-03-01 14:00:48', 'tính tiền 48.000'),
(6751, 4, 1, '2014-03-01 14:01:06', 'Tạo mới giao dịch'),
(6752, 4, 1, '2014-03-01 14:01:06', 'Cập nhật món Bình thủy điện 1'),
(6753, 4, 1, '2014-03-01 14:01:08', 'Cập nhật món Bóng đèn chữ U loai 3U 1'),
(6754, 4, 1, '2014-03-01 14:01:11', 'Cập nhật món Mì colosa thùng 1'),
(6755, 4, 1, '2014-03-01 14:10:56', 'Cập nhật món Bàn chải đánh răng Colgate 1'),
(6756, 4, 1, '2014-03-01 14:11:00', 'Cập nhật món Bóng đèn chữ U loai 3U 2'),
(6757, 4, 1, '2014-03-01 14:11:03', 'Cập nhật món Mì colosa thùng 2'),
(6758, 1, 1, '2014-03-01 14:11:31', 'tính tiền 339.000'),
(6759, 4, 1, '2014-03-01 14:12:07', 'Tạo mới giao dịch'),
(6760, 4, 1, '2014-03-01 14:12:07', 'Cập nhật món Bột ngọt vedan 1'),
(6761, 4, 1, '2014-03-01 14:12:34', 'Cập nhật món Bóng đèn chữ U loai 3U 1'),
(6762, 4, 1, '2014-03-02 22:26:16', 'Cập nhật món Bóng đèn chữ U loai 3U 2'),
(6763, 4, 1, '2014-03-02 22:26:17', 'Cập nhật món Bóng đèn chữ U loai 3U 3'),
(6764, 4, 1, '2014-03-02 22:26:26', 'Cập nhật món đường cát vàng 1'),
(6765, 4, 1, '2014-03-02 22:26:28', 'Cập nhật món đường cát trắng nhiển 1'),
(6766, 1, 1, '2014-03-02 22:26:29', 'tính tiền 183.000'),
(6767, 4, 4, '2014-03-03 20:17:59', 'Tạo mới giao dịch'),
(6768, 4, 4, '2014-03-03 20:17:59', 'Cập nhật món Mì colosa thùng 1'),
(6769, 4, 4, '2014-03-03 20:18:03', 'Cập nhật món Dầu ăn cái lân 0,5 lít 1'),
(6770, 4, 4, '2014-03-03 20:18:04', 'Cập nhật món Dầu ăn cái lân 0,5 lít 2'),
(6771, 4, 4, '2014-03-03 20:18:05', 'Cập nhật món Dầu ăn cái lân 0,5 lít 3'),
(6772, 1, 4, '2014-03-03 20:18:27', 'tính tiền 101.000'),
(6773, 4, 1, '2014-03-03 20:18:38', 'Tạo mới giao dịch'),
(6774, 4, 1, '2014-03-03 20:18:41', 'Cập nhật món Muối iot 1'),
(6775, 4, 1, '2014-03-03 20:18:45', 'Cập nhật món Mì gấu đỏ thùng 1'),
(6776, 1, 1, '2014-03-03 20:19:12', 'tính tiền 111.000');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_term`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Dumping data for table `taphoahaiau_term`
--

INSERT INTO `taphoahaiau_term` (`id`, `name`, `type`) VALUES
(1, 'Tiền Điện', 0),
(2, 'Tiền Nước', 0),
(3, 'Thuế', 0),
(10, 'Tiền Ăn Nhân Viên', 0),
(11, 'CP Khác', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_term_collect`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_term_collect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `taphoahaiau_term_collect`
--

INSERT INTO `taphoahaiau_term_collect` (`id`, `name`) VALUES
(2, 'Phụ Phẩm'),
(3, 'Đặc Biệt');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `paid_general` int(11) NOT NULL,
  `paid_pay_roll` int(11) NOT NULL,
  `paid_import` int(11) NOT NULL,
  `collect_general` int(11) NOT NULL,
  `collect_customer` int(11) NOT NULL,
  `collect_selling_debt` int(11) NOT NULL,
  `collect_selling_nodebt` int(11) NOT NULL,
  `estate_rate` int(11) NOT NULL,
  `store_value` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Dumping data for table `taphoahaiau_tracking`
--

INSERT INTO `taphoahaiau_tracking` (`id`, `date_start`, `date_end`, `paid_general`, `paid_pay_roll`, `paid_import`, `collect_general`, `collect_customer`, `collect_selling_debt`, `collect_selling_nodebt`, `estate_rate`, `store_value`) VALUES
(13, '2014-01-01', '2014-01-31', 0, 0, 0, 0, 0, 0, 0, 0, 0),
(16, '2014-02-01', '2014-02-28', 0, 0, 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_course`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_course` (
  `id` int(11) NOT NULL,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_course` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `value` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taphoahaiau_tracking_course`
--

INSERT INTO `taphoahaiau_tracking_course` (`id`, `id_tracking`, `id_td`, `id_course`, `count`, `price`, `value`) VALUES
(0, 16, 173, 260, 3, 0, 0),
(0, 16, 173, 383, 2, 0, 0),
(0, 16, 173, 325, 4, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_customer`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `value_session1` int(11) NOT NULL,
  `value_session2` int(11) NOT NULL,
  `value_collect` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_daily`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_daily` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `date` date NOT NULL,
  `selling` bigint(20) NOT NULL,
  `import` bigint(20) NOT NULL,
  `store` bigint(20) NOT NULL,
  `paid` bigint(20) NOT NULL,
  `collect` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=206 ;

--
-- Dumping data for table `taphoahaiau_tracking_daily`
--

INSERT INTO `taphoahaiau_tracking_daily` (`id`, `id_tracking`, `date`, `selling`, `import`, `store`, `paid`, `collect`) VALUES
(147, 16, '2014-02-01', 0, 0, 0, 0, 0),
(148, 16, '2014-02-02', 0, 0, 0, 0, 0),
(149, 16, '2014-02-03', 0, 0, 0, 0, 0),
(150, 16, '2014-02-04', 0, 0, 0, 0, 0),
(151, 16, '2014-02-05', 0, 0, 0, 0, 0),
(152, 16, '2014-02-06', 0, 0, 0, 0, 0),
(153, 16, '2014-02-07', 0, 0, 0, 0, 0),
(154, 16, '2014-02-08', 0, 0, 0, 0, 0),
(155, 16, '2014-02-09', 0, 0, 0, 0, 0),
(156, 16, '2014-02-10', 0, 0, 0, 0, 0),
(157, 16, '2014-02-11', 0, 0, 0, 0, 0),
(158, 16, '2014-02-12', 0, 0, 0, 0, 0),
(159, 16, '2014-02-13', 0, 0, 0, 0, 0),
(160, 16, '2014-02-14', 0, 0, 0, 0, 0),
(161, 16, '2014-02-15', 0, 0, 0, 0, 0),
(162, 16, '2014-02-16', 0, 0, 0, 0, 0),
(163, 16, '2014-02-17', 0, 0, 0, 0, 0),
(164, 16, '2014-02-18', 0, 0, 0, 0, 0),
(165, 16, '2014-02-19', 0, 0, 0, 0, 0),
(166, 16, '2014-02-20', 0, 0, 0, 0, 0),
(167, 16, '2014-02-21', 0, 0, 0, 0, 0),
(168, 16, '2014-02-22', 0, 0, 0, 0, 0),
(169, 16, '2014-02-23', 0, 0, 0, 0, 0),
(170, 16, '2014-02-24', 0, 0, 0, 0, 0),
(171, 16, '2014-02-25', 0, 0, 0, 0, 0),
(172, 16, '2014-02-26', 0, 0, 0, 0, 0),
(173, 16, '2014-02-27', 56000, 0, 0, 0, 0),
(174, 16, '2014-02-28', 0, 0, 0, 0, 0),
(175, 13, '2014-01-01', 0, 0, 0, 0, 0),
(176, 13, '2014-01-02', 0, 0, 0, 0, 0),
(177, 13, '2014-01-03', 0, 0, 0, 0, 0),
(178, 13, '2014-01-04', 0, 0, 0, 0, 0),
(179, 13, '2014-01-05', 0, 0, 0, 0, 0),
(180, 13, '2014-01-06', 0, 0, 0, 0, 0),
(181, 13, '2014-01-07', 0, 0, 0, 0, 0),
(182, 13, '2014-01-08', 0, 0, 0, 0, 0),
(183, 13, '2014-01-09', 0, 0, 0, 0, 0),
(184, 13, '2014-01-10', 0, 0, 0, 0, 0),
(185, 13, '2014-01-11', 0, 0, 0, 0, 0),
(186, 13, '2014-01-12', 0, 0, 0, 0, 0),
(187, 13, '2014-01-13', 0, 0, 0, 0, 0),
(188, 13, '2014-01-14', 0, 0, 0, 0, 0),
(189, 13, '2014-01-15', 0, 0, 0, 0, 0),
(190, 13, '2014-01-16', 0, 0, 0, 0, 0),
(191, 13, '2014-01-17', 0, 0, 0, 0, 0),
(192, 13, '2014-01-18', 0, 0, 0, 0, 0),
(193, 13, '2014-01-19', 0, 0, 0, 0, 0),
(194, 13, '2014-01-20', 0, 0, 0, 0, 0),
(195, 13, '2014-01-21', 0, 0, 0, 0, 0),
(196, 13, '2014-01-22', 0, 0, 0, 0, 0),
(197, 13, '2014-01-23', 0, 0, 0, 0, 0),
(198, 13, '2014-01-24', 0, 0, 0, 0, 0),
(199, 13, '2014-01-25', 0, 0, 0, 0, 0),
(200, 13, '2014-01-26', 0, 0, 0, 0, 0),
(201, 13, '2014-01-27', 0, 0, 0, 0, 0),
(202, 13, '2014-01-28', 0, 0, 0, 0, 0),
(203, 13, '2014-01-29', 0, 0, 0, 0, 0),
(204, 13, '2014-01-30', 0, 0, 0, 0, 0),
(205, 13, '2014-01-31', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_tracking_store`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_tracking_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `id_resource` int(11) NOT NULL,
  `count_old` float NOT NULL,
  `count_import` float NOT NULL,
  `count_export` float NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_unit`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_unit` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

--
-- Dumping data for table `taphoahaiau_unit`
--

INSERT INTO `taphoahaiau_unit` (`id`, `name`) VALUES
(1, 'Ly'),
(2, 'Điếu'),
(3, 'Chai'),
(4, 'Lon'),
(5, 'Dĩa'),
(6, 'Thùng'),
(7, 'Két'),
(9, 'Bịch'),
(10, 'Gói'),
(20, 'Trái'),
(21, 'Cái'),
(22, 'Hủ'),
(23, 'Kg'),
(24, 'Phần'),
(25, 'Bàn'),
(26, 'Hộp'),
(27, 'Bao'),
(28, 'Cây');

-- --------------------------------------------------------

--
-- Table structure for table `taphoahaiau_user`
--

CREATE TABLE IF NOT EXISTS `taphoahaiau_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `gender` int(11) NOT NULL,
  `note` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `datecreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dateupdate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `dateactivity` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `type` tinyint(4) NOT NULL,
  `code` varchar(13) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `taphoahaiau_user`
--

INSERT INTO `taphoahaiau_user` (`id`, `name`, `email`, `pass`, `gender`, `note`, `datecreate`, `dateupdate`, `dateactivity`, `type`, `code`) VALUES
(3, 'Bán hàng', 'banhang@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 1, ''),
(4, 'Quản lý', 'quanly@gmail.com', '123456', 0, '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 4, '');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `taphoahaiau_collect_customer`
--
ALTER TABLE `taphoahaiau_collect_customer`
  ADD CONSTRAINT `taphoahaiau_customer_collect_1` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_collect_general`
--
ALTER TABLE `taphoahaiau_collect_general`
  ADD CONSTRAINT `taphoahaiau_collect_general_1` FOREIGN KEY (`id_term`) REFERENCES `taphoahaiau_term_collect` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_course`
--
ALTER TABLE `taphoahaiau_course`
  ADD CONSTRAINT `taphoahaiau_course_1` FOREIGN KEY (`idcategory`) REFERENCES `taphoahaiau_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_order_import`
--
ALTER TABLE `taphoahaiau_order_import`
  ADD CONSTRAINT `taphoahaiau_order_import_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_order_import_detail`
--
ALTER TABLE `taphoahaiau_order_import_detail`
  ADD CONSTRAINT `taphoahaiau_order_import_detail_1` FOREIGN KEY (`idorder`) REFERENCES `taphoahaiau_order_import` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_order_import_detail_2` FOREIGN KEY (`idresource`) REFERENCES `taphoahaiau_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_customer`
--
ALTER TABLE `taphoahaiau_paid_customer`
  ADD CONSTRAINT `taphoahaiau_customer_paid_1` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_employee`
--
ALTER TABLE `taphoahaiau_paid_employee`
  ADD CONSTRAINT `taphoahaiau_paid_employee_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_general`
--
ALTER TABLE `taphoahaiau_paid_general`
  ADD CONSTRAINT `taphoahaiau_paid_general_1` FOREIGN KEY (`id_term`) REFERENCES `taphoahaiau_term` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_pay_roll`
--
ALTER TABLE `taphoahaiau_paid_pay_roll`
  ADD CONSTRAINT `taphoahaiau_paid_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_paid_supplier`
--
ALTER TABLE `taphoahaiau_paid_supplier`
  ADD CONSTRAINT `taphoahaiau_supplier_paid_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_pay_roll`
--
ALTER TABLE `taphoahaiau_pay_roll`
  ADD CONSTRAINT `taphoahaiau_pay_roll_ibfk_1` FOREIGN KEY (`id_employee`) REFERENCES `taphoahaiau_employee` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_r2c`
--
ALTER TABLE `taphoahaiau_r2c`
  ADD CONSTRAINT `taphoahaiau_r2c_1` FOREIGN KEY (`id_course`) REFERENCES `taphoahaiau_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_r2c_2` FOREIGN KEY (`id_resource`) REFERENCES `taphoahaiau_resource` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_resource`
--
ALTER TABLE `taphoahaiau_resource`
  ADD CONSTRAINT `taphoahaiau_resource_1` FOREIGN KEY (`idsupplier`) REFERENCES `taphoahaiau_supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_session`
--
ALTER TABLE `taphoahaiau_session`
  ADD CONSTRAINT `taphoahaiau_session_1` FOREIGN KEY (`idtable`) REFERENCES `taphoahaiau_table` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_2` FOREIGN KEY (`iduser`) REFERENCES `taphoahaiau_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_3` FOREIGN KEY (`idcustomer`) REFERENCES `taphoahaiau_customer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_session_detail`
--
ALTER TABLE `taphoahaiau_session_detail`
  ADD CONSTRAINT `taphoahaiau_session_detail_1` FOREIGN KEY (`idsession`) REFERENCES `taphoahaiau_session` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `taphoahaiau_session_detail_2` FOREIGN KEY (`idcourse`) REFERENCES `taphoahaiau_course` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `taphoahaiau_table`
--
ALTER TABLE `taphoahaiau_table`
  ADD CONSTRAINT `taphoahaiau_table_1` FOREIGN KEY (`iddomain`) REFERENCES `taphoahaiau_domain` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
