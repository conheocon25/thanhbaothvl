<?php 
function tpl_51dfb4f6_indexAdmin__NZkYKudkkw4k_AXY4rtYpQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/jquery-ui-1.8.11.custom.css"/>	
	<?php /* tag "script" from line 9 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.js"></script>
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.init.dataTables.js"></script>	
</head>
<?php /* tag "script" from line 13 */; ?>
<script>
	$(document).ready(function() {	
		$("#"+$("#CurrentPage").val()).css("color","red");	
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-13267161-16']);
		_gaq.push(['_trackPageview']);
		(function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();
	});			
</script>
<?php /* tag "body" from line 26 */; ?>
<body>
	<?php /* tag "div" from line 27 */; ?>
<div id="frame">
		<?php /* tag "div" from line 28 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 29 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuIndex', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 30 */; ?>
<div id="main">
			<?php /* tag "div" from line 31 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 32 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
			<?php /* tag "div" from line 34 */; ?>
<div id="main3_of2">
				<?php 
/* tag "div" from line 35 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuSearch', $_thistpl) ;
$ctx->popSlots() ;
?>

				<?php /* tag "div" from line 36 */; ?>
<div id="tieude_main"><?php echo phptal_escape($ctx->title); ?>
</div>
				<?php 
/* tag "input" from line 37 */ ;
if (null !== ($_tmp_1 = ($ctx->currentpage))):  ;
$_tmp_1 = ' value="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<input id="CurrentPage" type="hidden"<?php echo $_tmp_1 ?>
/>
				<?php /* tag "div" from line 38 */; ?>
<div id="Table">
					<?php /* tag "table" from line 39 */; ?>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="DataTable">
						<?php /* tag "thead" from line 40 */; ?>
<thead>
						<?php /* tag "tr" from line 41 */; ?>
<tr class="title" align="center">
							<?php /* tag "td" from line 42 */; ?>
<td style="font-weight:bold" width="3%" align="center">STT</td>
							<?php /* tag "td" from line 43 */; ?>
<td style="font-weight:bold" width="24%" align="center">Số Sim</td>
							<?php /* tag "td" from line 44 */; ?>
<td style="font-weight:bold" width="10%" align="center">Giá</td>							
							<?php /* tag "td" from line 45 */; ?>
<td style="font-weight:bold" width="13%" align="center">Mạng</td>							
							<?php /* tag "td" from line 46 */; ?>
<td style="font-weight:bold" width="20%" align="center"></td>							
						</tr>
						</thead>
						<?php /* tag "tbody" from line 49 */; ?>
<tbody>
						<?php 
/* tag "tr" from line 50 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->phonnumber = new PHPTAL_RepeatController($ctx->PhoneNumbers)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->phonnumber as $ctx->phonnumber): ;
?>
<tr>
							<?php /* tag "td" from line 51 */; ?>
<td width="3%" align="center"></td>
							<?php /* tag "td" from line 52 */; ?>
<td width="24%" align="center" style="font-size:17px;font-weight:bold;" class="sim"><?php echo phptal_escape($ctx->path($ctx->phonnumber, 'getFormatNumber')); ?>
</td>
							<?php /* tag "td" from line 53 */; ?>
<td width="10%" align="right" style="font-size:16px;font-weight:bold"><?php echo phptal_escape($ctx->path($ctx->phonnumber, 'getPrice')); ?>
</td>
							<?php /* tag "td" from line 54 */; ?>
<td width="13%" align="center">
								<?php 
/* tag "img" from line 55 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->phonnumber, 'getNetworkPicture')))):  ;
$_tmp_2 = ' src="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<img height="27px"<?php echo $_tmp_2 ?>
/>
							</td>						
							<?php /* tag "td" from line 57 */; ?>
<td width="20%" align="left">
								<?php 
/* tag "a" from line 58 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->phonnumber, 'getEditLinked')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a style="padding-right:0px"<?php echo $_tmp_2 ?>
>Sửa</a>
								<?php 
/* tag "a" from line 59 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->phonnumber, 'getDeleteLinked')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>Xóa</a>								
							</td>
						</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
											
						</tbody>
					</table>
					<?php 
/* tag "div" from line 64 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/page', $_thistpl) ;
$ctx->popSlots() ;
?>
					
				</div> 
			</div>
			<?php /* tag "div" from line 67 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 68 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin11', $_thistpl) ;
$ctx->popSlots() ;
?>

				<?php /* tag "div" from line 69 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 70 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 70 */; ?>
<img width="100%" height="50%" border="0" src="Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 70 */; ?>
<br/>
					<?php /* tag "a" from line 71 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 71 */; ?>
<img width="100%" height="50%" border="0" src="Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 71 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 74 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 76 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 77 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 78 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/indexAdmin.html (edit that file instead) */; ?>