<?php 
function tpl_51dfb4f5_index__l1AtN3xVUUNLqFaMxhynfA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="Template/css/jquery-ui-1.8.11.custom.css"/>	
	<?php /* tag "script" from line 9 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.js"></script>
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.init.dataTables.js"></script>
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="Template/script/jquery.textchange.js"></script>
	
</head>
<?php /* tag "script" from line 15 */; ?>
<script>
/*<![CDATA[*/
	$(document).ready(function(){	
			$("#"+$("#CurrentPage").val()).css("color","red");	
			
			var _gaq = _gaq || [];		
			_gaq.push(['_setAccount', 'UA-13267161-16']);
			_gaq.push(['_trackPageview']);
			
			(function() {
				var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
				ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
				var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
			})();
	});
/*]]>*/	
</script>
<?php /* tag "body" from line 32 */; ?>
<body>
	<?php /* tag "div" from line 33 */; ?>
<div id="frame">
		<?php /* tag "div" from line 34 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 35 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuIndex', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 36 */; ?>
<div id="main">
			<?php /* tag "div" from line 37 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 38 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
		<?php /* tag "div" from line 40 */; ?>
<div id="main3_of2">
				<?php 
/* tag "div" from line 41 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuSearch', $_thistpl) ;
$ctx->popSlots() ;
?>

				<?php /* tag "span" from line 42 */; ?>
<span id="error"></span>
				
				<?php /* tag "div" from line 44 */; ?>
<div id="tieude_main"><?php echo phptal_escape($ctx->title); ?>
</div>	
				<?php 
/* tag "input" from line 45 */ ;
if (null !== ($_tmp_1 = ($ctx->currentpage))):  ;
$_tmp_1 = ' value="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<input id="CurrentPage" type="hidden"<?php echo $_tmp_1 ?>
/>
				<?php /* tag "div" from line 46 */; ?>
<div id="Table">
						<?php /* tag "table" from line 47 */; ?>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="DataTable">
						<?php /* tag "thead" from line 48 */; ?>
<thead>						
							<?php /* tag "tr" from line 49 */; ?>
<tr>
								<?php /* tag "th" from line 50 */; ?>
<th style="font-weight:bold" width="5%" align="center">STT</th>
								<?php /* tag "th" from line 51 */; ?>
<th style="font-weight:bold" width="25%" align="center">Số Sim</th>
								<?php /* tag "th" from line 52 */; ?>
<th style="font-weight:bold" width="13%" align="center">Mạng</th>
								<?php /* tag "th" from line 53 */; ?>
<th style="font-weight:bold" width="15%" align="center">Giá</th>
								<?php /* tag "th" from line 54 */; ?>
<th style="font-weight:bold" width="12%" align="left">Đặt Mua</th>
							</tr>
						</thead>
						<?php /* tag "tbody" from line 57 */; ?>
<tbody>
						<?php 
/* tag "tr" from line 58 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->phonnumber = new PHPTAL_RepeatController($ctx->PhoneNumbers)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->phonnumber as $ctx->phonnumber): ;
?>
<tr>
							<?php /* tag "td" from line 59 */; ?>
<td width="5%" align="center"><?php echo phptal_escape($ctx->path($ctx->repeat, 'phonnumber/number')); ?>
</td>
							<?php /* tag "td" from line 60 */; ?>
<td width="25%" align="center" style="font-size:20px;font-weight:bold;"><?php echo phptal_escape($ctx->path($ctx->phonnumber, 'getFormatNumber')); ?>
</td>
							
							<?php /* tag "td" from line 62 */; ?>
<td width="13%" align="center">
								<?php 
/* tag "img" from line 63 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->phonnumber, 'getNetworkPicture')))):  ;
$_tmp_2 = ' src="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<img align="center" width="100px" height="37px"<?php echo $_tmp_2 ?>
/>
							</td>
							<?php /* tag "td" from line 65 */; ?>
<td width="15%" align="right" style="font-size:19px;"><?php echo phptal_escape($ctx->path($ctx->phonnumber, 'getPrice')); ?>
</td>
							<?php /* tag "td" from line 66 */; ?>
<td width="12%" align="left">
								<?php 
/* tag "a" from line 67 */ ;
if (!($ctx->path($ctx->phonnumber, 'state'))):  ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->phonnumber, 'getTitleCartLinked')))):  ;
$_tmp_2 = ' title="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->phonnumber, 'getCartIndexLinked')))):  ;
$_tmp_3 = ' href="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
<?php echo $_tmp_3 ?>
>
									<?php /* tag "img" from line 68 */; ?>
<img alt="Mua sim này" src="Template/images/cart.png" height="30px"/>
								</a><?php endif; ?>

								<?php 
/* tag "img" from line 70 */ ;
if ($ctx->path($ctx->phonnumber, 'state')):  ;
?>
<img alt="Mua sim này" src="Template/images/cart.png" height="30px"/><?php endif; ?>

							</td>
						</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
											
						</tbody>
					</table>
				</div>	
				<?php 
/* tag "div" from line 76 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/page', $_thistpl) ;
$ctx->popSlots() ;
?>

		</div> 			
			<?php /* tag "div" from line 78 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 79 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Index', $_thistpl) ;
$ctx->popSlots() ;
?>

				<?php /* tag "div" from line 80 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 81 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 81 */; ?>
<img width="100%" height="50%" border="0" src="Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 81 */; ?>
<br/>
					<?php /* tag "a" from line 82 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 82 */; ?>
<img width="100%" height="50%" border="0" src="Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 82 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 85 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 87 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 88 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 89 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/index.html (edit that file instead) */; ?>