<?php
class tgshai_number {		
		function getId()
		{
			return $this->id;
		}
		function getNumber()
		{
			return $this->number;
		}
		function getFormatNumber()
		{
			return trim($this->formatnumber, ' ');
		}
		function getState()
		{
			if ($this->state == 0)
				return "Còn hàng";
			else	return "Hết hàng";
		}		
		function getPrice()
		{
			return number_format(trim($this->price),0,',','.');
		}
		function getNetworkPicture()
		{
			return "../Template/images/$this->network";
			
		}
		function getNetwork()
		{
			return $this->network;
		}
		function getCartLinked()
		{
			return "../Command/addcustomer.php?idnumber=$this->number";
			
		}
		function getCartIndexLinked()
		{
			return "../Command/addcustomer.php?idnumber=$this->number";
			
		}
		function getDeleteLinked()
		{
			return "../Command/editnumber.php?delnumber=$this->id";
			
		}
		function getDeleteHotNumberLinked()
		{
			return "../Command/viewhotnumber.php?id=$this->id";
			
		}
		function getHotNumberLinked()
		{
			return "../Command/inserthotnumber.php?id=$this->id";
			
		}
		function getEditLinked()
		{
			return "../Command/editnumber.php?idnumber=$this->id";
			
		}
		function getTitleCartLinked()
		{
			return "Bạn chọn để mua Sim $this->number";
			
		}
	}
?>