<?php
	session_start();
	
	require_once 'PHPTAL/PHPTAL.php';
	require_once 'PDOConnection.php';
	date_default_timezone_set('Asia/Ho_Chi_Minh');
	
	$template = new PHPTAL('../Template/XoaAllHotPhoneNumber.html');
	
	$connetionPDO = new PDOConnection();
	if ($_SESSION["UID"] != "")
	{		
		$UserName = $_SESSION["UID"];
	}
	
	if ($_POST['checkDeleteAllHotNumber'] == "YES") {
		
		$connetionPDO->deleteAllHotNumber();
	}
	
	$ListOrder = $connetionPDO->findOrder(0,10);
	$PhoneNumberHotLine = $connetionPDO->findPhoneHotNumber();
	
	$template->UserName = $UserName;	
	$template->title = 'Danh Sách Sim Số ';
	$template->ListOrder = $ListOrder;
	$template->PhoneNumberHotLine = $PhoneNumberHotLine; 	
	try {
		echo $template->execute();
	}
	catch (Exception $e){
		echo $e;
	}				
?>