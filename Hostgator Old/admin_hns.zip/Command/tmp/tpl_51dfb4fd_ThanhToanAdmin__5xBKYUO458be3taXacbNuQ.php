<?php 
function tpl_51dfb4fd_ThanhToanAdmin__5xBKYUO458be3taXacbNuQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
</head>
<?php /* tag "body" from line 14 */; ?>
<body>
	<?php /* tag "div" from line 15 */; ?>
<div id="frame">
		<?php /* tag "div" from line 16 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 17 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuMuasim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 18 */; ?>
<div id="main">
			<?php /* tag "div" from line 19 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 20 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
			<?php /* tag "div" from line 22 */; ?>
<div id="main3_of2_height">
				<?php /* tag "div" from line 23 */; ?>
<div id="tieude_main">Phương thức thanh toán và nhận sim</div>
				<?php /* tag "div" from line 24 */; ?>
<div style="padding: 0 20px 0 20px; text-align: left; color: black;">
					<?php /* tag "p" from line 25 */; ?>
<p style="text-indent:30px;">Quí Khách hãy gọi đến <?php /* tag "font" from line 25 */; ?>
<font color="red" size="4"><?php /* tag "b" from line 25 */; ?>
<b>0944.92.96.96 – 0977.666.098</b></font> để dược chúng tôi cung cấp thông tin về sim số quý khách đặt mua và tư vấn hình thức thanh toán thuận tiện nhất cho quý khách.<?php /* tag "br" from line 25 */; ?>
<br/>
					<?php /* tag "font" from line 26 */; ?>
<font size="4" style="line-height:30px;"><?php /* tag "b" from line 26 */; ?>
<b>1. Nếu quý khách ở TP.Hồ Chí Minh:</b></font><?php /* tag "br" from line 26 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Quý khách ở Thành Phố <?php /* tag "font" from line 27 */; ?>
<font color="red">Hồ Chí Minh</font> chỉ cần đặt mua sim qua điện thoại hoặc tại website <?php /* tag "a" from line 27 */; ?>
<a href="http://www.thegioisim24h.com">www.thegioisim24h.com</a> Chúng tôi sẽ gọi điện lại cho quí khách để xác nhận thông tin và Sim cần mua.Chúng tôi sẽ cho nhân viên mang sim tới tận nơi Quý khách yêu cầu trong thời gian sớm nhất ( miễn phí vận chuyển).<?php /* tag "br" from line 27 */; ?>
<br/>
					<?php /* tag "font" from line 28 */; ?>
<font size="4" style="line-height:30px;"><?php /* tag "b" from line 28 */; ?>
<b>2. Nếu quý khách ở tỉnh xa:</b></font><?php /* tag "br" from line 28 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php /* tag "font" from line 29 */; ?>
<font color="blue"><?php /* tag "u" from line 29 */; ?>
<u>Đơn giản, quý khách chỉ cần</u>:</font><?php /* tag "br" from line 29 */; ?>
<br/>
					<?php /* tag "font" from line 30 */; ?>
<font color="blue" style="line-height:25px;"><?php /* tag "b" from line 30 */; ?>
<b>• Đặt mua sim số đẹp trên website.</b></font><?php /* tag "br" from line 30 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Để đặt mua <?php /* tag "b" from line 31 */; ?>
<b>số đẹp</b> trên website <?php /* tag "a" from line 31 */; ?>
<a href="http://www.thegioisim24h.com"> www.thegioisim24h.com</a> quý khách có thể nhấn vào chữ đặt mua bên cạnh sim tìm được điền đầy đủ thông tin đặt hàng và nhấn vào chữ đặt hàng hoặc quý khách có thể gọi điện trực tiếp đến số máy hỗ trợ của chúng tôi:<?php /* tag "br" from line 31 */; ?>
<br/>
					<?php /* tag "font" from line 32 */; ?>
<font color="red" size="4"><?php /* tag "b" from line 32 */; ?>
<b>0944.92.96.96 – 0977.666.098</b></font>.<?php /* tag "br" from line 32 */; ?>
<br/>
					<?php /* tag "font" from line 33 */; ?>
<font color="blue" style="line-height:25px;"><?php /* tag "b" from line 33 */; ?>
<b>• Đăng ký sử dụng sim số đẹp.</b></font><?php /* tag "br" from line 33 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Để đăng ký sử dụng số đẹp khi Quý khách nhận được sim ,Quý khách có thể gọi điện cho chúng tôi cung cấp thông tin cá nhân chúng tôi sẽ đăng ký thông tin sim cho Quý khách, Quý khách cũng có thể đem <?php /* tag "b" from line 34 */; ?>
<b>sim số đẹp</b> nhận được và CMND ra văn phòng giao dịch của nhà mạng để đăng ký thông tin cá nhân hoặc nhờ nhân viên chuyển sim tới đăng ký (Nếu đó là nhân viên của chúng tôi mang sim tới).<?php /* tag "br" from line 34 */; ?>
<br/>
					<?php /* tag "font" from line 35 */; ?>
<font color="blue" style="line-height:25px;"><?php /* tag "b" from line 35 */; ?>
<b>• Thanh toán và nhận sim số đẹp</b></font><?php /* tag "br" from line 35 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Thanh toán tiền  khi nhận Sim :  Quý khách  thanh toán trực tiếp cho nhân viên của chúng tôi khi mang sim tới giao cho Quý khách hoặc Nhân viên giao hàng bên chuyển phát nhanh mà chúng tôi nhờ giao sim và nhận tiền hộ.<?php /* tag "br" from line 36 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Nhân viên bưu điện tại địa phương sẽ giao hàng đến quí khách tại địa điểm mà quí khách đã đăng ký. Trong trường hợp quí khách đi vắng, vui lòng uỷ thác cho người khác nhận hàng và thanh toán tiền thay.<?php /* tag "br" from line 37 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Trong một số trường hợp nhân viên bưu điện đến phát mà không có người nhận, nhân viên bưu điện sẽ để lại tin nhắn mời khách hàng đến bưu điện nhận hàng.<?php /* tag "br" from line 38 */; ?>
<br/>
					Quý khách cũng có thể thanh toán qua chuyển khoản theo số tài khoản trên website.<?php /* tag "br" from line 39 */; ?>
<br/>
					<?php /* tag "font" from line 40 */; ?>
<font color="blue" style="line-height:25px;"><?php /* tag "b" from line 40 */; ?>
<b>• Tôi ở xa muốn mua sim số đẹp</b>?</font><?php /* tag "br" from line 40 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Dù quý khách ở bất kỳ nơi đâu chúng tôi cũng có thể giao sim tận tay và nhận tiền trực tiếp, đăng ký chính chủ thông tin cho quý khách. Quý khách chỉ cần đặt hàng trên website hoặc gọi điện cho chúng tôi  <?php /* tag "font" from line 41 */; ?>
<font color="red" size="4"><?php /* tag "b" from line 41 */; ?>
<b>0944.92.96.96 - 0977.666.098</b></font>.<?php /* tag "br" from line 41 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Sau 48h giờ quý khách không nhận được Sim sau khi đặt hàng và xác nhận thông tin hãy thông báo cho chúng tôi . Xin vui lòng gọi điện đến số hỗ trợ để yêu cầu kiểm tra đơn đặt hàng.<?php /* tag "br" from line 42 */; ?>
<br/>
					<?php /* tag "font" from line 43 */; ?>
<font size="4" style="line-height:30px;"><?php /* tag "b" from line 43 */; ?>
<b>3. Thanh toán bằng thẻ ATM  hoặc qua ngân hàng:</b></font><?php /* tag "br" from line 43 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Qúi khách vui lòng chuyển tiền vào một trong các tài  khoản dưới đây sau đó SMS cho chúng tôi địa chỉ nhận sim.<?php /* tag "br" from line 44 */; ?>
<br/>
					
					<?php /* tag "table" from line 46 */; ?>
<table border="0" width="100%" style="float: left; background: #DCE8FC; margin: 5px 0 5px 0; padding:  5px 0 5px 0;"><?php /* tag "tr" from line 46 */; ?>
<tr><?php /* tag "td" from line 46 */; ?>
<td>
					<?php /* tag "i" from line 47 */; ?>
<i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Công Thương Việt Nam - VietinBank , Tp HCM<?php /* tag "br" from line 47 */; ?>
<br/>
					<?php /* tag "span" from line 48 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 48 */; ?>
<b>STK : </b><?php /* tag "font" from line 48 */; ?>
<font color="red"> 711A.0650.3748 </font><?php /* tag "br" from line 48 */; ?>
<br/></span>
					<?php /* tag "span" from line 49 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 49 */; ?>
<br/></span>

					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Đông Á  - DongABank  ,CN Q 10,Tp HCM<?php /* tag "br" from line 51 */; ?>
<br/>
					<?php /* tag "span" from line 52 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 52 */; ?>
<b>STK  : </b><?php /* tag "font" from line 52 */; ?>
<font color="red"> 0107.5933.27 </font><?php /* tag "br" from line 52 */; ?>
<br/></span>
					<?php /* tag "span" from line 53 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 53 */; ?>
<br/></span>

					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Xuất Nhập Khẩu Việt Nam – EXIMBANK – SGD 1<?php /* tag "br" from line 55 */; ?>
<br/>
					<?php /* tag "span" from line 56 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 56 */; ?>
<b>STK  : </b><?php /* tag "font" from line 56 */; ?>
<font color="red"> 2000.14949.2454.62 </font><?php /* tag "br" from line 56 */; ?>
<br/></span>
					<?php /* tag "span" from line 57 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 57 */; ?>
<br/></span></i>
					</td></tr></table>
					
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Quí khách sẽ nhận được sim trong vòng 24h – 48h tại nhà từ khi chuyển tiền xong, mọi thất lạc trong quá trình chuyển sim chúng tôi hoàn toàn chịu trách nhiệm.<?php /* tag "br" from line 60 */; ?>
<br/>
					<?php /* tag "font" from line 61 */; ?>
<font color="blue" size="4">Lưu ý: Quý khách nên chuyển tiền trong cùng hệ thống ngân hàng để tránh mất thời gian chờ đợi.<?php /* tag "br" from line 61 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Rất hân hạnh được phục vụ quí khách!<?php /* tag "br" from line 62 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Quý khách cần được biết thêm thông tin, cánh thức mua <?php /* tag "b" from line 63 */; ?>
<b><?php /* tag "i" from line 63 */; ?>
<i>số đẹp</i></b>, cách thức thanh toán và nhận sim...<?php /* tag "br" from line 63 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Đừng ngần ngại hãy gọi qua số hỗ trợ khách hàng cho chúng tôi.</font><?php /* tag "br" from line 64 */; ?>
<br/>
					<?php /* tag "center" from line 65 */; ?>
<center><?php /* tag "font" from line 65 */; ?>
<font color="blue"><?php /* tag "b" from line 65 */; ?>
<b>SỐ MÁY HỖ TRỢ KHÁCH HÀNG</b></font><?php /* tag "br" from line 65 */; ?>
<br/>
					<?php /* tag "font" from line 66 */; ?>
<font color="red" size="4"><?php /* tag "b" from line 66 */; ?>
<b>0944.92.96.96 – 0977.666.098</b></font></center>
					</p>
				</div>
			</div>
			<?php /* tag "div" from line 70 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 71 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
 
				<?php /* tag "div" from line 72 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 73 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 73 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 73 */; ?>
<br/>
					<?php /* tag "a" from line 74 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 74 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 74 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 77 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 79 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 80 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 81 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/ThanhToanAdmin.html (edit that file instead) */; ?>