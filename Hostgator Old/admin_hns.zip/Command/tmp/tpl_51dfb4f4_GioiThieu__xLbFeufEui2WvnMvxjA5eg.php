<?php 
function tpl_51dfb4f4_GioiThieu__xLbFeufEui2WvnMvxjA5eg(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
</head>
<?php /* tag "body" from line 8 */; ?>
<body>
	<?php /* tag "div" from line 9 */; ?>
<div id="frame">
		<?php /* tag "div" from line 10 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuGioithieu', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 12 */; ?>
<div id="main">
			<?php /* tag "div" from line 13 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 16 */; ?>
<div id="main3_of2">
					<?php /* tag "div" from line 17 */; ?>
<div id="tieude_main">Vì sao phải dùng Sim Số Đẹp Giá Rẻ?</div>
					<?php /* tag "div" from line 18 */; ?>
<div align="justify" style="margin-bottom: 10px; padding: 0 20px 0 20px;">
						<?php /* tag "p" from line 19 */; ?>
<p style="text-indent:25px;">Chơi sim số đẹp hiện đang trở thành một trào lưu khá phổ biến ở Việt Nam; đặc biệt tại các thành phố lớn như TP HCM, Hà Nội, Hải Phòng… Tuy nhiên, những câu hỏi xung quanh việc chơi sim số như : chơi sim số cụ thể là gì; chơi sim như thế nào mới là đúng cách; những kinh nghiệm và kiến thức khi chơi sim số…đang được rất nhiều người đặt ra và đi tìm câu trả lời.Trong khuôn khổ loạt bai viết về “Chơi sim số” chúng tôi sẽ cố gắng cung cấp những thông tin hữu ích nhất về “Chơi sim số”; giúp bạn đọc có cái nhìn tổng quan và sâu hơn về trào lưu “Chơi sim số” hiện nay.</p><?php /* tag "br" from line 19 */; ?>
<br/>
						<?php /* tag "p" from line 20 */; ?>
<p style="text-indent:25px;">Phải khẳng định vui 1 chút là “Chơi sim số đẹp” khác hẳn với “Chơi Số Đề” , sim số đẹp có rất nhiều cách chơi, ở đây tôi có thể kể ra một vài cách chơi thường gặp và quen thuộc:</p><?php /* tag "br" from line 20 */; ?>
<br/>
						<?php /* tag "p" from line 21 */; ?>
<p style="text-indent:25px; font-size: 18px; font-weight:bold;">1. Phân loại Sim số:</p>
						<?php /* tag "table" from line 22 */; ?>
<table cellspacing="-2" style="margin: 5px 0 5px 0; float: left; border: 1px solid #999;">
							<?php /* tag "tr" from line 23 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 24 */; ?>
<td>STT</td>
								<?php /* tag "td" from line 25 */; ?>
<td align="center">Phân loại Sim Số</td>
							</tr>
							<?php /* tag "tr" from line 27 */; ?>
<tr>
								<?php /* tag "td" from line 28 */; ?>
<td class="ow_td1">01</td>
								<?php /* tag "td" from line 29 */; ?>
<td style="padding-left: 5px;">SIM rác :dòng này ko tính vì giá trị quá nhỏ (rất thập cẩm)</td>
							</tr>
							<?php /* tag "tr" from line 31 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 32 */; ?>
<td class="ow_td2">02</td>
								<?php /* tag "td" from line 33 */; ?>
<td style="padding-left: 5px;">Sim số đẹp trùng biển số xe</td>
							</tr>
							<?php /* tag "tr" from line 35 */; ?>
<tr>
								<?php /* tag "td" from line 36 */; ?>
<td class="ow_td1">03</td>
								<?php /* tag "td" from line 37 */; ?>
<td style="padding-left: 5px;">Sim số đẹp ngày tháng năm sinh</td>
							</tr>
							<?php /* tag "tr" from line 39 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 40 */; ?>
<td class="ow_td2">04</td>
								<?php /* tag "td" from line 41 */; ?>
<td style="padding-left: 5px;">Sim số đẹp ngày tháng có ý nghĩa (Quốc Khánh… hoặc ý nghĩa với người sử dụng)</td>
							</tr>
							<?php /* tag "tr" from line 43 */; ?>
<tr>
								<?php /* tag "td" from line 44 */; ?>
<td class="ow_td1">05</td>
								<?php /* tag "td" from line 45 */; ?>
<td style="padding-left: 5px;">Sim số đẹp soi gương (ABC.CBA)</td>
							</tr>
							<?php /* tag "tr" from line 47 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 48 */; ?>
<td class="ow_td2">06</td>
								<?php /* tag "td" from line 49 */; ?>
<td style="padding-left: 5px;">Sim số đẹp lồng lộn (AB.BA.AB / ABC.CBA.ABC)</td>
							</tr>
							<?php /* tag "tr" from line 51 */; ?>
<tr>
								<?php /* tag "td" from line 52 */; ?>
<td class="ow_td1">07</td>
								<?php /* tag "td" from line 53 */; ?>
<td style="padding-left: 5px;">Sim số đẹp số gánh (ABBA / ABBBA)</td>
							</tr>
							<?php /* tag "tr" from line 55 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 56 */; ?>
<td class="ow_td2">08</td>
								<?php /* tag "td" from line 57 */; ?>
<td style="padding-left: 5px;">Sim số đẹp số tiến (VD : 1234… 010203… 203040…)</td>
							</tr>
							<?php /* tag "tr" from line 59 */; ?>
<tr>
								<?php /* tag "td" from line 60 */; ?>
<td class="ow_td1">09</td>
								<?php /* tag "td" from line 61 */; ?>
<td style="padding-left: 5px;">Sim số đẹp luận / dịch nôm (Như phía bài trên đã nói)</td>
							</tr>
							<?php /* tag "tr" from line 63 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 64 */; ?>
<td class="ow_td2">10</td>
								<?php /* tag "td" from line 65 */; ?>
<td style="padding-left: 5px;">Sim số đẹp phong thủy (sim số đẹp hợp với mệnh người sử dụng sim số đẹp theo cách tính phong thủy)</td>
							</tr>
							<?php /* tag "tr" from line 67 */; ?>
<tr>
								<?php /* tag "td" from line 68 */; ?>
<td class="ow_td1">11</td>
								<?php /* tag "td" from line 69 */; ?>
<td style="padding-left: 5px;">Sim taxi (AB.AB.AB / ABC.ABC)</td>
							</tr>
							<?php /* tag "tr" from line 71 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 72 */; ?>
<td class="ow_td2">12</td>
								<?php /* tag "td" from line 73 */; ?>
<td style="padding-left: 5px;">Sim số đẹp VIP (Tứ quý – ngũ phúc – lục tài…) SIM dòng này dễ nhớ và rất đắt</td>
							</tr>
							<?php /* tag "tr" from line 75 */; ?>
<tr>
								<?php /* tag "td" from line 76 */; ?>
<td class="ow_td1">13</td>
								<?php /* tag "td" from line 77 */; ?>
<td style="padding-left: 5px;">Sim số đẹp độc (Sim số xấu, hiếm gặp)</td>
							</tr>
						</table>

						<?php /* tag "p" from line 81 */; ?>
<p style="text-indent:25px; font-weight:bold; font-size: 18px;">2. Một số dạng luận sim số đẹp phổ biến hiện nay:</p><?php /* tag "br" from line 81 */; ?>
<br/>
						<?php /* tag "table" from line 82 */; ?>
<table cellspacing="-2" width="100%" style="margin: 5px 0 5px 0; border: 1px solid #999;">
							<?php /* tag "tr" from line 83 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 84 */; ?>
<td align="center">Con Số</td>
								<?php /* tag "td" from line 85 */; ?>
<td align="center">Ý nghĩa</td>
							</tr>
							<?php /* tag "tr" from line 87 */; ?>
<tr>
								<?php /* tag "td" from line 88 */; ?>
<td class="ow_td1">0</td>
								<?php /* tag "td" from line 89 */; ?>
<td style="padding-left: 5px;">Tay trắng / Bất (phủ định)</td>
							</tr>
							<?php /* tag "tr" from line 91 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 92 */; ?>
<td class="ow_td2">1</td>
								<?php /* tag "td" from line 93 */; ?>
<td style="padding-left: 5px;">Nhất / Độc / Sinh</td>
							</tr>
							<?php /* tag "tr" from line 95 */; ?>
<tr>
								<?php /* tag "td" from line 96 */; ?>
<td class="ow_td1">2</td>
								<?php /* tag "td" from line 97 */; ?>
<td style="padding-left: 5px;">Mãi</td>
							</tr>
							<?php /* tag "tr" from line 99 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 100 */; ?>
<td class="ow_td2">3</td>
								<?php /* tag "td" from line 101 */; ?>
<td style="padding-left: 5px;">Tài</td>
							</tr>
							<?php /* tag "tr" from line 103 */; ?>
<tr>
								<?php /* tag "td" from line 104 */; ?>
<td class="ow_td1">4</td>
								<?php /* tag "td" from line 105 */; ?>
<td style="padding-left: 5px;">Tử</td>
							</tr>
							<?php /* tag "tr" from line 107 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 108 */; ?>
<td class="ow_td2">5</td>
								<?php /* tag "td" from line 109 */; ?>
<td style="padding-left: 5px;">Phúc / Sinh</td>
							</tr>
							<?php /* tag "tr" from line 111 */; ?>
<tr>
								<?php /* tag "td" from line 112 */; ?>
<td class="ow_td1">6</td>
								<?php /* tag "td" from line 113 */; ?>
<td style="padding-left: 5px;">Lộc</td>
							</tr>
							<?php /* tag "tr" from line 115 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 116 */; ?>
<td class="ow_td2">7</td>
								<?php /* tag "td" from line 117 */; ?>
<td style="padding-left: 5px;">Thất</td>
							</tr>
							<?php /* tag "tr" from line 119 */; ?>
<tr>
								<?php /* tag "td" from line 120 */; ?>
<td class="ow_td1">8</td>
								<?php /* tag "td" from line 121 */; ?>
<td style="padding-left: 5px;">Phát</td>
							</tr>
							<?php /* tag "tr" from line 123 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 124 */; ?>
<td class="ow_td2">9</td>
								<?php /* tag "td" from line 125 */; ?>
<td style="padding-left: 5px;">Trường / Vĩnh cửu</td>
							</tr>
						</table>

						<?php /* tag "p" from line 129 */; ?>
<p style="text-indent:25px; font-weight:bold; font-size: 18px;">3. Một số dạng luận theo dải số:</p><?php /* tag "br" from line 129 */; ?>
<br/>
						<?php /* tag "table" from line 130 */; ?>
<table cellspacing="-2" style="margin: 5px 0 5px 0; border: 1px solid #999;">
							<?php /* tag "tr" from line 131 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 132 */; ?>
<td align="center">Dãy Số</td>
								<?php /* tag "td" from line 133 */; ?>
<td align="center">Ý nghĩa</td>
							</tr>
							<?php /* tag "tr" from line 135 */; ?>
<tr>
								<?php /* tag "td" from line 136 */; ?>
<td class="ow_td1">1102</td>
								<?php /* tag "td" from line 137 */; ?>
<td style="padding-left: 5px;">Nhất nhất ko nhì / Độc nhất vô nhị</td>
							</tr>
							<?php /* tag "tr" from line 139 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 140 */; ?>
<td class="ow_td2">4078</td>
								<?php /* tag "td" from line 141 */; ?>
<td style="padding-left: 5px;">4 mùa không thất bát</td>
							</tr>
							<?php /* tag "tr" from line 143 */; ?>
<tr>
								<?php /* tag "td" from line 144 */; ?>
<td class="ow_td1">2204</td>
								<?php /* tag "td" from line 145 */; ?>
<td style="padding-left: 5px;">Mãi mãi không chết</td>
							</tr>
							<?php /* tag "tr" from line 147 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 148 */; ?>
<td class="ow_td2">1486</td>
								<?php /* tag "td" from line 149 */; ?>
<td style="padding-left: 5px;">1 năm 4 mùa phát lộc / 1 năm 4 mùa lộc phát</td>
							</tr>
							<?php /* tag "tr" from line 151 */; ?>
<tr>
								<?php /* tag "td" from line 152 */; ?>
<td class="ow_td1">01234</td>
								<?php /* tag "td" from line 153 */; ?>
<td style="padding-left: 5px;">Tay trắng đi lên – 1 vợ – 2 con – 3 tầng – 4 bánh (Từ tay trắng – cưới vợ – yên bề con cái – xây nhà – mua ôtô ^^)</td>
							</tr>
							<?php /* tag "tr" from line 155 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 156 */; ?>
<td class="ow_td2">456</td>
								<?php /* tag "td" from line 157 */; ?>
<td style="padding-left: 5px;">4 mùa sinh lộc</td>
							</tr>
							<?php /* tag "tr" from line 159 */; ?>
<tr>
								<?php /* tag "td" from line 160 */; ?>
<td class="ow_td1">4953</td>
								<?php /* tag "td" from line 161 */; ?>
<td style="padding-left: 5px;">49 chưa qua 53 đã tới (Số tử / Tử vi)</td>
							</tr>
							<?php /* tag "tr" from line 163 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 164 */; ?>
<td class="ow_td2">68</td>
								<?php /* tag "td" from line 165 */; ?>
<td style="padding-left: 5px;">Lộc Phát</td>
							</tr>
							<?php /* tag "tr" from line 167 */; ?>
<tr>
								<?php /* tag "td" from line 168 */; ?>
<td class="ow_td1">39</td>
								<?php /* tag "td" from line 169 */; ?>
<td style="padding-left: 5px;">Thần tài nhỏ</td>
							</tr>
							<?php /* tag "tr" from line 171 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 172 */; ?>
<td class="ow_td2">79</td>
								<?php /* tag "td" from line 173 */; ?>
<td style="padding-left: 5px;">Thần tài lớn</td>
							</tr>
							<?php /* tag "tr" from line 175 */; ?>
<tr>
								<?php /* tag "td" from line 176 */; ?>
<td class="ow_td1">38</td>
								<?php /* tag "td" from line 177 */; ?>
<td style="padding-left: 5px;">Ông địa nhỏ</td>
							</tr>
							<?php /* tag "tr" from line 179 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 180 */; ?>
<td class="ow_td2">78</td>
								<?php /* tag "td" from line 181 */; ?>
<td style="padding-left: 5px;">Thất bát / Ông địa lớn</td>
							</tr>
							<?php /* tag "tr" from line 183 */; ?>
<tr>
								<?php /* tag "td" from line 184 */; ?>
<td class="ow_td1">83</td>
								<?php /* tag "td" from line 185 */; ?>
<td style="padding-left: 5px;">Phát tài</td>
							</tr>
							<?php /* tag "tr" from line 187 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 188 */; ?>
<td class="ow_td2">86</td>
								<?php /* tag "td" from line 189 */; ?>
<td style="padding-left: 5px;">Phát lộc</td>
							</tr>
							<?php /* tag "tr" from line 191 */; ?>
<tr>
								<?php /* tag "td" from line 192 */; ?>
<td class="ow_td1">04</td>
								<?php /* tag "td" from line 193 */; ?>
<td style="padding-left: 5px;">Bất tử</td>
							</tr>
							<?php /* tag "tr" from line 195 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 196 */; ?>
<td class="ow_td2">94</td>
								<?php /* tag "td" from line 197 */; ?>
<td style="padding-left: 5px;">Thái tử</td>
							</tr>
							<?php /* tag "tr" from line 199 */; ?>
<tr>
								<?php /* tag "td" from line 200 */; ?>
<td class="ow_td1">569</td>
								<?php /* tag "td" from line 201 */; ?>
<td style="padding-left: 5px;">Phúc – Lộc – Thọ</td>
							</tr>
							<?php /* tag "tr" from line 203 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 204 */; ?>
<td class="ow_td2">227</td>
								<?php /* tag "td" from line 205 */; ?>
<td style="padding-left: 5px;">Vạn Vạn Tuế</td>
							</tr>
							<?php /* tag "tr" from line 207 */; ?>
<tr>
								<?php /* tag "td" from line 208 */; ?>
<td class="ow_td1">15.16.18</td>
								<?php /* tag "td" from line 209 */; ?>
<td style="padding-left: 5px;">Mỗi năm – mỗi lộc – mỗi phát</td>
							</tr>
							<?php /* tag "tr" from line 211 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 212 */; ?>
<td class="ow_td2">6886/8668</td>
								<?php /* tag "td" from line 213 */; ?>
<td style="padding-left: 5px;">Lộc phát phát lộc / Phát lộc lộc phát</td>
							</tr>
							<?php /* tag "tr" from line 215 */; ?>
<tr>
								<?php /* tag "td" from line 216 */; ?>
<td class="ow_td1">8386/8683</td>
								<?php /* tag "td" from line 217 */; ?>
<td style="padding-left: 5px;">Phát tài phát lộc / Phát lộc phát tài</td>
							</tr>
							<?php /* tag "tr" from line 219 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 220 */; ?>
<td class="ow_td2">18.18.18</td>
								<?php /* tag "td" from line 221 */; ?>
<td style="padding-left: 5px;">Mỗi năm 1 phát</td>
							</tr>
							<?php /* tag "tr" from line 223 */; ?>
<tr>
								<?php /* tag "td" from line 224 */; ?>
<td class="ow_td1">19.19.19</td>
								<?php /* tag "td" from line 225 */; ?>
<td style="padding-left: 5px;">1 bước lên trời</td>
							</tr>
							<?php /* tag "tr" from line 227 */; ?>
<tr class="ow_tr1">
								<?php /* tag "td" from line 228 */; ?>
<td class="ow_td2">1368</td>
								<?php /* tag "td" from line 229 */; ?>
<td style="padding-left: 5px;">Nhất tài lộc phát / Kim lâu (Tử vi)</td>
							</tr>
							<?php /* tag "tr" from line 231 */; ?>
<tr>
								<?php /* tag "td" from line 232 */; ?>
<td class="ow_td1"></td>
								<?php /* tag "td" from line 233 */; ?>
<td style="padding-left: 5px;">Dãy số đuôi 1368 thực sự là dãy số rất chi là đặc biệt,dân Sim số thường quan niệm con số 1 là Sinh (sinh sôi nảy nở),3 là tài,68 là lộc phát=> 1368 là Sinh Tài Lộc Phát rất đẹp với dân làm ăn buôn bán.Tuy nhiên dãy số 1368 còn có một điểm rất đặc biệt mà ít người phát hiện ra đó là : 123+456+789=1368 Đây là 3 cặp số nối tiếp nhau trong dãy số tự nhiên từ 0-9 cộng tổng lại thành ra 1368,có thể hiểu 1368 là chuỗi số đại diện cho sự tổng hòa các con số có đẹp có xấu và mang tính chọn lọc cao nhất của dãy số tự nhiên.Vậy có thể coi 1368 là đẹp? Hơn nữa 1368 lại không chứa các số bị coi là xấu như 4 và 7 trong đó nên càng mang tính chọn lọc rất cao,hơn nữa đây là số tiến đều ko bị ngắt đoạn lên xuống chập chùng chỉ sự thăng tiến cho chủ nhân của con số này.</td>
							</tr>
						</table>

					</div>
					<?php 
/* tag "span" from line 238 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuXemThem', $_thistpl) ;
$ctx->popSlots() ;
?>
 
					<?php /* tag "br" from line 239 */; ?>
<br/>					
			</div>
			<?php /* tag "div" from line 241 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 242 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 243 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 244 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 244 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 244 */; ?>
<br/>
					<?php /* tag "a" from line 245 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 245 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 245 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 248 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 250 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 251 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
	
		<?php /* tag "div" from line 252 */; ?>
<div class="vide"></div>	
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/GioiThieu.html (edit that file instead) */; ?>