<?php 
function tpl_51dfb500_ViewTotalIncome__o6XAVgrf_mU4UVWcP2z_3A(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
	
	<?php /* tag "script" from line 14 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.datepicker-vi.js"></script>
	<?php /* tag "script" from line 15 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.datepicker.min.js"></script>
	<?php /* tag "script" from line 16 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.core.js"></script>
	<?php /* tag "link" from line 17 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery.ui.theme.css"/>
	<?php /* tag "link" from line 18 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery.ui.datepicker.css"/>
		
</head>
<?php /* tag "script" from line 21 */; ?>
<script>
	$(document).ready(function() {
	var ct = new Date();
	var year = ct.getFullYear();
	var month = ct.getMonth()+1;
	var day = ct.getDate();		
	var sUS = year+"/"+month+"/"+day;	
	var sUS1 = year+"/"+month+"/"+(day-1);	
	$("#todate").val(sUS);
	$("#fromdate").val(sUS1);
	$('#todate').datepicker({dateFormat: 'yy-mm-dd'});
	$('#fromdate').datepicker({dateFormat: 'yy-mm-dd'});
});		
</script>
<?php /* tag "body" from line 35 */; ?>
<body>
	<?php /* tag "div" from line 36 */; ?>
<div id="frame">
		<?php /* tag "div" from line 37 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 38 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuMuasim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 39 */; ?>
<div id="main">
			<?php /* tag "div" from line 40 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 41 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
			<?php /* tag "div" from line 43 */; ?>
<div id="main3_of2_height">
				<?php /* tag "div" from line 44 */; ?>
<div id="tieude_main">Thống kê doanh thu</div>
				<?php 
/* tag "span" from line 45 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuTotalIncome', $_thistpl) ;
$ctx->popSlots() ;
?>
							
				<?php /* tag "div" from line 46 */; ?>
<div id="Table" style="padding-top:80px;padding-right:15px">
					<?php /* tag "table" from line 47 */; ?>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="DataTable">
						<?php /* tag "thead" from line 48 */; ?>
<thead>
							<?php /* tag "tr" from line 49 */; ?>
<tr>
								<?php /* tag "th" from line 50 */; ?>
<th style="font-weight:bold" align="center">Stt</th>
								<?php /* tag "th" from line 51 */; ?>
<th style="font-weight:bold" align="center">Khách hàng</th>
								<?php /* tag "th" from line 52 */; ?>
<th style="font-weight:bold" align="center">Mua Số</th>
								<?php /* tag "th" from line 53 */; ?>
<th style="font-weight:bold" align="center">Ngày</th>							
								<?php /* tag "th" from line 54 */; ?>
<th style="font-weight:bold" align="center">Giá bán</th>									
							</tr>
						</thead>
						<?php /* tag "tbody" from line 57 */; ?>
<tbody>
							<?php 
/* tag "tr" from line 58 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->total = new PHPTAL_RepeatController($ctx->Totals)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->total as $ctx->total): ;
?>
<tr>
								<?php /* tag "td" from line 59 */; ?>
<td></td>
								<?php /* tag "td" from line 60 */; ?>
<td align="center" style="font-size:18px;" class="sim"><?php 
/* tag "a" from line 60 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->total, 'getViewTotalIncomeIndexLinked')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
><?php /* tag "span" from line 60 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->total, 'name')); ?>
</span></a></td>
								<?php /* tag "td" from line 61 */; ?>
<td align="center" style="font-size:17px;" class="sim"><?php echo phptal_escape($ctx->path($ctx->total, 'idsim')); ?>
</td>
								<?php /* tag "td" from line 62 */; ?>
<td align="center" style="font-size:17px;"><?php echo phptal_escape($ctx->path($ctx->total, 'date')); ?>
</td>
								<?php /* tag "td" from line 63 */; ?>
<td align="right"><?php echo phptal_escape($ctx->path($ctx->total, 'getPrice')); ?>
</td>								
							</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
											
						</tbody>
					</table>					
				</div>
			</div>
			<?php /* tag "div" from line 69 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 70 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
 
				<?php /* tag "div" from line 71 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 72 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 72 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 72 */; ?>
<br/>
					<?php /* tag "a" from line 73 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 73 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 73 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 76 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 78 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 79 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 80 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/ViewTotalIncome.html (edit that file instead) */; ?>