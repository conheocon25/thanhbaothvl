<?php 
function tpl_51dfb4ed_EditSimByPrice__7l5yjz48puZcmjLPpl40AA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
	
	<?php /* tag "script" from line 14 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.datepicker-vi.js"></script>
	<?php /* tag "script" from line 15 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.datepicker.min.js"></script>
	<?php /* tag "script" from line 16 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.ui.core.js"></script>
	<?php /* tag "link" from line 17 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery.ui.theme.css"/>
	<?php /* tag "link" from line 18 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery.ui.datepicker.css"/>
		
</head>
<?php /* tag "script" from line 21 */; ?>
<script>
	$(document).ready(function() {
	
});		
</script>
<?php /* tag "body" from line 26 */; ?>
<body>
	<?php /* tag "div" from line 27 */; ?>
<div id="frame">
		<?php /* tag "div" from line 28 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 29 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuMuasim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 30 */; ?>
<div id="main">
			<?php /* tag "div" from line 31 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 32 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

				<?php /* tag "div" from line 33 */; ?>
<div style="margin-top:10px;border:1px solid #999;height:230px;">
					<?php /* tag "a" from line 34 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 34 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 34 */; ?>
<br/>
					<?php /* tag "a" from line 35 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 35 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 35 */; ?>
<br/>
				</div>
			</div>			
			<?php /* tag "div" from line 38 */; ?>
<div id="main3_of2_height">
				<?php /* tag "div" from line 39 */; ?>
<div id="tieude_main">Tăng giá Sim</div>
				<?php 
/* tag "span" from line 40 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuEditSimByPrice', $_thistpl) ;
$ctx->popSlots() ;
?>
							
				<?php /* tag "div" from line 41 */; ?>
<div id="Table" style="padding-top:80px;padding-right:15px">										
				</div>
			</div>
			<?php /* tag "div" from line 44 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 45 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
 
				<?php /* tag "div" from line 46 */; ?>
<div style="border: 1px solid #999; height: 300px;">
					<?php /* tag "a" from line 47 */; ?>
<a href="http://www.mobifone.com.vn/web/vn/" target="_blank"><?php /* tag "img" from line 47 */; ?>
<img width="100%" height="33%" border="0" src="../Template/images/mobifone.jpg" alt="Quang Cao"/></a><?php /* tag "br" from line 47 */; ?>
<br/>
					<?php /* tag "a" from line 48 */; ?>
<a href="http://www.vinaphone.com.vn/" target="_blank"><?php /* tag "img" from line 48 */; ?>
<img style="border-top: 1px solid #999;border-bottom: 1px solid #999;" width="100%" height="33%" border="0" src="../Template/images/vinaphone.jpg" alt="Quang Cao"/></a><?php /* tag "br" from line 48 */; ?>
<br/>
					<?php /* tag "a" from line 49 */; ?>
<a href="http://viettel.com.vn/" target="_blank"><?php /* tag "img" from line 49 */; ?>
<img width="100%" height="33%" border="0" src="../Template/images/viettel.jpg" alt="Quang Cao"/></a><?php /* tag "br" from line 49 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 52 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 54 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 55 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 56 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/EditSimByPrice.html (edit that file instead) */; ?>