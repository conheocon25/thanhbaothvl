<?php 
function tpl_51dfb4f4_GioHang__kjxD9roiSFEjxvDOoofZNw(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	<?php /* tag "script" from line 9 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/main.js"></script>
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
	
</head>
<?php /* tag "script" from line 15 */; ?>
<script>
/*<![CDATA[*/
$(document).ready(function() {	
			
			
			
});	
	function CheckSubmit()
	{
		var check = false;
		check = checkTextNull($('#ordername'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");	
		if(check ==true)
		{
			check = checkPhoneNumber($('#paydienthoai'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
			if(check ==true)
			{
				check = checkEmail($('#payemail'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
				if(check ==true)
				{
					check = checkTextNull($('#cboQuanHuyen'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
					if(check ==true)
					{
						check = checkTextNull($('#DiaChiGiaoHang'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
						if(check ==true)
						{
							check = checkTextNull($('#txtCaptcha'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
							return check;
						}
						else{ return check;}
					}else{ return check;}
				}else{ return check;}
			}else{ return check;}
		}else{ return check;}
	}
/*]]>*/
</script>
<?php /* tag "body" from line 51 */; ?>
<body>
	<?php /* tag "div" from line 52 */; ?>
<div id="frame">
		<?php /* tag "div" from line 53 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 54 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuDatsim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 55 */; ?>
<div id="main">
			<?php /* tag "div" from line 56 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 57 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 59 */; ?>
<div id="main3_of2" style="height:1297px;">					
				<?php /* tag "table" from line 60 */; ?>
<table width="100%">
					<?php /* tag "tr" from line 61 */; ?>
<tr>
						<?php /* tag "td" from line 62 */; ?>
<td align="center">
							<?php /* tag "form" from line 63 */; ?>
<form id="form_LH" method="post" action="../Command/addcustomer.php" name="curtomerform">
								<?php 
/* tag "input" from line 64 */ ;
if (null !== ($_tmp_1 = ($ctx->CartId))):  ;
$_tmp_1 = ' value="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<input type="hidden" name="IdNumber"<?php echo $_tmp_1 ?>
/>
								<?php /* tag "h1" from line 65 */; ?>
<h1>Đặt mua sim:</h1>
								<?php /* tag "span" from line 66 */; ?>
<span id="simcart">
									<?php /* tag "table" from line 67 */; ?>
<table width="100%" cellpadding="3" bordercolor="#C0C0C0" border="1" style="border-collapse: collapse;">
										<?php 
/* tag "input" from line 68 */ ;
if (null !== ($_tmp_1 = ($ctx->CartNumber))):  ;
$_tmp_1 = ' value="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<input name="paynumber" type="hidden"<?php echo $_tmp_1 ?>
/>										
										<?php /* tag "tr" from line 69 */; ?>
<tr class="title" align="center">
											<?php /* tag "td" from line 70 */; ?>
<td>Mã</td>
											<?php /* tag "td" from line 71 */; ?>
<td>Số sim</td>
											<?php /* tag "td" from line 72 */; ?>
<td>Giá</td>			
											<?php /* tag "td" from line 73 */; ?>
<td>Xóa</td>
										</tr>
										<?php /* tag "tr" from line 75 */; ?>
<tr>
											<?php /* tag "td" from line 76 */; ?>
<td align="center"><?php echo phptal_escape($ctx->CartId); ?>
</td>
											<?php /* tag "td" from line 77 */; ?>
<td align="center" class="sim"><?php echo phptal_escape($ctx->CartFormatNumber); ?>
</td>							
											<?php /* tag "td" from line 78 */; ?>
<td align="center"><?php /* tag "span" from line 78 */; ?>
<span><?php echo phptal_escape($ctx->CartPrice); ?>
</span><?php /* tag "sup" from line 78 */; ?>
<sup>vnđ</sup>											
											</td>							
											<?php /* tag "td" from line 80 */; ?>
<td id="remove16573" align="center">
												<?php 
/* tag "a" from line 81 */ ;
if (null !== ($_tmp_1 = ($ctx->CartDeleteLinked))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a title="Xóa sim này"<?php echo $_tmp_1 ?>
>
													<?php /* tag "img" from line 82 */; ?>
<img alt="Xóa sim này" src="../Template/images/cartremove.png"/>
												</a>
											</td>
										</tr>
										<?php /* tag "tr" from line 86 */; ?>
<tr style="font-weight:bold;color:red">
											<?php /* tag "td" from line 87 */; ?>
<td align="right" colspan="3">Tổng cộng: </td>
											<?php /* tag "td" from line 88 */; ?>
<td align="center">								
												<?php /* tag "span" from line 89 */; ?>
<span><?php echo phptal_escape($ctx->CartPrice); ?>
</span><?php /* tag "sup" from line 89 */; ?>
<sup>vnđ</sup>
											</td>											
										</tr>
									</table>
								</span>								
								<?php /* tag "span" from line 94 */; ?>
<span id="cartaction">
									<?php /* tag "div" from line 95 */; ?>
<div id="formTieude">Thông tin:</div>
									<?php /* tag "div" from line 96 */; ?>
<div style="color:red" id="error"></div>
									<?php /* tag "ol" from line 97 */; ?>
<ol>
										
										<?php /* tag "li" from line 99 */; ?>
<li>
											<?php /* tag "label" from line 100 */; ?>
<label>Họ tên:</label>
											<?php /* tag "input" from line 101 */; ?>
<input id="ordername" type="text" value="" name="payhoten"/>&nbsp;<?php /* tag "font" from line 101 */; ?>
<font color="red">(*)</font>
										</li>
										
										<?php /* tag "li" from line 104 */; ?>
<li>
											<?php /* tag "label" from line 105 */; ?>
<label>Số điện thoại:</label>
											<?php /* tag "input" from line 106 */; ?>
<input id="paydienthoai" type="text" value="" name="paydienthoai"/>&nbsp;<?php /* tag "font" from line 106 */; ?>
<font color="red">(*)</font>
										</li>
										
										<?php /* tag "li" from line 109 */; ?>
<li>
											<?php /* tag "label" from line 110 */; ?>
<label>Email:</label>
											<?php /* tag "input" from line 111 */; ?>
<input id="payemail" type="text" value="" name="payemail"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</li>
										
									</ol>
									
									<?php /* tag "div" from line 116 */; ?>
<div id="formTieude">Địa chỉ:</div>
									
									<?php /* tag "ol" from line 118 */; ?>
<ol>
										<?php /* tag "li" from line 119 */; ?>
<li>
												<?php /* tag "label" from line 120 */; ?>
<label>Tỉnh thành:</label>
												<?php /* tag "select" from line 121 */; ?>
<select style="width: 210px;" name="cboTinhThanh" id="cboTinhThanh">
													<?php /* tag "option" from line 122 */; ?>
<option label="Hồ Chí Minh" value="Hồ Chí Minh">Hồ Chí Minh</option>
													<?php /* tag "option" from line 123 */; ?>
<option label="Hà Nội" value="Hà Nội">Hà Nội</option>
													<?php /* tag "option" from line 124 */; ?>
<option label="Hải Phòng" value="Hải Phòng">Hải Phòng</option>
													<?php /* tag "option" from line 125 */; ?>
<option label="Thừa Thiên-Huế" value="Thừa Thiên-Huế">Thừa Thiên-Huế</option>
													<?php /* tag "option" from line 126 */; ?>
<option label="Đà Nẵng" value="Đà Nẵng">Đà Nẵng</option>
													<?php /* tag "option" from line 127 */; ?>
<option label="Cần Thơ" value="Cần Thơ">Cần Thơ</option>
													<?php /* tag "option" from line 128 */; ?>
<option label="An Giang" value="An Giang">An Giang</option>
													<?php /* tag "option" from line 129 */; ?>
<option label="BR - Vũng Tàu" value="BR - Vũng Tàu">BR - Vũng Tàu</option>
													<?php /* tag "option" from line 130 */; ?>
<option label="Bắc Cạn" value="Bắc Cạn">Bắc Cạn</option>
													<?php /* tag "option" from line 131 */; ?>
<option label="Bắc Giang" value="Bắc Giang">Bắc Giang</option>
													<?php /* tag "option" from line 132 */; ?>
<option label="Bạc Liêu" value="Bạc Liêu">Bạc Liêu</option>
													<?php /* tag "option" from line 133 */; ?>
<option label="Bắc Ninh" value="Bắc Ninh">Bắc Ninh</option>
													<?php /* tag "option" from line 134 */; ?>
<option label="Bến Tre" value="Bến Tre">Bến Tre</option>
													<?php /* tag "option" from line 135 */; ?>
<option label="Bình Định" value="Bình Định">Bình Định</option>
													<?php /* tag "option" from line 136 */; ?>
<option label="Bình Dương" value="Bình Dương">Bình Dương</option>
													<?php /* tag "option" from line 137 */; ?>
<option label="Bình Phước" value="Bình Phước">Bình Phước</option>
													<?php /* tag "option" from line 138 */; ?>
<option label="Bình Thuận" value="Bình Thuận">Bình Thuận</option>
													<?php /* tag "option" from line 139 */; ?>
<option label="Cà Mau" value="Cà Mau">Cà Mau</option>
													<?php /* tag "option" from line 140 */; ?>
<option label="Cao Bằng" value="Cao Bằng">Cao Bằng</option>
													<?php /* tag "option" from line 141 */; ?>
<option label="Đắk Lắk" value="Đắk Lắk">Đắk Lắk</option>
													<?php /* tag "option" from line 142 */; ?>
<option label="Đắk Nông" value="Đắk Nông">Đắk Nông</option>
													<?php /* tag "option" from line 143 */; ?>
<option label="Điện Biên" value="Điện Biên">Điện Biên</option>
													<?php /* tag "option" from line 144 */; ?>
<option label="Đồng Nai" value="Đồng Nai">Đồng Nai</option>
													<?php /* tag "option" from line 145 */; ?>
<option label="Đồng Tháp" value="Đồng Tháp">Đồng Tháp</option>
													<?php /* tag "option" from line 146 */; ?>
<option label="Gia Lai" value="Gia Lai">Gia Lai</option>
													<?php /* tag "option" from line 147 */; ?>
<option label="Hà Giang" value="Hà Giang">Hà Giang</option>
													<?php /* tag "option" from line 148 */; ?>
<option label="Hà Nam" value="Hà Nam">Hà Nam</option>
													<?php /* tag "option" from line 149 */; ?>
<option label="Hà Tĩnh" value="Hà Tĩnh">Hà Tĩnh</option>
													<?php /* tag "option" from line 150 */; ?>
<option label="Hải Dương" value="Hải Dương">Hải Dương</option>
													<?php /* tag "option" from line 151 */; ?>
<option label="Hậu Giang" value="Hậu Giang">Hậu Giang</option>
													<?php /* tag "option" from line 152 */; ?>
<option label="Hòa Bình" value="Hòa Bình">Hòa Bình</option>
													<?php /* tag "option" from line 153 */; ?>
<option label="Hưng Yên" value="Hưng Yên">Hưng Yên</option>
													<?php /* tag "option" from line 154 */; ?>
<option label="Khánh Hòa" value="Khánh Hòa">Khánh Hòa</option>
													<?php /* tag "option" from line 155 */; ?>
<option label="Kiên Giang" value="Kiên Giang">Kiên Giang</option>
													<?php /* tag "option" from line 156 */; ?>
<option label="Kon Tum" value="Kon Tum">Kon Tum</option>
													<?php /* tag "option" from line 157 */; ?>
<option label="Lai Châu" value="Lai Châu">Lai Châu</option>
													<?php /* tag "option" from line 158 */; ?>
<option label="Lâm Đồng" value="Lâm Đồng">Lâm Đồng</option>
													<?php /* tag "option" from line 159 */; ?>
<option label="Lạng Sơn" value="Lạng Sơn">Lạng Sơn</option>
													<?php /* tag "option" from line 160 */; ?>
<option label="Lào Cai" value="Lào Cai">Lào Cai</option>
													<?php /* tag "option" from line 161 */; ?>
<option label="Long An" value="Long An">Long An</option>
													<?php /* tag "option" from line 162 */; ?>
<option label="Nam Định" value="Nam Định">Nam Định</option>
													<?php /* tag "option" from line 163 */; ?>
<option label="Nghệ An" value="Nghệ An">Nghệ An</option>
													<?php /* tag "option" from line 164 */; ?>
<option label="Ninh Bình" value="Ninh Bình">Ninh Bình</option>
													<?php /* tag "option" from line 165 */; ?>
<option label="Ninh Thuận" value="Ninh Thuận">Ninh Thuận</option>
													<?php /* tag "option" from line 166 */; ?>
<option label="Phú Thọ" value="Phú Thọ">Phú Thọ</option>
													<?php /* tag "option" from line 167 */; ?>
<option label="Phú Yên" value="Phú Yên">Phú Yên</option>
													<?php /* tag "option" from line 168 */; ?>
<option label="Quảng Bình" value="Quảng Bình">Quảng Bình</option>
													<?php /* tag "option" from line 169 */; ?>
<option label="Quảng Nam" value="Quảng Nam">Quảng Nam</option>
													<?php /* tag "option" from line 170 */; ?>
<option label="Quảng Ngãi" value="Quảng Ngãi">Quảng Ngãi</option>
													<?php /* tag "option" from line 171 */; ?>
<option label="Quảng Ninh" value="Quảng Ninh">Quảng Ninh</option>
													<?php /* tag "option" from line 172 */; ?>
<option label="Quảng Trị" value="Quảng Trị">Quảng Trị</option>
													<?php /* tag "option" from line 173 */; ?>
<option label="Sóc Trăng" value="Sóc Trăng">Sóc Trăng</option>
													<?php /* tag "option" from line 174 */; ?>
<option label="Sơn La" value="Sơn La">Sơn La</option>
													<?php /* tag "option" from line 175 */; ?>
<option label="Tây Ninh" value="Tây Ninh">Tây Ninh</option>
													<?php /* tag "option" from line 176 */; ?>
<option label="Thái Bình" value="Thái Bình">Thái Bình</option>
													<?php /* tag "option" from line 177 */; ?>
<option label="Thái Nguyên" value="Thái Nguyên">Thái Nguyên</option>
													<?php /* tag "option" from line 178 */; ?>
<option label="Thanh Hóa" value="Thanh Hóa">Thanh Hóa</option>
													<?php /* tag "option" from line 179 */; ?>
<option label="Tiền Giang" value="Tiền Giang">Tiền Giang</option>
													<?php /* tag "option" from line 180 */; ?>
<option label="Trà Vinh" value="Trà Vinh">Trà Vinh</option>
													<?php /* tag "option" from line 181 */; ?>
<option label="Tuyên Quang" value="Tuyên Quang">Tuyên Quang</option>
													<?php /* tag "option" from line 182 */; ?>
<option label="Vĩnh Long" value="Vĩnh Long">Vĩnh Long</option>
													<?php /* tag "option" from line 183 */; ?>
<option label="Vĩnh Phúc" value="Vĩnh Phúc">Vĩnh Phúc</option>
													<?php /* tag "option" from line 184 */; ?>
<option label="Yên Bái" value="Yên Bái">Yên Bái</option>
												</select>&nbsp;<?php /* tag "font" from line 185 */; ?>
<font color="red">(*)</font>
											</li>
										
											<?php /* tag "li" from line 188 */; ?>
<li>
												<?php /* tag "label" from line 189 */; ?>
<label>Quận/Huyện:</label>
												<?php /* tag "input" from line 190 */; ?>
<input type="text" name="cboQuanHuyen" id="cboQuanHuyen"/>&nbsp;<?php /* tag "font" from line 190 */; ?>
<font color="red">(*)</font>
											</li>
																																	
											<?php /* tag "li" from line 193 */; ?>
<li>
												<?php /* tag "label" from line 194 */; ?>
<label>Số nhà – tên đường:</label>
												<?php /* tag "input" from line 195 */; ?>
<input type="text" name="DiaChiGiaoHang" id="DiaChiGiaoHang"/>&nbsp;<?php /* tag "font" from line 195 */; ?>
<font color="red">(*)</font>
											</li>										
										<?php /* tag "li" from line 197 */; ?>
<li>
											<?php /* tag "label" from line 198 */; ?>
<label>Tin nhắn của bạn:</label>
											<?php /* tag "textarea" from line 199 */; ?>
<textarea rows="7" cols="30" name="payghichu"></textarea>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										</li>
										
										<?php /* tag "li" from line 202 */; ?>
<li>
											<?php /* tag "label" from line 203 */; ?>
<label>Mã xác nhận:</label>
											<?php /* tag "img" from line 204 */; ?>
<img align="left" id="imgCaptcha" src="create_image.php"/>
											<?php /* tag "input" from line 205 */; ?>
<input id="txtCaptcha" type="text" name="txtCaptcha" value="" maxlength="10" size="32"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;																						
										</li>
										
										<?php /* tag "li" from line 208 */; ?>
<li id="send">
											<?php /* tag "button" from line 209 */; ?>
<button class="send1" type="submit" onclick="return CheckSubmit();">Đặt hàng</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php /* tag "button" from line 209 */; ?>
<button class="send2" type="reset">Nhập lại</button>
										</li>
									
									</ol>
								</span>
							</form>
						</td>
					</tr>
				</table>
				<?php /* tag "div" from line 218 */; ?>
<div style="text-align: left; margin: 0 15px 0 15px; color: blue;">
					<?php /* tag "p" from line 219 */; ?>
<p style="padding-bottom: 5px;"><?php /* tag "b" from line 219 */; ?>
<b><?php /* tag "u" from line 219 */; ?>
<u>Ghi chú</u>:</b></p><?php /* tag "br" from line 219 */; ?>
<br/>
					<?php /* tag "p" from line 220 */; ?>
<p style="padding-bottom: 5px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- (Quý khách chú ý !) Những đơn đặt hàng cần phải điền đầy đủ thông tin cần thiết <?php /* tag "font" from line 220 */; ?>
<font color="red">(*)</font> và được viết bằng tiếng việt có dấu là những đơn đặt hàng chính xác.</p><?php /* tag "br" from line 220 */; ?>
<br/>
					<?php /* tag "p" from line 221 */; ?>
<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Việc đặt hàng qua website gặp khó khăn quý khách hãy gọi <?php /* tag "font" from line 221 */; ?>
<font color="red"><?php /* tag "b" from line 221 */; ?>
<b>0989.88.78.78 - 0977.666.098</b></font> để đặt mua sim qua điện thoại !</p><?php /* tag "br" from line 221 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 224 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 225 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3', $_thistpl) ;
$ctx->popSlots() ;
?>
 
				<?php /* tag "div" from line 226 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 227 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 227 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 227 */; ?>
<br/>
					<?php /* tag "a" from line 228 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 228 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 228 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 231 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 233 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 234 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
			
		<?php /* tag "div" from line 235 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/GioHang.html (edit that file instead) */; ?>