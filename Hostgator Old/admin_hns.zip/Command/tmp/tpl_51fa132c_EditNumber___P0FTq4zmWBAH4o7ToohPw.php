<?php 
function tpl_51fa132c_EditNumber___P0FTq4zmWBAH4o7ToohPw(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
	
</head>
<?php /* tag "script" from line 15 */; ?>
<script type="text/javascript">
			$(document).ready(
				function(){								
					$("select[name='idCategory_'] option ").each(function (index, mOption) {												
						if ($(mOption).attr("value") == $("#currentIdCategory").val())
						{							
							$("select[name='idCategory_'] option[value="+ $(mOption).attr("value") +"]").attr("selected", true);		
						}						
					});
					
					$("#idCategory_").change(function () {																		
							
							$("#currentIdCategory").val($("select[name='idCategory_'] option:selected").val());
								
					});
			});			
		</script>
<?php /* tag "body" from line 32 */; ?>
<body>
	<?php /* tag "div" from line 33 */; ?>
<div id="frame">
		<?php /* tag "div" from line 34 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 35 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuDatsim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 36 */; ?>
<div id="main">
			<?php /* tag "div" from line 37 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 38 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
		<?php /* tag "div" from line 40 */; ?>
<div id="main3_of2_height">				
					<?php /* tag "div" from line 41 */; ?>
<div id="tieude_main">Cập nhật thông tin sim số</div>
					<?php /* tag "table" from line 42 */; ?>
<table width="100%">							
							<?php 
/* tag "tr" from line 43 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Phone = new PHPTAL_RepeatController($ctx->PhoneNumber)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Phone as $ctx->Phone): ;
?>
<tr>
								<?php /* tag "td" from line 44 */; ?>
<td align="center">
								<?php /* tag "form" from line 45 */; ?>
<form id="form_LH" method="post" action="../../Command/editnumber.php">
									<?php /* tag "ol" from line 46 */; ?>
<ol>											
										<?php /* tag "li" from line 47 */; ?>
<li>
											<?php /* tag "label" from line 48 */; ?>
<label>Số Ðiện Thoại:</label>
											<?php 
/* tag "input" from line 49 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Phone, 'number')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input id="text" type="text" name="phonenumber"<?php echo $_tmp_2 ?>
/>
										</li>											
										<?php /* tag "li" from line 51 */; ?>
<li>
											<?php /* tag "label" from line 52 */; ?>
<label>Cách đọc số:</label>
											<?php 
/* tag "input" from line 53 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Phone, 'formatnumber')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input id="text" type="text" name="phoneformatnumber"<?php echo $_tmp_2 ?>
/>
										</li>
										<?php /* tag "li" from line 55 */; ?>
<li>						
											<?php /* tag "label" from line 56 */; ?>
<label>Loại Sim:</label>											
												<?php /* tag "select" from line 57 */; ?>
<select style="width: 210px;" id="idCategory_" name="idCategory_">
													<?php 
/* tag "option" from line 58 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->Category = new PHPTAL_RepeatController($ctx->Categorys)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->Category as $ctx->Category): ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Category, 'id')))):  ;
$_tmp_3 = ' value="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<option<?php echo $_tmp_3 ?>
><?php echo phptal_escape($ctx->path($ctx->Category, 'name')); ?>
</option><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

												</select>
										</li>											
										<?php /* tag "li" from line 61 */; ?>
<li>						
											<?php /* tag "label" from line 62 */; ?>
<label>Giá bán</label>
											<?php 
/* tag "input" from line 63 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Phone, 'price')))):  ;
$_tmp_3 = ' value="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<input id="text" type="text" name="phoneprice"<?php echo $_tmp_3 ?>
/>
										</li>
										<?php /* tag "li" from line 65 */; ?>
<li>						
											<?php /* tag "label" from line 66 */; ?>
<label>Trạng thái:</label>									
											<?php /* tag "select" from line 67 */; ?>
<select style="width: 210px;" id="phonestate" name="phonestate">
												<?php /* tag "option" from line 68 */; ?>
<option value="0">Chưa Bán</option>
												<?php /* tag "option" from line 69 */; ?>
<option value="1">Đã Bán</option>
											</select>
										</li>									
										<?php /* tag "li" from line 72 */; ?>
<li id="send">
												<?php /* tag "button" from line 73 */; ?>
<button type="submit">Cập nhật</button>
												<?php 
/* tag "a" from line 74 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Phone, 'getHotNumberLinked')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>Đưa vào DS Sim mới về</a>
										</li>
									</ol>
									<?php 
/* tag "input" from line 77 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Phone, 'idcategory')))):  ;
$_tmp_3 = ' value="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<input type="hidden" size="40" id="currentIdCategory" name="currentIdCategory"<?php echo $_tmp_3 ?>
/>
									<?php 
/* tag "input" from line 78 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Phone, 'id')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input type="hidden" size="40" id="currentIdNumber" name="currentIdNumber"<?php echo $_tmp_2 ?>
/>							
								</form>	
								</td>
							</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

					</table>									
			</div>
			<?php /* tag "div" from line 84 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 85 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin11', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 86 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 87 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 87 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 87 */; ?>
<br/>
					<?php /* tag "a" from line 88 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 88 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 88 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 91 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 93 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 94 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
			
		<?php /* tag "div" from line 95 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/EditNumber.html (edit that file instead) */; ?>