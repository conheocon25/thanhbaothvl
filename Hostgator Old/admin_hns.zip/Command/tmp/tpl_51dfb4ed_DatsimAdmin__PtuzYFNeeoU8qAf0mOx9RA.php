<?php 
function tpl_51dfb4ed_DatsimAdmin__PtuzYFNeeoU8qAf0mOx9RA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	<?php /* tag "script" from line 9 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/main.js"></script>
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
</head>
<?php /* tag "script" from line 14 */; ?>
<script>
/*<![CDATA[*/
$(document).ready(function() {	
	
});		
	function CheckSubmit()
	{
		check = false;
		check = checkTextNull($('#ordername'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");			
		if (check == true)
		{
			check = checkPhoneNumber($('#Phone'), $('#error'),"Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
			if (check == true)
			{
				check = checkEmail($('#Email'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
				if (check == true)
				{
					check = checkPhoneNumber($('#Sim'), $('#error'),"Điền thiếu thông tin xin vui lòng ghi thêm mục này!");			
					if (check == true)
					{
						check = checkTextNull($('#cboQuanHuyen'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
						if (check == true)
						{
							check = checkTextNull($('#cboQuanHuyen'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
							if (check == true)
							{
								check = checkTextNull($('#DiaChiGiaoHang'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
								if (check == true)
								{
									check = checkTextNull($('#txtCaptcha'), $('#error'), "Điền thiếu thông tin xin vui lòng ghi thêm mục này!");
									return check;									
								}else{return false;}
							}else{return false;}
						}else{return false;}
					}else{return false;}
				}else{return false;}
			}else{return false;}
		}else{return false;}		
	}
/*]]>*/
</script>
<?php /* tag "body" from line 55 */; ?>
<body>
	<?php /* tag "div" from line 56 */; ?>
<div id="frame">
		<?php /* tag "div" from line 57 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 58 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuDatsim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 59 */; ?>
<div id="main">
			<?php /* tag "div" from line 60 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 61 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 63 */; ?>
<div id="main3_of2" style="height: 1297px;">
				<?php /* tag "div" from line 64 */; ?>
<div id="tieude_main">Thông tin đặt hàng</div>
					<?php /* tag "p" from line 65 */; ?>
<p>- <?php /* tag "font" from line 65 */; ?>
<font color="red"><?php /* tag "b" from line 65 */; ?>
<b>Bạn tìm số mình thích, bạn rất bận ….</b></font></p>
					<?php /* tag "p" from line 66 */; ?>
<p>- <?php /* tag "b" from line 66 */; ?>
<b>Bạn không có thời gian ngồi bên cạnh máy vi tính để tìm sim số đẹp theo ý mình?</b></p>
					<?php /* tag "p" from line 67 */; ?>
<p>- Chúng tôi sẽ giúp bạn công việc đó.</p>
					<?php /* tag "p" from line 68 */; ?>
<p>- Bạn hãy điền yêu cầu theo mẫu bên dưới. Chúng tôi sẽ tìm giúp Bạn !</p>

					<?php /* tag "table" from line 70 */; ?>
<table width="100%">
						<?php /* tag "tr" from line 71 */; ?>
<tr>
							<?php /* tag "td" from line 72 */; ?>
<td align="center">
								<?php /* tag "form" from line 73 */; ?>
<form id="form_LH" method="post" action="../../Command/datsim.php">
									<?php /* tag "input" from line 74 */; ?>
<input name="orderdate" type="hidden" id="orderdate"/>

										<?php /* tag "div" from line 76 */; ?>
<div id="formTieude">Thông tin:</div>

										<?php /* tag "ol" from line 78 */; ?>
<ol>
											
											<?php /* tag "li" from line 80 */; ?>
<li>
												<?php /* tag "label" from line 81 */; ?>
<label>Họ tên:</label>
												<?php /* tag "input" from line 82 */; ?>
<input id="ordername name" type="text" value="" name="ordername"/>&nbsp;<?php /* tag "font" from line 82 */; ?>
<font color="red">(*)</font>
											</li>
											
											<?php /* tag "li" from line 85 */; ?>
<li>
												<?php /* tag "label" from line 86 */; ?>
<label>Số điện thoại:</label>
												<?php /* tag "input" from line 87 */; ?>
<input id="Phone" type="text" value="" name="orderphone"/>&nbsp;<?php /* tag "font" from line 87 */; ?>
<font color="red">(*)</font>
											</li>
											
											<?php /* tag "li" from line 90 */; ?>
<li>
												<?php /* tag "label" from line 91 */; ?>
<label>Email:</label>
												<?php /* tag "input" from line 92 */; ?>
<input id="Email" type="text" value="" name="orderemail"/>&nbsp;<?php /* tag "font" from line 92 */; ?>
<font color="red">(*)</font>
											</li>
											<?php /* tag "li" from line 94 */; ?>
<li>
												<?php /* tag "label" from line 95 */; ?>
<label>Số điện thoại cần đặt:</label>
												<?php /* tag "input" from line 96 */; ?>
<input id="Sim" type="text" value="" name="ordersimnumber"/>&nbsp;<?php /* tag "font" from line 96 */; ?>
<font color="red">(*)</font>
											</li>
											
										</ol>
										
										<?php /* tag "div" from line 101 */; ?>
<div id="formTieude">Địa chỉ:</div>
										
										<?php /* tag "ol" from line 103 */; ?>
<ol>
											<?php /* tag "li" from line 104 */; ?>
<li>
												<?php /* tag "label" from line 105 */; ?>
<label>Tỉnh thành:</label>
												<?php /* tag "select" from line 106 */; ?>
<select style="width: 210px;" name="cboTinhThanh" id="cboTinhThanh">
													<?php /* tag "option" from line 107 */; ?>
<option label="Hồ Chí Minh" value="Hồ Chí Minh">Hồ Chí Minh</option>
													<?php /* tag "option" from line 108 */; ?>
<option label="Hà Nội" value="Hà Nội">Hà Nội</option>
													<?php /* tag "option" from line 109 */; ?>
<option label="Hải Phòng" value="Hải Phòng">Hải Phòng</option>
													<?php /* tag "option" from line 110 */; ?>
<option label="Thừa Thiên-Huế" value="Thừa Thiên-Huế">Thừa Thiên-Huế</option>
													<?php /* tag "option" from line 111 */; ?>
<option label="Đà Nẵng" value="Đà Nẵng">Đà Nẵng</option>
													<?php /* tag "option" from line 112 */; ?>
<option label="Cần Thơ" value="Cần Thơ">Cần Thơ</option>
													<?php /* tag "option" from line 113 */; ?>
<option label="An Giang" value="An Giang">An Giang</option>
													<?php /* tag "option" from line 114 */; ?>
<option label="BR - Vũng Tàu" value="BR - Vũng Tàu">BR - Vũng Tàu</option>
													<?php /* tag "option" from line 115 */; ?>
<option label="Bắc Cạn" value="Bắc Cạn">Bắc Cạn</option>
													<?php /* tag "option" from line 116 */; ?>
<option label="Bắc Giang" value="Bắc Giang">Bắc Giang</option>
													<?php /* tag "option" from line 117 */; ?>
<option label="Bạc Liêu" value="Bạc Liêu">Bạc Liêu</option>
													<?php /* tag "option" from line 118 */; ?>
<option label="Bắc Ninh" value="Bắc Ninh">Bắc Ninh</option>
													<?php /* tag "option" from line 119 */; ?>
<option label="Bến Tre" value="Bến Tre">Bến Tre</option>
													<?php /* tag "option" from line 120 */; ?>
<option label="Bình Định" value="Bình Định">Bình Định</option>
													<?php /* tag "option" from line 121 */; ?>
<option label="Bình Dương" value="Bình Dương">Bình Dương</option>
													<?php /* tag "option" from line 122 */; ?>
<option label="Bình Phước" value="Bình Phước">Bình Phước</option>
													<?php /* tag "option" from line 123 */; ?>
<option label="Bình Thuận" value="Bình Thuận">Bình Thuận</option>
													<?php /* tag "option" from line 124 */; ?>
<option label="Cà Mau" value="Cà Mau">Cà Mau</option>
													<?php /* tag "option" from line 125 */; ?>
<option label="Cao Bằng" value="Cao Bằng">Cao Bằng</option>
													<?php /* tag "option" from line 126 */; ?>
<option label="Đắk Lắk" value="Đắk Lắk">Đắk Lắk</option>
													<?php /* tag "option" from line 127 */; ?>
<option label="Đắk Nông" value="Đắk Nông">Đắk Nông</option>
													<?php /* tag "option" from line 128 */; ?>
<option label="Điện Biên" value="Điện Biên">Điện Biên</option>
													<?php /* tag "option" from line 129 */; ?>
<option label="Đồng Nai" value="Đồng Nai">Đồng Nai</option>
													<?php /* tag "option" from line 130 */; ?>
<option label="Đồng Tháp" value="Đồng Tháp">Đồng Tháp</option>
													<?php /* tag "option" from line 131 */; ?>
<option label="Gia Lai" value="Gia Lai">Gia Lai</option>
													<?php /* tag "option" from line 132 */; ?>
<option label="Hà Giang" value="Hà Giang">Hà Giang</option>
													<?php /* tag "option" from line 133 */; ?>
<option label="Hà Nam" value="Hà Nam">Hà Nam</option>
													<?php /* tag "option" from line 134 */; ?>
<option label="Hà Tĩnh" value="Hà Tĩnh">Hà Tĩnh</option>
													<?php /* tag "option" from line 135 */; ?>
<option label="Hải Dương" value="Hải Dương">Hải Dương</option>
													<?php /* tag "option" from line 136 */; ?>
<option label="Hậu Giang" value="Hậu Giang">Hậu Giang</option>
													<?php /* tag "option" from line 137 */; ?>
<option label="Hòa Bình" value="Hòa Bình">Hòa Bình</option>
													<?php /* tag "option" from line 138 */; ?>
<option label="Hưng Yên" value="Hưng Yên">Hưng Yên</option>
													<?php /* tag "option" from line 139 */; ?>
<option label="Khánh Hòa" value="Khánh Hòa">Khánh Hòa</option>
													<?php /* tag "option" from line 140 */; ?>
<option label="Kiên Giang" value="Kiên Giang">Kiên Giang</option>
													<?php /* tag "option" from line 141 */; ?>
<option label="Kon Tum" value="Kon Tum">Kon Tum</option>
													<?php /* tag "option" from line 142 */; ?>
<option label="Lai Châu" value="Lai Châu">Lai Châu</option>
													<?php /* tag "option" from line 143 */; ?>
<option label="Lâm Đồng" value="Lâm Đồng">Lâm Đồng</option>
													<?php /* tag "option" from line 144 */; ?>
<option label="Lạng Sơn" value="Lạng Sơn">Lạng Sơn</option>
													<?php /* tag "option" from line 145 */; ?>
<option label="Lào Cai" value="Lào Cai">Lào Cai</option>
													<?php /* tag "option" from line 146 */; ?>
<option label="Long An" value="Long An">Long An</option>
													<?php /* tag "option" from line 147 */; ?>
<option label="Nam Định" value="Nam Định">Nam Định</option>
													<?php /* tag "option" from line 148 */; ?>
<option label="Nghệ An" value="Nghệ An">Nghệ An</option>
													<?php /* tag "option" from line 149 */; ?>
<option label="Ninh Bình" value="Ninh Bình">Ninh Bình</option>
													<?php /* tag "option" from line 150 */; ?>
<option label="Ninh Thuận" value="Ninh Thuận">Ninh Thuận</option>
													<?php /* tag "option" from line 151 */; ?>
<option label="Phú Thọ" value="Phú Thọ">Phú Thọ</option>
													<?php /* tag "option" from line 152 */; ?>
<option label="Phú Yên" value="Phú Yên">Phú Yên</option>
													<?php /* tag "option" from line 153 */; ?>
<option label="Quảng Bình" value="Quảng Bình">Quảng Bình</option>
													<?php /* tag "option" from line 154 */; ?>
<option label="Quảng Nam" value="Quảng Nam">Quảng Nam</option>
													<?php /* tag "option" from line 155 */; ?>
<option label="Quảng Ngãi" value="Quảng Ngãi">Quảng Ngãi</option>
													<?php /* tag "option" from line 156 */; ?>
<option label="Quảng Ninh" value="Quảng Ninh">Quảng Ninh</option>
													<?php /* tag "option" from line 157 */; ?>
<option label="Quảng Trị" value="Quảng Trị">Quảng Trị</option>
													<?php /* tag "option" from line 158 */; ?>
<option label="Sóc Trăng" value="Sóc Trăng">Sóc Trăng</option>
													<?php /* tag "option" from line 159 */; ?>
<option label="Sơn La" value="Sơn La">Sơn La</option>
													<?php /* tag "option" from line 160 */; ?>
<option label="Tây Ninh" value="Tây Ninh">Tây Ninh</option>
													<?php /* tag "option" from line 161 */; ?>
<option label="Thái Bình" value="Thái Bình">Thái Bình</option>
													<?php /* tag "option" from line 162 */; ?>
<option label="Thái Nguyên" value="Thái Nguyên">Thái Nguyên</option>
													<?php /* tag "option" from line 163 */; ?>
<option label="Thanh Hóa" value="Thanh Hóa">Thanh Hóa</option>
													<?php /* tag "option" from line 164 */; ?>
<option label="Tiền Giang" value="Tiền Giang">Tiền Giang</option>
													<?php /* tag "option" from line 165 */; ?>
<option label="Trà Vinh" value="Trà Vinh">Trà Vinh</option>
													<?php /* tag "option" from line 166 */; ?>
<option label="Tuyên Quang" value="Tuyên Quang">Tuyên Quang</option>
													<?php /* tag "option" from line 167 */; ?>
<option label="Vĩnh Long" value="Vĩnh Long">Vĩnh Long</option>
													<?php /* tag "option" from line 168 */; ?>
<option label="Vĩnh Phúc" value="Vĩnh Phúc">Vĩnh Phúc</option>
													<?php /* tag "option" from line 169 */; ?>
<option label="Yên Bái" value="Yên Bái">Yên Bái</option>
												</select>&nbsp;<?php /* tag "font" from line 170 */; ?>
<font color="red">(*)</font>
											</li>
										
											<?php /* tag "li" from line 173 */; ?>
<li>
												<?php /* tag "label" from line 174 */; ?>
<label>Quận/Huyện:</label>
												<?php /* tag "input" from line 175 */; ?>
<input type="text" name="cboQuanHuyen" id="cboQuanHuyen"/>&nbsp;<?php /* tag "font" from line 175 */; ?>
<font color="red">(*)</font>
											</li>
																																	
											<?php /* tag "li" from line 178 */; ?>
<li>
												<?php /* tag "label" from line 179 */; ?>
<label>Số nhà – tên đường:</label>
												<?php /* tag "input" from line 180 */; ?>
<input type="text" name="DiaChiGiaoHang" id="DiaChiGiaoHang"/>&nbsp;<?php /* tag "font" from line 180 */; ?>
<font color="red">(*)</font>
											</li>
											
											<?php /* tag "li" from line 183 */; ?>
<li>
												<?php /* tag "label" from line 184 */; ?>
<label>Tin nhắn của bạn:</label>
												<?php /* tag "textarea" from line 185 */; ?>
<textarea rows="7" cols="30" name="ordernote"></textarea>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
											</li>
											
											<?php /* tag "li" from line 188 */; ?>
<li>
												<?php /* tag "label" from line 189 */; ?>
<label>Mã xác nhận:</label>
												<?php /* tag "img" from line 190 */; ?>
<img id="imgCaptcha" src="create_image.php"/>
												<?php /* tag "input" from line 191 */; ?>
<input id="txtCaptcha" type="text" name="txtCaptcha" value="" maxlength="10" size="32"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
												
												<?php /* tag "div" from line 193 */; ?>
<div style="color:red" id="error"><?php echo phptal_escape($ctx->txterror); ?>
</div>
											</li>
											
											<?php /* tag "li" from line 196 */; ?>
<li id="send">
												<?php /* tag "button" from line 197 */; ?>
<button class="send1" type="submit" onclick="return CheckSubmit();">Đặt hàng</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php /* tag "button" from line 197 */; ?>
<button class="send2" type="reset">Nhập lại</button>
											</li>
										
										</ol>
								</form>
							</td>
						</tr>
					</table>  
			</div>
			<?php /* tag "div" from line 206 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 207 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 208 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 209 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 209 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 209 */; ?>
<br/>
					<?php /* tag "a" from line 210 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 210 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 210 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 213 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 215 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 216 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 217 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/DatsimAdmin.html (edit that file instead) */; ?>