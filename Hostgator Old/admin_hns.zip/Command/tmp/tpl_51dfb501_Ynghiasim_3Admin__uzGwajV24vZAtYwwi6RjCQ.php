<?php 
function tpl_51dfb501_Ynghiasim_3Admin__uzGwajV24vZAtYwwi6RjCQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
</head>
<?php /* tag "body" from line 8 */; ?>
<body>
	<?php /* tag "div" from line 9 */; ?>
<div id="frame">
		<?php /* tag "div" from line 10 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuGioithieu', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 12 */; ?>
<div id="main">
			<?php /* tag "div" from line 13 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 16 */; ?>
<div id="main3_of2">
					<?php /* tag "div" from line 17 */; ?>
<div id="tieude_main">Ý nghĩa các con số theo quan niệm Dân Gian</div>
					<?php /* tag "div" from line 18 */; ?>
<div align="justify" style="margin-bottom: 80px; padding: 0 20px 0 20px;">
						<?php /* tag "p" from line 19 */; ?>
<p style="text-indent:25px;">- 3456 : Bạn bè nể sợ (B-B-N-S)</p><?php /* tag "br" from line 19 */; ?>
<br/>
						<?php /* tag "p" from line 20 */; ?>
<p style="text-indent:25px;">- 6789 : San bằng tất cả ( 6 - 7 - 8 - 9 : S - B - T - C ) hoặc Sống bằng tình cảm.</p><?php /* tag "br" from line 20 */; ?>
<br/>
						<?php /* tag "p" from line 21 */; ?>
<p style="text-indent:25px;">- 6789 : san bằng tất cả</p><?php /* tag "br" from line 21 */; ?>
<br/><?php /* tag "br" from line 21 */; ?>
<br/>
						<?php /* tag "p" from line 22 */; ?>
<p style="text-indent:25px;">- 1102 : độc nhất vô nhị</p><?php /* tag "br" from line 22 */; ?>
<br/>
						<?php /* tag "p" from line 23 */; ?>
<p style="text-indent:25px;">- 0378 : phong bao bão táp</p><?php /* tag "br" from line 23 */; ?>
<br/>
						<?php /* tag "p" from line 24 */; ?>
<p style="text-indent:25px;">- 3899 : phát tài mãi mãi</p><?php /* tag "br" from line 24 */; ?>
<br/>
						<?php /* tag "p" from line 25 */; ?>
<p style="text-indent:25px;">- 365078 : 1 năm 365 ngày không thất bát</p><?php /* tag "br" from line 25 */; ?>
<br/>
						<?php /* tag "p" from line 26 */; ?>
<p style="text-indent:25px;">- 4078 : bốn mùa không thất bát</p><?php /* tag "br" from line 26 */; ?>
<br/>
						<?php /* tag "p" from line 27 */; ?>
<p style="text-indent:25px;">- 6677028 : xấu xấu bẩn bẩn không ai tán</p><?php /* tag "br" from line 27 */; ?>
<br/><?php /* tag "br" from line 27 */; ?>
<br/>
						<?php /* tag "p" from line 28 */; ?>
<p style="text-indent:25px;">00 : trứng vịt</p><?php /* tag "br" from line 28 */; ?>
<br/>
						<?php /* tag "p" from line 29 */; ?>
<p style="text-indent:25px;">01 - 41 - 81 : con cá trắng</p><?php /* tag "br" from line 29 */; ?>
<br/>
						<?php /* tag "p" from line 30 */; ?>
<p style="text-indent:25px;">02 - 42 - 82 : ốc</p><?php /* tag "br" from line 30 */; ?>
<br/>
						<?php /* tag "p" from line 31 */; ?>
<p style="text-indent:25px;">03 - 43 - 83 : xác chết (con vịt)</p><?php /* tag "br" from line 31 */; ?>
<br/>
						<?php /* tag "p" from line 32 */; ?>
<p style="text-indent:25px;">04 - 44 - 84 : con công</p><?php /* tag "br" from line 32 */; ?>
<br/>
						<?php /* tag "p" from line 33 */; ?>
<p style="text-indent:25px;">05 - 45 - 85 : con trùng</p><?php /* tag "br" from line 33 */; ?>
<br/>
						<?php /* tag "p" from line 34 */; ?>
<p style="text-indent:25px;">06 - 46 - 86 : con cọp</p><?php /* tag "br" from line 34 */; ?>
<br/>
						<?php /* tag "p" from line 35 */; ?>
<p style="text-indent:25px;">07 - 47 - 87 : con heo</p><?php /* tag "br" from line 35 */; ?>
<br/>
						<?php /* tag "p" from line 36 */; ?>
<p style="text-indent:25px;">08 - 48 - 88 : con thỏ</p><?php /* tag "br" from line 36 */; ?>
<br/>
						<?php /* tag "p" from line 37 */; ?>
<p style="text-indent:25px;">09 - 49 - 89 : con trâu</p><?php /* tag "br" from line 37 */; ?>
<br/>
						<?php /* tag "p" from line 38 */; ?>
<p style="text-indent:25px;">10 - 50 - 90 : con rồng nằm</p><?php /* tag "br" from line 38 */; ?>
<br/>
						<?php /* tag "p" from line 39 */; ?>
<p style="text-indent:25px;">11 - 51 - 91 : con chó</p><?php /* tag "br" from line 39 */; ?>
<br/>
						<?php /* tag "p" from line 40 */; ?>
<p style="text-indent:25px;">12 - 52 - 92 : con ngựa</p><?php /* tag "br" from line 40 */; ?>
<br/>
						<?php /* tag "p" from line 41 */; ?>
<p style="text-indent:25px;">13 - 53 - 93 : con voi</p><?php /* tag "br" from line 41 */; ?>
<br/>
						<?php /* tag "p" from line 42 */; ?>
<p style="text-indent:25px;">14 - 54 - 94 : con mèo nhà</p><?php /* tag "br" from line 42 */; ?>
<br/>
						<?php /* tag "p" from line 43 */; ?>
<p style="text-indent:25px;">15 - 55 - 95 : con chuột</p><?php /* tag "br" from line 43 */; ?>
<br/>
						<?php /* tag "p" from line 44 */; ?>
<p style="text-indent:25px;">16 - 56 - 96 : con ong</p><?php /* tag "br" from line 44 */; ?>
<br/>
						<?php /* tag "p" from line 45 */; ?>
<p style="text-indent:25px;">17 - 57 - 97 : con hạc</p><?php /* tag "br" from line 45 */; ?>
<br/>
						<?php /* tag "p" from line 46 */; ?>
<p style="text-indent:25px;">18 - 58 - 98 : con mèo rừng</p><?php /* tag "br" from line 46 */; ?>
<br/>
						<?php /* tag "p" from line 47 */; ?>
<p style="text-indent:25px;">19 - 59 - 99 : con bướm</p><?php /* tag "br" from line 47 */; ?>
<br/>
						<?php /* tag "p" from line 48 */; ?>
<p style="text-indent:25px;">20 - 60 : con rết (con rít áh)</p><?php /* tag "br" from line 48 */; ?>
<br/>
						<?php /* tag "p" from line 49 */; ?>
<p style="text-indent:25px;">21 - 61 : Thuý Kiều</p><?php /* tag "br" from line 49 */; ?>
<br/>
						<?php /* tag "p" from line 50 */; ?>
<p style="text-indent:25px;">22 - 62 : bồ câu</p><?php /* tag "br" from line 50 */; ?>
<br/>
						<?php /* tag "p" from line 51 */; ?>
<p style="text-indent:25px;">23 - 63 : con khỉ</p><?php /* tag "br" from line 51 */; ?>
<br/>
						<?php /* tag "p" from line 52 */; ?>
<p style="text-indent:25px;">24 - 64 : con ếch</p><?php /* tag "br" from line 52 */; ?>
<br/>
						<?php /* tag "p" from line 53 */; ?>
<p style="text-indent:25px;">25 - 65 : con ó</p><?php /* tag "br" from line 53 */; ?>
<br/>
						<?php /* tag "p" from line 54 */; ?>
<p style="text-indent:25px;">26 - 66 : rồng bay</p><?php /* tag "br" from line 54 */; ?>
<br/>
						<?php /* tag "p" from line 55 */; ?>
<p style="text-indent:25px;">27 - 67 : con rùa</p><?php /* tag "br" from line 55 */; ?>
<br/>
						<?php /* tag "p" from line 56 */; ?>
<p style="text-indent:25px;">28 - 68 : con gà</p><?php /* tag "br" from line 56 */; ?>
<br/>
						<?php /* tag "p" from line 57 */; ?>
<p style="text-indent:25px;">29- 69: con lươn</p><?php /* tag "br" from line 57 */; ?>
<br/>
						<?php /* tag "p" from line 58 */; ?>
<p style="text-indent:25px;">30 - 70 : con cá đen</p><?php /* tag "br" from line 58 */; ?>
<br/>
						<?php /* tag "p" from line 59 */; ?>
<p style="text-indent:25px;">31 - 71 : con tôm</p><?php /* tag "br" from line 59 */; ?>
<br/>
						<?php /* tag "p" from line 60 */; ?>
<p style="text-indent:25px;">32 - 72 : con rắn</p><?php /* tag "br" from line 60 */; ?>
<br/>
						<?php /* tag "p" from line 61 */; ?>
<p style="text-indent:25px;">33 - 73 : con nhện</p><?php /* tag "br" from line 61 */; ?>
<br/>
						<?php /* tag "p" from line 62 */; ?>
<p style="text-indent:25px;">34 - 74 : con nai</p><?php /* tag "br" from line 62 */; ?>
<br/>
						<?php /* tag "p" from line 63 */; ?>
<p style="text-indent:25px;">35 - 75 : con dê</p><?php /* tag "br" from line 63 */; ?>
<br/>
						<?php /* tag "p" from line 64 */; ?>
<p style="text-indent:25px;">36 - 76 : bà vải</p><?php /* tag "br" from line 64 */; ?>
<br/>
						<?php /* tag "p" from line 65 */; ?>
<p style="text-indent:25px;">37 - 77 : ông trời</p><?php /* tag "br" from line 65 */; ?>
<br/>
						<?php /* tag "p" from line 66 */; ?>
<p style="text-indent:25px;">38 - 78 : ông địa</p><?php /* tag "br" from line 66 */; ?>
<br/>
						<?php /* tag "p" from line 67 */; ?>
<p style="text-indent:25px;">39 - 79 : thần tài</p><?php /* tag "br" from line 67 */; ?>
<br/>
						<?php /* tag "p" from line 68 */; ?>
<p style="text-indent:25px;">40 - 80 : ông táo</p><?php /* tag "br" from line 68 */; ?>
<br/>
						<?php /* tag "p" from line 69 */; ?>
<p style="text-indent:25px;">- Chỉ điểm qua một chút thôi, nhưng hẳn các bạn đã thấy là có rất nhiều kiểu “Chơi SIM Số”. Thú “Chơi sim số đẹp” không dừng ở trong khuôn khổ là 1 quy tắc nhất định nào đó mà nó là muôn hình vạn trạng; nếu đã “Chơi sim số đẹp” thì mới biết có được một con sim số đẹp hợp ý nó vất vả và sung sướng thế nào</p><?php /* tag "br" from line 69 */; ?>
<br/>
					</div>
					<?php 
/* tag "span" from line 71 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuXemThem', $_thistpl) ;
$ctx->popSlots() ;
?>
 
					<?php /* tag "br" from line 72 */; ?>
<br/>					
			</div>
			<?php /* tag "div" from line 74 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 75 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 76 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 77 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 77 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 77 */; ?>
<br/>
					<?php /* tag "a" from line 78 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 78 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 78 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 81 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 83 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 84 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
	
		<?php /* tag "div" from line 85 */; ?>
<div class="vide"></div>	
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/Ynghiasim_3Admin.html (edit that file instead) */; ?>