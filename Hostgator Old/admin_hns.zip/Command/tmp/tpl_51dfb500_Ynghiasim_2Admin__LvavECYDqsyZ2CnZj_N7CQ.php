<?php 
function tpl_51dfb500_Ynghiasim_2Admin__LvavECYDqsyZ2CnZj_N7CQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
</head>
<?php /* tag "body" from line 8 */; ?>
<body>
	<?php /* tag "div" from line 9 */; ?>
<div id="frame">
		<?php /* tag "div" from line 10 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuGioithieu', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 12 */; ?>
<div id="main">
			<?php /* tag "div" from line 13 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 16 */; ?>
<div id="main3_of2">
					<?php /* tag "div" from line 17 */; ?>
<div id="tieude_main">Ý nghĩa của các con số!</div>
					<?php /* tag "div" from line 18 */; ?>
<div align="justify" style="margin-bottom: 80px; padding: 0 20px 0 20px;">
						<?php /* tag "p" from line 19 */; ?>
<p style="text-indent:30px;">(*) Mỗi con số đều mang một ý nghĩa của nó, mỗi người trong chúng ta đều yêu thích và gắn liền với một số nhất định, như số 1 khởi đầu, số 6 là lộc số 3 tài, số 8 phát, số 9 là trường cửu!</p><?php /* tag "br" from line 19 */; ?>
<br/>
						<?php /* tag "b" from line 20 */; ?>
<b>Số Một (1)</b>
						<?php /* tag "p" from line 21 */; ?>
<p style="text-indent:30px;">Là con số của các vị thần thánh, của hoành đồ, được hiểu như là con trai của cõi trời. Số một tượng trưng cái đỉnh tối thượng, đỉnh núi cao – độc nhất không còn ai khác nữa. Chúng ta, con người không thể nắm giữ vị trí này lâu dài, vì nó có thể đơn độc và hiểm nghèo, bởi chúng ta không phải là thần thánh. Chỉ có thần thánh mới có thể nắm giữ vị trí này mãi mãi</p><?php /* tag "br" from line 21 */; ?>
<br/>
						<?php /* tag "b" from line 22 */; ?>
<b>Số hai (2)</b>
						<?php /* tag "p" from line 23 */; ?>
<p style="text-indent:30px;">Tượng trưng là một cặp, một đôi, một con số hạnh phúc (song hỷ) và điều hành thuận lợi cho những sự kiện như sinh nhật, cưới hỏi, hội hè. Số hai tượng trưng sự cân bằng âm dương kết hợp tạo thành thái lưu hay là nguồn gốc của vạn vật. Các câu đối đỏ may mắn thường được dán trước cửa nhà cổng chính vào dịp đầu năm mới.</p><?php /* tag "br" from line 23 */; ?>
<br/>
						<?php /* tag "b" from line 24 */; ?>
<b>Số ba (3)</b>
						<?php /* tag "p" from line 25 */; ?>
<p style="text-indent:30px;">Được xem là con số vững chắc, như kiếng ba chân là một hình thức vững chắc nhất. Người Trung Quốc có câu “ba với ba là mãi mãi” (bất tận) và biểu tượng hy vọng trường thọ. Phong thủy dùng nhiều lĩnh vực số học trong việc bài trí các đồ vật và con số ba là con số đặc biệt hữu dụng cho việc tăng thêm vẻ vững chắc khi đập mắt vào và sự hài hòa của một môi trường.</p><?php /* tag "br" from line 25 */; ?>
<br/>
						<?php /* tag "b" from line 26 */; ?>
<b>Số bốn (4)</b>
						<?php /* tag "p" from line 27 */; ?>
<p style="text-indent:30px;">Là sự hình thành của hai đôi. Hai cặp chắc hẳn phải tốt lành, thuận lợi nhưng trong cách phát âm tiếng Trung Quốc nó giống như chữ “tử” (chết). Vì thế sự kết hợp này không được tốt đẹp lắm. Thuật phong thủy tìm cách tránh bất cứ sự bài trí có liên quan đến con số bốn.</p><?php /* tag "br" from line 27 */; ?>
<br/>
						<?php /* tag "b" from line 28 */; ?>
<b>Số năm (5)</b>
						<?php /* tag "p" from line 29 */; ?>
<p style="text-indent:30px;">Tượng trưng cho danh dự, uy quyền, quyền lực. Số năm còn có nghĩa là năm hướng (Bắc, Nam, Đông, Tây và Trung tâm) là năm ngọn núi thiêng liêng của Trung Quốc. Số năm tượng trưng cho trường thọ và bất diệt. Con số năm cũng là sự kết hợp với căn nhà bằng vàng, nắm giữ sự thịnh vượng và hạnh phúc cho mỗi gia đình. Số năm là một con số tuyệt vời dùng trong việc bài trí phong thủy.</p><?php /* tag "br" from line 29 */; ?>
<br/>
						<?php /* tag "b" from line 30 */; ?>
<b>Số sáu (6)</b>
						<?php /* tag "p" from line 31 */; ?>
<p style="text-indent:30px;">Là gấp đôi của số ba và như thế là điềm lành, thuận lợi. Ba cộng thêm sáu là chín và cùng nhau tạo thành nhóm ba con số may mắn. Một sự bài trí dùng bất cứ đồ vật có 6, 9, 3 món đều tốt cho việc hòa giải những khu vực xấu hoặc những nơi hướng xấu.</p><?php /* tag "br" from line 31 */; ?>
<br/>
						<?php /* tag "b" from line 32 */; ?>
<b>Số bẩy (7)</b>
						<?php /* tag "p" from line 33 */; ?>
<p style="text-indent:30px;">Là con số có sức mạnh kỳ diệu với những nguồn gốc truyền thuyết sâu sắc. Đó là 7 sao và cây gươm 7 sao dùng trong nghi lễ đạo Lão, tượng trưng cho sức mạnh đẩy lùi ma quỷ trong phong thủy, một sự bài trí 7 món đồ vật được ban cho một sức mạnh kỳ bí và một cảm giác của sự bất khả xâm phạm.</p><?php /* tag "br" from line 33 */; ?>
<br/>
						<?php /* tag "b" from line 34 */; ?>
<b>Số tám (8)</b>
						<?php /* tag "p" from line 35 */; ?>
<p style="text-indent:30px;">Cũng là con số có nhiều sự quan hệ tôn giáo, là tám điều bất tử trong đạo Lão và bát chánh trong Phật giáo. Một cửa sổ hình bát giác hoặc bình cắm hoa tám mặt và một bát quái (thường được treo trước ngưỡng cửa) cũng tốt, có thể ngăn chặn những ảnh hưởng xấu trước khi chúng muốn xâm nhập vào nhà.</p><?php /* tag "br" from line 35 */; ?>
<br/>
						<?php /* tag "b" from line 36 */; ?>
<b>Số chín (9)</b>
						<?php /* tag "p" from line 37 */; ?>
<p style="text-indent:30px;">Và cuối cùng là con số chính, là con số hạnh phúc, an lành, thuận lợi. Tiếng Trung Quốc, số chín đồng âm với từ “trường thọ và may mắn”.</p><?php /* tag "br" from line 37 */; ?>
<br/>
						<?php /* tag "p" from line 38 */; ?>
<p style="text-indent:30px;">(*) Nắm bắt được ý nghĩa này, trong cuộc sống con người đã biết vận dụng ý nghĩa của từng con số để phục vụ cho những ước muốn của mình…</p><?php /* tag "br" from line 38 */; ?>
<br/>
					</div>
					<?php 
/* tag "span" from line 40 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuXemThem', $_thistpl) ;
$ctx->popSlots() ;
?>

					<?php /* tag "br" from line 41 */; ?>
<br/>
			</div>
			<?php /* tag "div" from line 43 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 44 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 45 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 46 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 46 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 46 */; ?>
<br/>
					<?php /* tag "a" from line 47 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 47 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 47 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 50 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 52 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 53 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 54 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/Ynghiasim_2Admin.html (edit that file instead) */; ?>