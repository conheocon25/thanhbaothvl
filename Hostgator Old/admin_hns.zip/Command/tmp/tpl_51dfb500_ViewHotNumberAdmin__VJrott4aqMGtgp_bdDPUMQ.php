<?php 
function tpl_51dfb500_ViewHotNumberAdmin__VJrott4aqMGtgp_bdDPUMQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
</head>
<?php /* tag "script" from line 14 */; ?>
<script>
	$(document).ready(function() {
	var ct = new Date();
	var year = ct.getFullYear();
	var month = ct.getMonth()+1;
	var day = ct.getDate();		
	var sUS = year+"/"+month+"/"+day;	
	$("#orderdate").val(sUS);
	
});		
</script>
<?php /* tag "body" from line 25 */; ?>
<body>
	<?php /* tag "div" from line 26 */; ?>
<div id="frame">
		<?php /* tag "div" from line 27 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 28 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuMuasim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 29 */; ?>
<div id="main">
			<?php /* tag "div" from line 30 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 31 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
			<?php /* tag "div" from line 33 */; ?>
<div id="main3_of2_height">		
				<?php /* tag "div" from line 34 */; ?>
<div id="tieude_main">Thông tin Sim Mới Về</div>				
				<?php /* tag "div" from line 35 */; ?>
<div id="Table" style="padding-top:05px;padding-right:15px">
					<?php /* tag "table" from line 36 */; ?>
<table cellpadding="0" cellspacing="0" border="0" class="display" id="DataTable">
						<?php /* tag "thead" from line 37 */; ?>
<thead>
						<?php /* tag "tr" from line 38 */; ?>
<tr class="title" align="center">							
							<?php /* tag "td" from line 39 */; ?>
<td style="font-weight:bold" align="center">Stt</td>
							<?php /* tag "td" from line 40 */; ?>
<td style="font-weight:bold" align="center">Số Sim</td>
							<?php /* tag "td" from line 41 */; ?>
<td style="font-weight:bold" align="center">Giá bán</td>														
							<?php /* tag "td" from line 42 */; ?>
<td style="font-weight:bold" align="center">Ngày lấy về</td>							
							<?php /* tag "td" from line 43 */; ?>
<td style="font-weight:bold" align="center">Xóa</td>
						</tr>
						</thead>
						<?php /* tag "tbody" from line 46 */; ?>
<tbody>
						<?php 
/* tag "tr" from line 47 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->hotnumber = new PHPTAL_RepeatController($ctx->ViewHotNumber)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->hotnumber as $ctx->hotnumber): ;
?>
<tr>
							<?php /* tag "td" from line 48 */; ?>
<td></td>
							<?php /* tag "td" from line 49 */; ?>
<td align="center" style="font-size:15px;color:#319EFF" class="sim"><?php echo phptal_escape($ctx->path($ctx->hotnumber, 'getFormatNumber')); ?>
</td>
							<?php /* tag "td" from line 50 */; ?>
<td align="right" style="font-size:14px;color:#319EFF"><?php echo phptal_escape($ctx->path($ctx->hotnumber, 'getPrice')); ?>
</td>							
							<?php /* tag "td" from line 51 */; ?>
<td align="center"><?php echo phptal_escape($ctx->path($ctx->hotnumber, 'date')); ?>
</td>
							<?php /* tag "td" from line 52 */; ?>
<td align="center"><?php 
/* tag "a" from line 52 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->hotnumber, 'getDeleteHotNumberLinked')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>Xóa</a></td>
						</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
											
						</tbody>
					</table>
				</div>
			</div>
			<?php /* tag "div" from line 58 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 59 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 60 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 61 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 61 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 61 */; ?>
<br/>
					<?php /* tag "a" from line 62 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 62 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 62 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 65 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 67 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 68 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 69 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/ViewHotNumberAdmin.html (edit that file instead) */; ?>