<?php 
function tpl_51dfb4ec_changepass__XKf4LlEsDHPPRxM6Z5USVA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
	
</head>
<?php /* tag "script" from line 15 */; ?>
<script type="text/javascript">
			$(document).ready(
				function(){								
					$("select[name='idCategory_'] option ").each(function (index, mOption) {												
						if ($(mOption).attr("value") == $("#currentIdCategory").val())
						{							
							$("select[name='idCategory_'] option[value="+ $(mOption).attr("value") +"]").attr("selected", true);		
						}						
					});
					
					$("#idCategory_").change(function () {																		
							
							$("#currentIdCategory").val($("select[name='idCategory_'] option:selected").val());
								
					});
			});			
		</script>
<?php /* tag "body" from line 32 */; ?>
<body>
	<?php /* tag "div" from line 33 */; ?>
<div id="frame">
		<?php /* tag "div" from line 34 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 35 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuDatsim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 36 */; ?>
<div id="main">
			<?php /* tag "div" from line 37 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 38 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
		<?php /* tag "div" from line 40 */; ?>
<div id="main3_of2_height">				
					<?php /* tag "div" from line 41 */; ?>
<div id="tieude_main">Cập nhật thông tin tài khoản Quản trị</div>
					<?php 
/* tag "table" from line 42 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->User = new PHPTAL_RepeatController($ctx->Users)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->User as $ctx->User): ;
?>
<table border="0" align="center" cellspacing="0" cellpadding="0">
						<?php /* tag "form" from line 43 */; ?>
<form method="post" action="../../Command/edituser.php">						
								<?php 
/* tag "input" from line 44 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->User, 'id')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input id="text" class="input" type="hidden" size="40" name="idusername"<?php echo $_tmp_2 ?>
/>
								<?php /* tag "tr" from line 45 */; ?>
<tr>
									<?php /* tag "td" from line 46 */; ?>
<td width="150" class="DK">Tài khoản:</td>
									<?php /* tag "td" from line 47 */; ?>
<td> <?php 
/* tag "input" from line 47 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->User, 'user')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input id="text" class="input" type="text" size="40" name="username"<?php echo $_tmp_2 ?>
/></td>
								</tr>
								<?php /* tag "tr" from line 49 */; ?>
<tr>
									<?php /* tag "td" from line 50 */; ?>
<td width="150" class="DK">Họ và tên:</td>
									<?php /* tag "td" from line 51 */; ?>
<td> <?php 
/* tag "input" from line 51 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->User, 'note')))):  ;
$_tmp_2 = ' value="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<input id="text" class="input" type="text" size="40" name="fullname"<?php echo $_tmp_2 ?>
/></td>
								</tr>								
								<?php /* tag "tr" from line 53 */; ?>
<tr>								
									<?php /* tag "td" from line 54 */; ?>
<td width="150" class="DK">Mật khẩu mới</td>
									<?php /* tag "td" from line 55 */; ?>
<td><?php /* tag "input" from line 55 */; ?>
<input id="text" class="input" type="password" size="40" name="newpass"/></td>
								</tr>								
								<?php /* tag "tr" from line 57 */; ?>
<tr align="right">
									<?php /* tag "td" from line 58 */; ?>
<td colspan="2"><?php /* tag "input" from line 58 */; ?>
<input type="submit" value="Cập nhật"/>
									</td>
								</tr>
						</form>	
					</table><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
									
			</div>
			<?php /* tag "div" from line 64 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 65 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 66 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 67 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 67 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 67 */; ?>
<br/>
					<?php /* tag "a" from line 68 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 68 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 68 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 71 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 73 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 74 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
	
		<?php /* tag "div" from line 75 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/changepass.html (edit that file instead) */; ?>