<?php 
function tpl_51dfb4fd_ThanhToan__Apj8x1UxivigNKqAZD3y2Q(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
	<?php /* tag "link" from line 7 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/datatable.css"/>
	<?php /* tag "link" from line 8 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/jquery-ui-1.8.11.custom.css"/>
	
	<?php /* tag "script" from line 10 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.js"></script>
	<?php /* tag "script" from line 11 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.dataTables.js"></script>	
	<?php /* tag "script" from line 12 */; ?>
<script type="text/javascript" language="javascript" src="../Template/script/jquery.init.dataTables.js"></script>	
</head>
<?php /* tag "body" from line 14 */; ?>
<body>
	<?php /* tag "div" from line 15 */; ?>
<div id="frame">
		<?php /* tag "div" from line 16 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 17 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuMuasim', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 18 */; ?>
<div id="main">
			<?php /* tag "div" from line 19 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 20 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>			
			<?php /* tag "div" from line 22 */; ?>
<div id="main3_of2_height">
				<?php /* tag "div" from line 23 */; ?>
<div id="tieude_main">Phương thức thanh toán và nhận sim</div>
				<?php /* tag "div" from line 24 */; ?>
<div style="padding: 0 20px 0 20px; text-align: left; color: black;">
					
					<?php /* tag "font" from line 26 */; ?>
<font size="4" style="line-height:30px;"><?php /* tag "b" from line 26 */; ?>
<b>Thanh toán bằng thẻ ATM  hoặc qua ngân hàng:</b></font><?php /* tag "br" from line 26 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Qúi khách vui lòng chuyển tiền vào một trong các tài  khoản dưới đây sau đó SMS cho chúng tôi địa chỉ nhận sim.<?php /* tag "br" from line 27 */; ?>
<br/>
					
					<?php /* tag "table" from line 29 */; ?>
<table border="0" width="100%" style="float: left; background: #DCE8FC; margin: 5px 0 5px 0; padding:  5px 0 5px 0;"><?php /* tag "tr" from line 29 */; ?>
<tr><?php /* tag "td" from line 29 */; ?>
<td>
					<?php /* tag "i" from line 30 */; ?>
<i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Công Thương Việt Nam - VietinBank , Tp HCM<?php /* tag "br" from line 30 */; ?>
<br/>
					<?php /* tag "span" from line 31 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 31 */; ?>
<b>STK : </b><?php /* tag "font" from line 31 */; ?>
<font color="red"> 711A.0650.3748 </font><?php /* tag "br" from line 31 */; ?>
<br/></span>
					<?php /* tag "span" from line 32 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 32 */; ?>
<br/></span>

					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Đông Á  - DongABank  ,CN Q 10,Tp HCM<?php /* tag "br" from line 34 */; ?>
<br/>
					<?php /* tag "span" from line 35 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 35 */; ?>
<b>STK  : </b><?php /* tag "font" from line 35 */; ?>
<font color="red"> 0107.5933.27 </font><?php /* tag "br" from line 35 */; ?>
<br/></span>
					<?php /* tag "span" from line 36 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 36 */; ?>
<br/></span>

					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;+ Ngân Hàng Xuất Nhập Khẩu Việt Nam – EXIMBANK – SGD 1<?php /* tag "br" from line 38 */; ?>
<br/>
					<?php /* tag "span" from line 39 */; ?>
<span style="padding-left: 90px;"><?php /* tag "b" from line 39 */; ?>
<b>STK  : </b><?php /* tag "font" from line 39 */; ?>
<font color="red"> 2000.14949.2454.62 </font><?php /* tag "br" from line 39 */; ?>
<br/></span>
					<?php /* tag "span" from line 40 */; ?>
<span style="padding-left: 90px;">Chủ TK : Nguyễn Phước Hải<?php /* tag "br" from line 40 */; ?>
<br/></span></i>
					</td></tr></table>
					
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Quí khách sẽ nhận được sim trong vòng 24h – 48h tại nhà từ khi chuyển tiền xong, mọi thất lạc trong quá trình chuyển sim chúng tôi hoàn toàn chịu trách nhiệm.<?php /* tag "br" from line 43 */; ?>
<br/>
					<?php /* tag "font" from line 44 */; ?>
<font color="blue" size="4">Lưu ý: Quý khách nên chuyển tiền trong cùng hệ thống ngân hàng để tránh mất thời gian chờ đợi.<?php /* tag "br" from line 44 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Rất hân hạnh được phục vụ quí khách!<?php /* tag "br" from line 45 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Quý khách cần được biết thêm thông tin, cánh thức mua <?php /* tag "b" from line 46 */; ?>
<b><?php /* tag "i" from line 46 */; ?>
<i>số đẹp</i></b>, cách thức thanh toán và nhận sim...<?php /* tag "br" from line 46 */; ?>
<br/>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Đừng ngần ngại hãy gọi qua số hỗ trợ khách hàng cho chúng tôi.</font><?php /* tag "br" from line 47 */; ?>
<br/>
					<?php /* tag "center" from line 48 */; ?>
<center><?php /* tag "font" from line 48 */; ?>
<font color="blue"><?php /* tag "b" from line 48 */; ?>
<b>SỐ MÁY HỖ TRỢ KHÁCH HÀNG</b></font><?php /* tag "br" from line 48 */; ?>
<br/>
					<?php /* tag "font" from line 49 */; ?>
<font color="red" size="4"><?php /* tag "b" from line 49 */; ?>
<b>0944.92.96.96 – 0977.666.098</b></font></center>
					
				</div>
			</div>			
			<?php /* tag "div" from line 53 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 54 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3', $_thistpl) ;
$ctx->popSlots() ;
?>
 
				<?php /* tag "div" from line 55 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 56 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 56 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 56 */; ?>
<br/>
					<?php /* tag "a" from line 57 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 57 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 57 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 60 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 62 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 63 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 64 */; ?>
<div class="vide"></div>
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/ThanhToan.html (edit that file instead) */; ?>