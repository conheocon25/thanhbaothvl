<?php 
function tpl_51dfb4f4_GioiThieuAdmin__joaA25W5xXYWN4G89zb3tQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<?php /* tag "head" from line 3 */; ?>
<head>
	<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
	<?php /* tag "title" from line 5 */; ?>
<title>Sim số đẹp giá rẻ</title>
	<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="../Template/css/main2.css"/>
</head>
<?php /* tag "body" from line 8 */; ?>
<body>
	<?php /* tag "div" from line 9 */; ?>
<div id="frame">
		<?php /* tag "div" from line 10 */; ?>
<div id="header"></div>
			<?php 
/* tag "span" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuGioithieu', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 12 */; ?>
<div id="main">
			<?php /* tag "div" from line 13 */; ?>
<div id="main3_of1">
				<?php 
/* tag "span" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of1', $_thistpl) ;
$ctx->popSlots() ;
?>

			</div>
			<?php /* tag "div" from line 16 */; ?>
<div id="main3_of2">
					<?php /* tag "div" from line 17 */; ?>
<div id="tieude_main">Vì sao phải dùng Sim Số Đẹp Giá Rẻ?</div>
					<?php /* tag "div" from line 18 */; ?>
<div align="justify" style="margin-bottom: 10px; padding: 0 20px 0 20px;">
						<?php /* tag "p" from line 19 */; ?>
<p style="text-indent:25px;">Chơi sim số đẹp hiện đang trở thành một trào lưu khá phổ biến ở Việt Nam; đặc biệt tại các thành phố lớn như TP HCM, Hà Nội, Hải Phòng… Tuy nhiên, những câu hỏi xung quanh việc chơi sim số như : chơi sim số cụ thể là gì; chơi sim như thế nào mới là đúng cách; những kinh nghiệm và kiến thức khi chơi sim số…đang được rất nhiều người đặt ra và đi tìm câu trả lời.Trong khuôn khổ loạt bai viết về “Chơi sim số” chúng tôi sẽ cố gắng cung cấp những thông tin hữu ích nhất về “Chơi sim số”; giúp bạn đọc có cái nhìn tổng quan và sâu hơn về trào lưu “Chơi sim số” hiện nay.</p><?php /* tag "br" from line 19 */; ?>
<br/>
						<?php /* tag "p" from line 20 */; ?>
<p style="text-indent:25px;">Phải khẳng định vui 1 chút là “Chơi sim số đẹp” khác hẳn với “Chơi Số Đề” , sim số đẹp có rất nhiều cách chơi, ở đây tôi có thể kể ra một vài cách chơi thường gặp và quen thuộc:</p><?php /* tag "br" from line 20 */; ?>
<br/>
						<?php /* tag "p" from line 21 */; ?>
<p style="text-indent:25px; font-size: 18px; font-weight:bold;">1. Phân loại Sim số:</p>
						<?php /* tag "table" from line 22 */; ?>
<table border="1" cellspacing="-2" style="margin: 5px 0 5px 0; float: left;">
							<?php /* tag "tr" from line 23 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 24 */; ?>
<td>STT</td>
								<?php /* tag "td" from line 25 */; ?>
<td align="center">Phân loại Sim Số</td>
							</tr>
							<?php /* tag "tr" from line 27 */; ?>
<tr>
								<?php /* tag "td" from line 28 */; ?>
<td align="center">01</td>
								<?php /* tag "td" from line 29 */; ?>
<td style="padding-left: 5px;">SIM rác :dòng này ko tính vì giá trị quá nhỏ (rất thập cẩm)</td>
							</tr>
							<?php /* tag "tr" from line 31 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 32 */; ?>
<td align="center">02</td>
								<?php /* tag "td" from line 33 */; ?>
<td style="padding-left: 5px;">Sim số đẹp trùng biển số xe</td>
							</tr>
							<?php /* tag "tr" from line 35 */; ?>
<tr>
								<?php /* tag "td" from line 36 */; ?>
<td align="center">03</td>
								<?php /* tag "td" from line 37 */; ?>
<td style="padding-left: 5px;">Sim số đẹp ngày tháng năm sinh</td>
							</tr>
							<?php /* tag "tr" from line 39 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 40 */; ?>
<td align="center">04</td>
								<?php /* tag "td" from line 41 */; ?>
<td style="padding-left: 5px;">Sim số đẹp ngày tháng có ý nghĩa (Quốc Khánh… hoặc ý nghĩa với người sử dụng)</td>
							</tr>
							<?php /* tag "tr" from line 43 */; ?>
<tr>
								<?php /* tag "td" from line 44 */; ?>
<td align="center">05</td>
								<?php /* tag "td" from line 45 */; ?>
<td style="padding-left: 5px;">Sim số đẹp soi gương (ABC.CBA)</td>
							</tr>
							<?php /* tag "tr" from line 47 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 48 */; ?>
<td align="center">06</td>
								<?php /* tag "td" from line 49 */; ?>
<td style="padding-left: 5px;">Sim số đẹp lồng lộn (AB.BA.AB / ABC.CBA.ABC)</td>
							</tr>
							<?php /* tag "tr" from line 51 */; ?>
<tr>
								<?php /* tag "td" from line 52 */; ?>
<td align="center">07</td>
								<?php /* tag "td" from line 53 */; ?>
<td style="padding-left: 5px;">Sim số đẹp số gánh (ABBA / ABBBA)</td>
							</tr>
							<?php /* tag "tr" from line 55 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 56 */; ?>
<td align="center">08</td>
								<?php /* tag "td" from line 57 */; ?>
<td style="padding-left: 5px;">Sim số đẹp số tiến (VD : 1234… 010203… 203040…)</td>
							</tr>
							<?php /* tag "tr" from line 59 */; ?>
<tr>
								<?php /* tag "td" from line 60 */; ?>
<td align="center">09</td>
								<?php /* tag "td" from line 61 */; ?>
<td style="padding-left: 5px;">Sim số đẹp luận / dịch nôm (Như phía bài trên đã nói)</td>
							</tr>
							<?php /* tag "tr" from line 63 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 64 */; ?>
<td align="center">10</td>
								<?php /* tag "td" from line 65 */; ?>
<td style="padding-left: 5px;">Sim số đẹp phong thủy (sim số đẹp hợp với mệnh người sử dụng sim số đẹp theo cách tính phong thủy)</td>
							</tr>
							<?php /* tag "tr" from line 67 */; ?>
<tr>
								<?php /* tag "td" from line 68 */; ?>
<td align="center">11</td>
								<?php /* tag "td" from line 69 */; ?>
<td style="padding-left: 5px;">Sim taxi (AB.AB.AB / ABC.ABC)</td>
							</tr>
							<?php /* tag "tr" from line 71 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 72 */; ?>
<td align="center">12</td>
								<?php /* tag "td" from line 73 */; ?>
<td style="padding-left: 5px;">Sim số đẹp VIP (Tứ quý – ngũ phúc – lục tài…) SIM dòng này dễ nhớ và rất đắt</td>
							</tr>
							<?php /* tag "tr" from line 75 */; ?>
<tr>
								<?php /* tag "td" from line 76 */; ?>
<td align="center">13</td>
								<?php /* tag "td" from line 77 */; ?>
<td style="padding-left: 5px;">Sim số đẹp độc (Sim số xấu, hiếm gặp)</td>
							</tr>
						</table>

						<?php /* tag "p" from line 81 */; ?>
<p style="text-indent:25px; font-weight:bold; font-size: 18px;">2. Một số dạng luận sim số đẹp phổ biến hiện nay:</p><?php /* tag "br" from line 81 */; ?>
<br/>
						<?php /* tag "table" from line 82 */; ?>
<table border="1" cellspacing="-2" width="100%" style="margin: 5px 0 5px 0;">
							<?php /* tag "tr" from line 83 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 84 */; ?>
<td align="center">Con Số</td>
								<?php /* tag "td" from line 85 */; ?>
<td align="center">Ý nghĩa</td>
							</tr>
							<?php /* tag "tr" from line 87 */; ?>
<tr>
								<?php /* tag "td" from line 88 */; ?>
<td align="center">0</td>
								<?php /* tag "td" from line 89 */; ?>
<td style="padding-left: 5px;">Tay trắng / Bất (phủ định)</td>
							</tr>
							<?php /* tag "tr" from line 91 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 92 */; ?>
<td align="center">1</td>
								<?php /* tag "td" from line 93 */; ?>
<td style="padding-left: 5px;">Nhất / Độc / Sinh</td>
							</tr>
							<?php /* tag "tr" from line 95 */; ?>
<tr>
								<?php /* tag "td" from line 96 */; ?>
<td align="center">2</td>
								<?php /* tag "td" from line 97 */; ?>
<td style="padding-left: 5px;">Mãi</td>
							</tr>
							<?php /* tag "tr" from line 99 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 100 */; ?>
<td align="center">3</td>
								<?php /* tag "td" from line 101 */; ?>
<td style="padding-left: 5px;">Tài</td>
							</tr>
							<?php /* tag "tr" from line 103 */; ?>
<tr>
								<?php /* tag "td" from line 104 */; ?>
<td align="center">4</td>
								<?php /* tag "td" from line 105 */; ?>
<td style="padding-left: 5px;">Tử</td>
							</tr>
							<?php /* tag "tr" from line 107 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 108 */; ?>
<td align="center">5</td>
								<?php /* tag "td" from line 109 */; ?>
<td style="padding-left: 5px;">Phúc / Sinh</td>
							</tr>
							<?php /* tag "tr" from line 111 */; ?>
<tr>
								<?php /* tag "td" from line 112 */; ?>
<td align="center">6</td>
								<?php /* tag "td" from line 113 */; ?>
<td style="padding-left: 5px;">Lộc</td>
							</tr>
							<?php /* tag "tr" from line 115 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 116 */; ?>
<td align="center">7</td>
								<?php /* tag "td" from line 117 */; ?>
<td style="padding-left: 5px;">Thất</td>
							</tr>
							<?php /* tag "tr" from line 119 */; ?>
<tr>
								<?php /* tag "td" from line 120 */; ?>
<td align="center">8</td>
								<?php /* tag "td" from line 121 */; ?>
<td style="padding-left: 5px;">Phát</td>
							</tr>
							<?php /* tag "tr" from line 123 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 124 */; ?>
<td align="center">9</td>
								<?php /* tag "td" from line 125 */; ?>
<td style="padding-left: 5px;">Trường / Vĩnh cửu</td>
							</tr>
						</table>

						<?php /* tag "p" from line 129 */; ?>
<p style="text-indent:25px; font-weight:bold; font-size: 18px;">3. Một số dạng luận theo dải số:</p><?php /* tag "br" from line 129 */; ?>
<br/>
						<?php /* tag "table" from line 130 */; ?>
<table border="1" cellspacing="-2" style="margin: 5px 0 5px 0;">
							<?php /* tag "tr" from line 131 */; ?>
<tr bgcolor="#93bede" style="font-weight:bold;">
								<?php /* tag "td" from line 132 */; ?>
<td align="center">Dãy Số</td>
								<?php /* tag "td" from line 133 */; ?>
<td align="center">Ý nghĩa</td>
							</tr>
							<?php /* tag "tr" from line 135 */; ?>
<tr>
								<?php /* tag "td" from line 136 */; ?>
<td align="center">1102</td>
								<?php /* tag "td" from line 137 */; ?>
<td style="padding-left: 5px;">Nhất nhất ko nhì / Độc nhất vô nhị</td>
							</tr>
							<?php /* tag "tr" from line 139 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 140 */; ?>
<td align="center">4078</td>
								<?php /* tag "td" from line 141 */; ?>
<td style="padding-left: 5px;">4 mùa không thất bát</td>
							</tr>
							<?php /* tag "tr" from line 143 */; ?>
<tr>
								<?php /* tag "td" from line 144 */; ?>
<td align="center">2204</td>
								<?php /* tag "td" from line 145 */; ?>
<td style="padding-left: 5px;">Mãi mãi không chết</td>
							</tr>
							<?php /* tag "tr" from line 147 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 148 */; ?>
<td align="center">1486</td>
								<?php /* tag "td" from line 149 */; ?>
<td style="padding-left: 5px;">1 năm 4 mùa phát lộc / 1 năm 4 mùa lộc phát</td>
							</tr>
							<?php /* tag "tr" from line 151 */; ?>
<tr>
								<?php /* tag "td" from line 152 */; ?>
<td align="center">01234</td>
								<?php /* tag "td" from line 153 */; ?>
<td style="padding-left: 5px;">Tay trắng đi lên – 1 vợ – 2 con – 3 tầng – 4 bánh (Từ tay trắng – cưới vợ – yên bề con cái – xây nhà – mua ôtô ^^)</td>
							</tr>
							<?php /* tag "tr" from line 155 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 156 */; ?>
<td align="center">456</td>
								<?php /* tag "td" from line 157 */; ?>
<td style="padding-left: 5px;">4 mùa sinh lộc</td>
							</tr>
							<?php /* tag "tr" from line 159 */; ?>
<tr>
								<?php /* tag "td" from line 160 */; ?>
<td align="center">4953</td>
								<?php /* tag "td" from line 161 */; ?>
<td style="padding-left: 5px;">49 chưa qua 53 đã tới (Số tử / Tử vi)</td>
							</tr>
							<?php /* tag "tr" from line 163 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 164 */; ?>
<td align="center">68</td>
								<?php /* tag "td" from line 165 */; ?>
<td style="padding-left: 5px;">Lộc Phát</td>
							</tr>
							<?php /* tag "tr" from line 167 */; ?>
<tr>
								<?php /* tag "td" from line 168 */; ?>
<td align="center">39</td>
								<?php /* tag "td" from line 169 */; ?>
<td style="padding-left: 5px;">Thần tài nhỏ</td>
							</tr>
							<?php /* tag "tr" from line 171 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 172 */; ?>
<td align="center">79</td>
								<?php /* tag "td" from line 173 */; ?>
<td style="padding-left: 5px;">Thần tài lớn</td>
							</tr>
							<?php /* tag "tr" from line 175 */; ?>
<tr>
								<?php /* tag "td" from line 176 */; ?>
<td align="center">38</td>
								<?php /* tag "td" from line 177 */; ?>
<td style="padding-left: 5px;">Ông địa nhỏ</td>
							</tr>
							<?php /* tag "tr" from line 179 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 180 */; ?>
<td align="center">78</td>
								<?php /* tag "td" from line 181 */; ?>
<td style="padding-left: 5px;">Thất bát / Ông địa lớn</td>
							</tr>
							<?php /* tag "tr" from line 183 */; ?>
<tr>
								<?php /* tag "td" from line 184 */; ?>
<td align="center">83</td>
								<?php /* tag "td" from line 185 */; ?>
<td style="padding-left: 5px;">Phát tài</td>
							</tr>
							<?php /* tag "tr" from line 187 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 188 */; ?>
<td align="center">86</td>
								<?php /* tag "td" from line 189 */; ?>
<td style="padding-left: 5px;">Phát lộc</td>
							</tr>
							<?php /* tag "tr" from line 191 */; ?>
<tr>
								<?php /* tag "td" from line 192 */; ?>
<td align="center">04</td>
								<?php /* tag "td" from line 193 */; ?>
<td style="padding-left: 5px;">Bất tử</td>
							</tr>
							<?php /* tag "tr" from line 195 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 196 */; ?>
<td align="center">94</td>
								<?php /* tag "td" from line 197 */; ?>
<td style="padding-left: 5px;">Thái tử</td>
							</tr>
							<?php /* tag "tr" from line 199 */; ?>
<tr>
								<?php /* tag "td" from line 200 */; ?>
<td align="center">569</td>
								<?php /* tag "td" from line 201 */; ?>
<td style="padding-left: 5px;">Phúc – Lộc – Thọ</td>
							</tr>
							<?php /* tag "tr" from line 203 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 204 */; ?>
<td align="center">227</td>
								<?php /* tag "td" from line 205 */; ?>
<td style="padding-left: 5px;">Vạn Vạn Tuế</td>
							</tr><?php /* tag "tr" from line 206 */; ?>
<tr>
								<?php /* tag "td" from line 207 */; ?>
<td align="center">15.16.18</td>
								<?php /* tag "td" from line 208 */; ?>
<td style="padding-left: 5px;">Mỗi năm – mỗi lộc – mỗi phát</td>
							</tr><?php /* tag "tr" from line 209 */; ?>
<tr>
								<?php /* tag "td" from line 210 */; ?>
<td align="center">6886/8668</td>
								<?php /* tag "td" from line 211 */; ?>
<td style="padding-left: 5px;">Lộc phát phát lộc / Phát lộc lộc phát</td>
							</tr>
							<?php /* tag "tr" from line 213 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 214 */; ?>
<td align="center">8386/8683</td>
								<?php /* tag "td" from line 215 */; ?>
<td style="padding-left: 5px;">Phát tài phát lộc / Phát lộc phát tài</td>
							</tr>
							<?php /* tag "tr" from line 217 */; ?>
<tr>
								<?php /* tag "td" from line 218 */; ?>
<td align="center">18.18.18</td>
								<?php /* tag "td" from line 219 */; ?>
<td style="padding-left: 5px;">Mỗi năm 1 phát</td>
							</tr>
							<?php /* tag "tr" from line 221 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 222 */; ?>
<td align="center">19.19.19</td>
								<?php /* tag "td" from line 223 */; ?>
<td style="padding-left: 5px;">1 bước lên trời</td>
							</tr>
							<?php /* tag "tr" from line 225 */; ?>
<tr>
								<?php /* tag "td" from line 226 */; ?>
<td align="center">1368</td>
								<?php /* tag "td" from line 227 */; ?>
<td style="padding-left: 5px;">Nhất tài lộc phát / Kim lâu (Tử vi)</td>
							</tr>
							<?php /* tag "tr" from line 229 */; ?>
<tr bgcolor="#EFEFEF">
								<?php /* tag "td" from line 230 */; ?>
<td align="center"></td>
								<?php /* tag "td" from line 231 */; ?>
<td style="padding-left: 5px;">Dãy số đuôi 1368 thực sự là dãy số rất chi là đặc biệt,dân Sim số thường quan niệm con số 1 là Sinh (sinh sôi nảy nở),3 là tài,68 là lộc phát=> 1368 là Sinh Tài Lộc Phát rất đẹp với dân làm ăn buôn bán.Tuy nhiên dãy số 1368 còn có một điểm rất đặc biệt mà ít người phát hiện ra đó là : 123+456+789=1368 Đây là 3 cặp số nối tiếp nhau trong dãy số tự nhiên từ 0-9 cộng tổng lại thành ra 1368,có thể hiểu 1368 là chuỗi số đại diện cho sự tổng hòa các con số có đẹp có xấu và mang tính chọn lọc cao nhất của dãy số tự nhiên.Vậy có thể coi 1368 là đẹp? Hơn nữa 1368 lại không chứa các số bị coi là xấu như 4 và 7 trong đó nên càng mang tính chọn lọc rất cao,hơn nữa đây là số tiến đều ko bị ngắt đoạn lên xuống chập chùng chỉ sự thăng tiến cho chủ nhân của con số này.</td>
							</tr>
						</table>

					</div>
					<?php 
/* tag "span" from line 236 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/MenuXemThem', $_thistpl) ;
$ctx->popSlots() ;
?>
 
					<?php /* tag "br" from line 237 */; ?>
<br/>					
			</div>
			<?php /* tag "div" from line 239 */; ?>
<div id="main3_of3">
				<?php 
/* tag "span" from line 240 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Main3of3Admin', $_thistpl) ;
$ctx->popSlots() ;
?>
  
				<?php /* tag "div" from line 241 */; ?>
<div style="border: 1px solid #999; height: 242px;">
					<?php /* tag "a" from line 242 */; ?>
<a href="http://tkpc.vn/" target="_blank"><?php /* tag "img" from line 242 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/tinkhoa.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 242 */; ?>
<br/>
					<?php /* tag "a" from line 243 */; ?>
<a href="http://sncpc.com/home/" target="_blank"><?php /* tag "img" from line 243 */; ?>
<img width="100%" height="50%" border="0" src="../Template/images/snc.gif" alt="Quang Cao"/></a><?php /* tag "br" from line 243 */; ?>
<br/>
				</div>
			</div>
			<?php /* tag "div" from line 246 */; ?>
<div class="vide"></div>
		</div>
		<?php /* tag "div" from line 248 */; ?>
<div id="line"></div>
		<?php 
/* tag "div" from line 249 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('macros.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>
	
		<?php /* tag "div" from line 250 */; ?>
<div class="vide"></div>	
	</div>
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home/tgsim24h/public_html/Template/GioiThieuAdmin.html (edit that file instead) */; ?>