<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SellingSearchCourse.html");
	echo $Viewer->html();
?>
