<?php		
	$mDomain	 		= new \MVC\Mapper\Domain();	
	$mTable		 		= new \MVC\Mapper\Table();
	$mSupplier		 	= new \MVC\Mapper\Supplier();
	$mResource		 	= new \MVC\Mapper\Resource();
	$mSession		 	= new \MVC\Mapper\Session();
	$mSessionDetail	 	= new \MVC\Mapper\SessionDetail();	
	$mEmployee 			= new \MVC\Mapper\Employee();
	$mUnit 				= new \MVC\Mapper\Unit();
	$mCustomer 			= new \MVC\Mapper\Customer();	
	$mCategory 			= new \MVC\Mapper\Category();	
	$mCourse 			= new \MVC\Mapper\Course();	
	$mUser 				= new \MVC\Mapper\User();
	$mConfig 			= new \MVC\Mapper\Config();
	$mTermPaid 			= new \MVC\Mapper\TermPaid();
	$mTermCollect 		= new \MVC\Mapper\TermCollect();
?>