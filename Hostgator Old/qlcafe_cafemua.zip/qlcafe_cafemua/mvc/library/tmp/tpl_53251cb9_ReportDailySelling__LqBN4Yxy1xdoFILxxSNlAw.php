<?php 
function tpl_53251cb9_ReportDailySelling__LqBN4Yxy1xdoFILxxSNlAw(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

	</head>
	
	<?php /* tag "body" from line 8 */; ?>
<body data-menu-position="closed">
		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>
		
		<?php /* tag "div" from line 10 */; ?>
<div id="content">
			<?php 
/* tag "div" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/ContentHeader', $_thistpl) ;
$ctx->popSlots() ;
?>
			
			<?php 
/* tag "div" from line 12 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/LocationBar', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 13 */; ?>
<div class="row">
				<?php /* tag "div" from line 14 */; ?>
<div class="container-fluid">
					<?php /* tag "div" from line 15 */; ?>
<div class="col-12">
						<?php /* tag "div" from line 16 */; ?>
<div class="widget-box">
							<?php /* tag "div" from line 17 */; ?>
<div class="widget-content nopadding">
								<?php /* tag "h1" from line 18 */; ?>
<h1><?php echo phptal_escape('TỔNG CỘNG ( ' . $ctx->NTotal->formatCurrency() . ' / ' . $ctx->NTotal_1->formatCurrency() . ' / ' . $ctx->NTotal_2->formatCurrency() . ')'); ?>
</h1>
								<?php /* tag "h3" from line 19 */; ?>
<h3>CA 1 <?php /* tag "span" from line 19 */; ?>
<span><?php echo phptal_escape('TỔNG CỘNG ( ' . $ctx->NTotal1->formatCurrency() . ' / ' . $ctx->NTotal11->formatCurrency() . ' / ' . $ctx->NTotal12->formatCurrency() . ')'); ?>
</span></h3>
								<?php /* tag "table" from line 20 */; ?>
<table class="table table-striped table-hover">
									<?php /* tag "thead" from line 21 */; ?>
<thead>
										<?php /* tag "tr" from line 22 */; ?>
<tr>
											<?php /* tag "th" from line 23 */; ?>
<th width="5%"><?php /* tag "B" from line 23 */; ?>
<B>#ID</B></th>
											<?php /* tag "th" from line 24 */; ?>
<th width="15%"><?php /* tag "div" from line 24 */; ?>
<div class="text-left">THỜI GIAN</div></th>
											<?php /* tag "th" from line 25 */; ?>
<th width="11%"><?php /* tag "div" from line 25 */; ?>
<div class="text-left">THU NGÂN</div></th>
											<?php /* tag "th" from line 26 */; ?>
<th width="14%"><?php /* tag "div" from line 26 */; ?>
<div class="text-left">NHÂN VIÊN</div></th>
											<?php /* tag "th" from line 27 */; ?>
<th width="33%"><?php /* tag "div" from line 27 */; ?>
<div class="text-left">BÀN</div></th>											
											<?php /* tag "th" from line 28 */; ?>
<th width="11%"><?php /* tag "div" from line 28 */; ?>
<div class="text-right">CHƯA TÍNH</div></th>
											<?php /* tag "th" from line 29 */; ?>
<th width="11%"><?php /* tag "div" from line 29 */; ?>
<div class="text-right">ĐÃ TÍNH</div></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 32 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 33 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Session = new PHPTAL_RepeatController($ctx->Session1All)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Session as $ctx->Session): ;
?>
<tr>
											<?php /* tag "td" from line 34 */; ?>
<td align="center"><?php /* tag "span" from line 34 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getId')); ?>
</span></td>
											<?php /* tag "td" from line 35 */; ?>
<td align="left"><?php /* tag "span" from line 35 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTimeRangePrint')); ?>
</span></td>
											<?php /* tag "td" from line 36 */; ?>
<td align="left"><?php /* tag "span" from line 36 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getUser/getName')); ?>
</span></td>
											<?php /* tag "td" from line 37 */; ?>
<td align="left">
												<?php 
/* tag "span" from line 38 */ ;
if ($ctx->path($ctx->Session, 'getEmployee')):  ;
?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getEmployee/getName')); ?>
</span><?php endif; ?>

												<?php 
/* tag "span" from line 39 */ ;
if (!($ctx->path($ctx->Session, 'getEmployee'))):  ;
?>
<span>Chưa xác định</span><?php endif; ?>

											</td>
											<?php /* tag "td" from line 41 */; ?>
<td align="left"><?php /* tag "span" from line 41 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTable/getDomain/getName')); ?>
</span> / <?php /* tag "span" from line 41 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTable/getName')); ?>
</span></td>
											<?php /* tag "td" from line 42 */; ?>
<td align="right">
												<?php 
/* tag "a" from line 43 */ ;
if ($ctx->Session->getStatus()==0):  ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Session, 'getURLPrint')))):  ;
$_tmp_2 = ' alt="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a data-toggle="modal" class="SessionPreview" href="#DialogPreview"<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Session, 'getValuePrint')); ?>
</a><?php endif; ?>

											</td>
											<?php /* tag "td" from line 45 */; ?>
<td align="right">
												<?php 
/* tag "a" from line 46 */ ;
if ($ctx->Session->getStatus()==1):  ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Session, 'getURLPrint')))):  ;
$_tmp_2 = ' alt="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a data-toggle="modal" class="SessionPreview" href="#DialogPreview"<?php echo $_tmp_2 ?>
><?php echo phptal_escape($ctx->path($ctx->Session, 'getValuePrint')); ?>
</a><?php endif; ?>

											</td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>								
								<?php /* tag "h3" from line 51 */; ?>
<h3>CA 2 <?php /* tag "span" from line 51 */; ?>
<span><?php echo phptal_escape('TỔNG CỘNG ( ' . $ctx->NTotal2->formatCurrency() . ' / ' . $ctx->NTotal21->formatCurrency() . ' / ' . $ctx->NTotal22->formatCurrency() . ')'); ?>
</span></h3>
								<?php /* tag "table" from line 52 */; ?>
<table class="table table-striped table-hover">
									<?php /* tag "thead" from line 53 */; ?>
<thead>
										<?php /* tag "tr" from line 54 */; ?>
<tr>
											<?php /* tag "th" from line 55 */; ?>
<th width="5%"><?php /* tag "B" from line 55 */; ?>
<B>#ID</B></th>
											<?php /* tag "th" from line 56 */; ?>
<th width="15%"><?php /* tag "div" from line 56 */; ?>
<div class="text-left">THỜI GIAN</div></th>
											<?php /* tag "th" from line 57 */; ?>
<th width="11%"><?php /* tag "div" from line 57 */; ?>
<div class="text-left">THU NGÂN</div></th>
											<?php /* tag "th" from line 58 */; ?>
<th width="14%"><?php /* tag "div" from line 58 */; ?>
<div class="text-left">NHÂN VIÊN</div></th>
											<?php /* tag "th" from line 59 */; ?>
<th width="33%"><?php /* tag "div" from line 59 */; ?>
<div class="text-left">BÀN</div></th>											
											<?php /* tag "th" from line 60 */; ?>
<th width="11%"><?php /* tag "div" from line 60 */; ?>
<div class="text-right">CHƯA TÍNH</div></th>
											<?php /* tag "th" from line 61 */; ?>
<th width="11%"><?php /* tag "div" from line 61 */; ?>
<div class="text-right">ĐÃ TÍNH</div></th>
										</tr>
									</thead>
									<?php /* tag "tbody" from line 64 */; ?>
<tbody>
										<?php 
/* tag "tr" from line 65 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->Session = new PHPTAL_RepeatController($ctx->Session2All)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->Session as $ctx->Session): ;
?>
<tr>
											<?php /* tag "td" from line 66 */; ?>
<td align="center"><?php /* tag "span" from line 66 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getId')); ?>
</span></td>
											<?php /* tag "td" from line 67 */; ?>
<td align="left"><?php /* tag "span" from line 67 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTimeRangePrint')); ?>
</span></td>
											<?php /* tag "td" from line 68 */; ?>
<td align="left"><?php /* tag "span" from line 68 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getUser/getName')); ?>
</span></td>
											<?php /* tag "td" from line 69 */; ?>
<td align="left">
												<?php 
/* tag "span" from line 70 */ ;
if ($ctx->path($ctx->Session, 'getEmployee')):  ;
?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getEmployee/getName')); ?>
</span><?php endif; ?>

												<?php 
/* tag "span" from line 71 */ ;
if (!($ctx->path($ctx->Session, 'getEmployee'))):  ;
?>
<span>Chưa xác định</span><?php endif; ?>

											</td>
											<?php /* tag "td" from line 73 */; ?>
<td align="left"><?php /* tag "span" from line 73 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTable/getDomain/getName')); ?>
</span> / <?php /* tag "span" from line 73 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTable/getName')); ?>
</span></td>
											<?php /* tag "td" from line 74 */; ?>
<td align="right">
												<?php 
/* tag "a" from line 75 */ ;
if ($ctx->Session->getStatus()==0):  ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->Session, 'getURLPrint')))):  ;
$_tmp_1 = ' alt="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a data-toggle="modal" class="SessionPreview" href="#DialogPreview"<?php echo $_tmp_1 ?>
><?php echo phptal_escape($ctx->path($ctx->Session, 'getValuePrint')); ?>
</a><?php endif; ?>

											</td>
											<?php /* tag "td" from line 77 */; ?>
<td align="right">
												<?php 
/* tag "a" from line 78 */ ;
if ($ctx->Session->getStatus()==1):  ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->Session, 'getURLPrint')))):  ;
$_tmp_1 = ' alt="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a data-toggle="modal" class="SessionPreview" href="#DialogPreview"<?php echo $_tmp_1 ?>
><?php echo phptal_escape($ctx->path($ctx->Session, 'getValuePrint')); ?>
</a><?php endif; ?>

											</td>
										</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</tbody>
								</table>								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- DIALOG PREVIEW	-->
		<?php /* tag "div" from line 90 */; ?>
<div id="DialogPreview" class="modal fade">
			<?php /* tag "div" from line 91 */; ?>
<div class="modal-dialog">
				<?php /* tag "div" from line 92 */; ?>
<div class="modal-content">
					<?php /* tag "div" from line 93 */; ?>
<div class="modal-header"><?php /* tag "h3" from line 93 */; ?>
<h3><?php /* tag "i" from line 93 */; ?>
<i class="glyphicons-print modal-icon"></i>XEM LẠI PHIẾU</h3></div>
					<?php /* tag "div" from line 94 */; ?>
<div class="form-horizontal">
						<?php /* tag "div" from line 95 */; ?>
<div class="form-group">
							<?php /* tag "div" from line 96 */; ?>
<div id="DocPreview"></div>
						</div>
						<?php /* tag "div" from line 98 */; ?>
<div class="modal-footer">
							<?php /* tag "button" from line 99 */; ?>
<button id="ButtonDocPreview" data-dismiss="modal" class="btn btn-default btn-small"><?php /* tag "i" from line 99 */; ?>
<i class="glyphicons-undo"></i> Đóng lại</button>
						</div>									
					</div>
				</div>
			</div>
		</div>
		<?php 
/* tag "div" from line 105 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 106 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "script" from line 107 */; ?>
<script>
			$(".SessionPreview").click(function(){
				var URL = $(this).attr('alt');
				var mPDF = new PDFObject({ 		
					url: URL,				
					height: "500px",
					pdfOpenParams:{
						view: 'Fit', 
						toolbar: '1', 
						statusbar: '1', 
						messages: '1',
						navpanes: '1' 
					}				
				}).embed("DocPreview");						
				
			});
		</script>						
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcafe_cafemua/mvc/templates/ReportDailySelling.html (edit that file instead) */; ?>