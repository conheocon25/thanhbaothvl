<?php
	$Data = array('result'=>'OK');		
	echo json_encode($Data);
?>