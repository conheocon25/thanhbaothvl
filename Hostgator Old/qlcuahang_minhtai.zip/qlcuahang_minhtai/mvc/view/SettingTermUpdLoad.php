<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingTermUpdLoad.html");
	echo $Viewer->html();
?>
