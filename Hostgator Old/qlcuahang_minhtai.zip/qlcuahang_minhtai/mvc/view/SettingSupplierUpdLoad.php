<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingSupplierUpdLoad.html");
	echo $Viewer->html();
?>
