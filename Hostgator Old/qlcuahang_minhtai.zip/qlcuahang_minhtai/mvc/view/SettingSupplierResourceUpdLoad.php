<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingSupplierResourceUpdLoad.html");
	echo $Viewer->html();
?>
