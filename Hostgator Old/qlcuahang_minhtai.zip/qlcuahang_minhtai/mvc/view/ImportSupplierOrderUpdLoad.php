<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/ImportSupplierOrderUpdLoad.html");
	echo $Viewer->html();
?>
