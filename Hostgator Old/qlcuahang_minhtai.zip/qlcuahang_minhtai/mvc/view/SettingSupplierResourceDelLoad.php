<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingSupplierResourceDelLoad.html");
	echo $Viewer->html();
?>
