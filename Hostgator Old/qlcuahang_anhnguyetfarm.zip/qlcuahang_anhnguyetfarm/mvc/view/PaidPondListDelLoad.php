<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/PaidPondListDelLoad.html");
	echo $Viewer->html();
?>
