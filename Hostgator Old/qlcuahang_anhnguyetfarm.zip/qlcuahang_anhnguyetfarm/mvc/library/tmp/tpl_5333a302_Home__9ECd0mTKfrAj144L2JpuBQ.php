<?php 
function tpl_5333a302_Home__9ECd0mTKfrAj144L2JpuBQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html xmlns="http://www.w3.org/1999/xhtml">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php /* tag "meta" from line 4 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<?php /* tag "meta" from line 5 */; ?>
<meta http-equiv="X-UA-Compatible" content="IE=9"/>
		<?php /* tag "link" from line 6 */; ?>
<link rel="stylesheet" type="text/css" href="/mvc/templates/theme/base/layout.css"/>
	</head>
	
	<?php /* tag "body" from line 9 */; ?>
<body>
		<?php /* tag "div" from line 10 */; ?>
<div id="wraper">
			<?php /* tag "div" from line 11 */; ?>
<div id="header">
				<?php /* tag "img" from line 12 */; ?>
<img border="0" src="/mvc/templates/theme/base/images/banner.jpg" width="1000" height="200"/>
			</div>
			<?php /* tag "div" from line 14 */; ?>
<div id="main">
				<?php /* tag "div" from line 15 */; ?>
<div id="top-border">
					<?php /* tag "div" from line 16 */; ?>
<div class="top-angle">
						<?php /* tag "div" from line 17 */; ?>
<div class="x-border"></div>
					</div>
				</div>
				<?php /* tag "div" from line 20 */; ?>
<div id="main-content">
					<?php /* tag "div" from line 21 */; ?>
<div id="left">
						<?php /* tag "div" from line 22 */; ?>
<div class="box">
							<?php /* tag "div" from line 23 */; ?>
<div class="box-title">
								<?php /* tag "div" from line 24 */; ?>
<div class="title-node">
									<?php /* tag "div" from line 25 */; ?>
<div class="title-mid">
										<?php /* tag "h3" from line 26 */; ?>
<h3>Danh Mục</h3>
									</div>
								</div>
							</div>
							<?php /* tag "div" from line 30 */; ?>
<div class="box-content">
								<?php /* tag "div" from line 31 */; ?>
<div class="content-node">
									<?php /* tag "div" from line 32 */; ?>
<div class="content-mid">
										<?php /* tag "ul" from line 33 */; ?>
<ul class="menu-left">
											<?php /* tag "a" from line 34 */; ?>
<a href="#"><?php /* tag "li" from line 34 */; ?>
<li>Giới thiệu</li></a>
											<?php /* tag "a" from line 35 */; ?>
<a href="#"><?php /* tag "li" from line 35 */; ?>
<li>Hoạt động</li></a>
											<?php /* tag "a" from line 36 */; ?>
<a href="#"><?php /* tag "li" from line 36 */; ?>
<li>Tiêu chuẩn chất lượng</li></a>
											<?php /* tag "a" from line 37 */; ?>
<a href="#"><?php /* tag "li" from line 37 */; ?>
<li>Ảnh minh họa</li></a>
											<?php /* tag "a" from line 38 */; ?>
<a target="blank" href="/signin/load"><?php /* tag "li" from line 38 */; ?>
<li>Quản lý ao</li></a>
										</ul>
									</div>
								</div>
							</div>
							<?php /* tag "div" from line 43 */; ?>
<div class="box-bottom">
								<?php /* tag "div" from line 44 */; ?>
<div class="bottom-node">
									<?php /* tag "div" from line 45 */; ?>
<div class="bottom-mid"></div>
								</div>
							</div>
						</div>
																		
						<!-- //////////////////////////////////////////////// -->
						<?php /* tag "div" from line 51 */; ?>
<div class="box">
							<?php /* tag "div" from line 52 */; ?>
<div class="box-title">
								<?php /* tag "div" from line 53 */; ?>
<div class="title-node">
									<?php /* tag "div" from line 54 */; ?>
<div class="title-mid">
										<?php /* tag "h3" from line 55 */; ?>
<h3>Liên hệ</h3>
									</div>
								</div>
							</div>
							<?php /* tag "div" from line 59 */; ?>
<div class="box-content">
								<?php /* tag "div" from line 60 */; ?>
<div class="content-node">
									<?php /* tag "div" from line 61 */; ?>
<div class="content-mid" align="center">
										<?php /* tag "a" from line 62 */; ?>
<a href="http://edit.yahoo.com/config/send_webmesg?.target=tuan_buithanh&amp;src=pg">
											<?php /* tag "img" from line 63 */; ?>
<img border="0" src="http://opi.yahoo.com/online?u=tuan_buithanh&amp;m=g&amp;t=2"/>
										</a><?php /* tag "br" from line 64 */; ?>
<br/>
										<?php /* tag "b" from line 65 */; ?>
<b>Trại cá Ánh Nguyệt</b><?php /* tag "br" from line 65 */; ?>
<br/>
										Châu Thành Đồng Tháp<?php /* tag "br" from line 66 */; ?>
<br/>
										Mail:anhnguyetfarm@gmail.com<?php /* tag "br" from line 67 */; ?>
<br/>
										YM:anhnguyetfarm@yahoo.com<?php /* tag "br" from line 68 */; ?>
<br/>
										ĐT:(0939) 43 88 37<?php /* tag "br" from line 69 */; ?>
<br/>
									</div>
								</div>
							</div>
							<?php /* tag "div" from line 73 */; ?>
<div class="box-bottom">
								<?php /* tag "div" from line 74 */; ?>
<div class="bottom-node">
									<?php /* tag "div" from line 75 */; ?>
<div class="bottom-mid"></div>
								</div>
							</div>
						</div>
					</div>
					<?php /* tag "div" from line 80 */; ?>
<div id="right">
						<?php /* tag "embed" from line 81 */; ?>
<embed type="application/x-shockwave-flash" src="https://picasaweb.google.com/s/c/bin/slideshow.swf" width="100%" height="400" flashvars="host=picasaweb.google.com&amp;hl=vi&amp;feat=flashalbum&amp;RGB=0x000000&amp;feed=https%3A%2F%2Fpicasaweb.google.com%2Fdata%2Ffeed%2Fapi%2Fuser%2F109127814216215895925%2Falbumid%2F5820396779339705329%3Falt%3Drss%26kind%3Dphoto%26hl%3Dvi" pluginspage="http://www.macromedia.com/go/getflashplayer">
						</embed>
					</div>
					<?php /* tag "div" from line 84 */; ?>
<div class="clear"></div>
					<?php /* tag "div" from line 85 */; ?>
<div id="footer">						
					</div>
				</div>
				<?php /* tag "div" from line 88 */; ?>
<div id="bottom-border">
					<?php /* tag "div" from line 89 */; ?>
<div class="bottom-angle">
						<?php /* tag "div" from line 90 */; ?>
<div class="y-border"></div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_anhnguyetfarm/mvc/templates/Home.html (edit that file instead) */; ?>