﻿$( document ).bind( "mobileinit", function(){ 
	$.extend( $.mobile, { 		
		loadingMessage: "Đang xử lí dữ liệu...", 		
		defaultTransition: "none"		
	});
});
