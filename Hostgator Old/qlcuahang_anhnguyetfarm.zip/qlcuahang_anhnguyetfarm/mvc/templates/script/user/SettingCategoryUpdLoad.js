﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingCategoryUpdLoad").validate();
});
