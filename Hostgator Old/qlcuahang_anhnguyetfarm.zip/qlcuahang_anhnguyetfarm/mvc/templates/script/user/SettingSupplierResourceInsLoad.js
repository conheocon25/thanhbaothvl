﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingSupplierResourceInsLoad").validate();
});
