﻿$(document).on("pageshow", "#PageHome", function() {			("#FormSignin").validate();
});
