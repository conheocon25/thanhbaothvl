﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingSupplierUpdLoad").validate();
});
