﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingInfoUpdLoad").validate();
});
