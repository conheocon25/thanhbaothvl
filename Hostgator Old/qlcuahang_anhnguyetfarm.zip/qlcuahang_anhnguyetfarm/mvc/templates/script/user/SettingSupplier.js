﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$('#SettingSupplier').attr('data-theme','a');
});
