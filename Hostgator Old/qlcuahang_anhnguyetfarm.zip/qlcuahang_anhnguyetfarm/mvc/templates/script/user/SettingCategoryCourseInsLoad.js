﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingCategoryCourseInsLoad").validate();
});
