﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$('#SettingCategory').attr('data-theme','a');
});
