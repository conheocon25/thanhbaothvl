﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$('#SettingInfo').attr('data-theme','a');
});
