﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingSupplierInsLoad").validate();
});
