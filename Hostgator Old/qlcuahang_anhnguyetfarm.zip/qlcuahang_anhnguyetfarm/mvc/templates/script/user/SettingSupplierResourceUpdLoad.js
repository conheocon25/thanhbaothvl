﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingSupplierResourceUpdLoad").validate();
});
