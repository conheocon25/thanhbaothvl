﻿$(document).bind( "pagebeforechange", function( e, data ) {		
	$("#FormPaidPondListInsLoad").validate(); 
});