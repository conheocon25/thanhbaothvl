﻿$(document).bind( "pagebeforechange", function( e, data ) {	
	$("#FormSettingCategoryInsLoad").validate();
});
