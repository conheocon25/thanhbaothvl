﻿$(document).on("pageshow", "#PageHome", function(){
	$("#FormRegister").validate();
});
