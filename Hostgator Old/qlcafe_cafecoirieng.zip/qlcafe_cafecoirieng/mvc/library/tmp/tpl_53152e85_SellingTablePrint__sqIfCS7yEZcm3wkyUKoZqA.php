<?php 
function tpl_53152e85_SellingTablePrint__sqIfCS7yEZcm3wkyUKoZqA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
/* tag "table" from line 1 */ ;
?>
<table align="left" width="100%" cellpadding="1" cellspacing="0" border="0" bordercolor="#FFF">
		<?php /* tag "tr" from line 2 */; ?>
<tr>			
			<?php /* tag "td" from line 3 */; ?>
<td width="100%" align="center">
				<?php /* tag "font" from line 4 */; ?>
<font size="11pt"><?php /* tag "b" from line 4 */; ?>
<b><?php echo phptal_escape($ctx->path($ctx->ConfigName, 'getValue')); ?>
</b></font>
			</td>
		</tr>
		<?php /* tag "tr" from line 7 */; ?>
<tr>			
			<?php /* tag "td" from line 8 */; ?>
<td width="100%" align="center">
				<?php /* tag "font" from line 9 */; ?>
<font size="10pt"><?php echo phptal_escape($ctx->path($ctx->ConfigAddress, 'getValue')); ?>
</font>
			</td>
		</tr>
		<?php /* tag "tr" from line 12 */; ?>
<tr>			
			<?php /* tag "td" from line 13 */; ?>
<td width="100%" align="center">
				<?php /* tag "font" from line 14 */; ?>
<font size="10pt"><?php echo phptal_escape($ctx->path($ctx->ConfigPhone, 'getValue')); ?>
</font>
			</td>
		</tr>
		<?php /* tag "tr" from line 17 */; ?>
<tr>			
			<?php /* tag "td" from line 18 */; ?>
<td width="100%" align="center">
				<?php /* tag "font" from line 19 */; ?>
<font size="11pt"><?php /* tag "b" from line 19 */; ?>
<b>PHIẾU THANH TOÁN</b></font>
			</td>
		</tr>		
	</table>
<?php /* tag "br" from line 23 */; ?>
<br/>
<?php /* tag "font" from line 24 */; ?>
<font size="10pt">	
	<?php /* tag "table" from line 25 */; ?>
<table align="left" style="padding-top:0px;" width="100%" cellpadding="1" cellspacing="0" border="0" bordercolor="#FFF">
		<?php /* tag "tr" from line 26 */; ?>
<tr>
			<?php /* tag "td" from line 27 */; ?>
<td width="40%" align="left">				
				<?php /* tag "span" from line 28 */; ?>
<span><?php echo phptal_escape(mb_strtoupper($ctx->Session->getTable()->getName(),'UTF8')); ?>
</span>				
			</td>
			<?php /* tag "td" from line 30 */; ?>
<td width="60%" align="right">
				<?php /* tag "span" from line 31 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getTimeRangePrint')); ?>
</span>
			</td>
		</tr>
		<?php /* tag "tr" from line 34 */; ?>
<tr>
			<?php /* tag "td" from line 35 */; ?>
<td width="40%" align="left">
				HĐ: <?php /* tag "span" from line 36 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getId')); ?>
</span>
			</td>
			<?php /* tag "td" from line 38 */; ?>
<td width="60%" align="right">
				<?php /* tag "span" from line 39 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getEmployee/getName')); ?>
</span>
			</td>
		</tr>		
	</table>
</font>
<?php /* tag "br" from line 44 */; ?>
<br/>
<?php /* tag "font" from line 45 */; ?>
<font size="9pt">
	<?php /* tag "table" from line 46 */; ?>
<table align="left" style="padding-bottom:0px;" width="100%" cellpadding="2" cellspacing="0" border="1">
		<?php /* tag "thead" from line 47 */; ?>
<thead>
			<?php /* tag "tr" from line 48 */; ?>
<tr>
				<?php /* tag "th" from line 49 */; ?>
<th width="45%"><?php /* tag "b" from line 49 */; ?>
<b>MÓN</b></th>
				<?php /* tag "th" from line 50 */; ?>
<th width="15%" align="right"><?php /* tag "b" from line 50 */; ?>
<b>SL</b></th>
				<?php /* tag "th" from line 51 */; ?>
<th width="20%" align="right"><?php /* tag "b" from line 51 */; ?>
<b>Đ.GIÁ</b></th>
				<?php /* tag "th" from line 52 */; ?>
<th width="20%" align="right"><?php /* tag "b" from line 52 */; ?>
<b>T.TIỀN</b></th>
			</tr>
		</thead>
		<?php /* tag "tbody" from line 55 */; ?>
<tbody>
			<?php 
/* tag "tr" from line 56 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Detail = new PHPTAL_RepeatController($ctx->path($ctx->Session, 'getDetails'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Detail as $ctx->Detail): ;
?>
<tr>
				<?php /* tag "td" from line 57 */; ?>
<td width="45%" align="left"><?php echo phptal_escape($ctx->path($ctx->Detail, 'getCourse/getName')); ?>
</td>
				<?php /* tag "td" from line 58 */; ?>
<td width="15%" align="right"><?php echo phptal_escape($ctx->path($ctx->Detail, 'getCount')); ?>
</td>
				<?php /* tag "td" from line 59 */; ?>
<td width="20%" align="right"><?php echo phptal_escape($ctx->path($ctx->Detail, 'getPricePrint')); ?>
</td>
				<?php /* tag "td" from line 60 */; ?>
<td width="20%" align="right"><?php /* tag "span" from line 60 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Detail, 'getValuePrint')); ?>
</span></td>
			</tr><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
		
		</tbody>
	</table>
	<?php /* tag "table" from line 64 */; ?>
<table align="left" style="padding-bottom:2px;" width="100%" cellpadding="2" cellspacing="0" border="0">
		<?php /* tag "tbody" from line 65 */; ?>
<tbody>
			<?php 
/* tag "tr" from line 66 */ ;
if ($ctx->path($ctx->Session, 'getDiscountPercent')):  ;
?>
<tr>
				<?php /* tag "td" from line 67 */; ?>
<td align="right" colspan="5" width="100%">
					<?php /* tag "font" from line 68 */; ?>
<font align="right" size="10pt">T.PHIẾU: <?php /* tag "b" from line 68 */; ?>
<b><?php echo phptal_escape($ctx->path($ctx->Session, 'getValueBasePrint')); ?>
</b></font>
				</td>	
			</tr><?php endif; ?>

			<?php 
/* tag "tr" from line 71 */ ;
if ($ctx->path($ctx->Session, 'getDiscountPercent')):  ;
?>
<tr>
				<?php /* tag "td" from line 72 */; ?>
<td align="right" colspan="5" width="100%">
					<?php /* tag "font" from line 73 */; ?>
<font align="right" size="12pt">GIẢM GIÁ: <?php /* tag "b" from line 73 */; ?>
<b><?php echo phptal_escape($ctx->path($ctx->Session, 'getDiscountPercentPrint')); ?>
</b></font>
				</td>	
			</tr><?php endif; ?>

			<?php /* tag "tr" from line 76 */; ?>
<tr>
				<?php /* tag "td" from line 77 */; ?>
<td align="right" colspan="5" width="100%">
					<?php /* tag "font" from line 78 */; ?>
<font align="right" size="12pt">TC: <?php /* tag "b" from line 78 */; ?>
<b><?php echo phptal_escape($ctx->path($ctx->Session, 'getValuePrint')); ?>
</b></font>
				</td>
			</tr>
			<?php /* tag "tr" from line 81 */; ?>
<tr>
				<?php /* tag "td" from line 82 */; ?>
<td align="right" colspan="5" width="100%">
					<?php /* tag "p" from line 83 */; ?>
<p>(<?php /* tag "span" from line 83 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Session, 'getValueStrPrint')); ?>
</span>)</p>
				</td>
			</tr>
		</tbody>
	</table>
	<?php /* tag "h3" from line 88 */; ?>
<h3 align="center">CÁM ƠN QUÝ KHÁCH, HẸN GẶP LẠI !</h3>
</font><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from D:\AppWebServer\SPN_Cafe\cafecoirieng\mvc\templates\SellingTablePrint.html (edit that file instead) */; ?>