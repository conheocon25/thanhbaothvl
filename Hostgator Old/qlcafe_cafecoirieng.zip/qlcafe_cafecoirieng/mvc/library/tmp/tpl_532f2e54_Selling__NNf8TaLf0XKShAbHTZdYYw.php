<?php 
function tpl_532f2e54_Selling__NNf8TaLf0XKShAbHTZdYYw(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
	<?php /* tag "head" from line 3 */; ?>
<head>
		<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>
		
	</head>
	<?php /* tag "body" from line 7 */; ?>
<body>
		<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/StyleTools', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 10 */; ?>
<div id="sidebar">
			<?php /* tag "ul" from line 11 */; ?>
<ul>
				<?php 
/* tag "li" from line 12 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Domain = new PHPTAL_RepeatController($ctx->DomainAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Domain as $ctx->Domain): ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Domain, 'getId')))):  ;
$_tmp_2 = ' alt="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li class="Domain"<?php echo $_tmp_2 ?>
>
					<?php /* tag "a" from line 13 */; ?>
<a><?php /* tag "i" from line 13 */; ?>
<i class="glyphicons-show_big_thumbnails"></i><?php /* tag "span" from line 13 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Domain, 'getName')); ?>
</span></a>
				</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

				<?php 
/* tag "li" from line 15 */ ;
if (null !== ($_tmp_2 = ('101'))):  ;
$_tmp_2 = ' alt="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li class="Domain"<?php echo $_tmp_2 ?>
>
					<?php /* tag "a" from line 16 */; ?>
<a><?php /* tag "i" from line 16 */; ?>
<i class="glyphicons-show_big_thumbnails"></i>CHƯA CÓ KHÁCH</a>
				</li>
				<?php 
/* tag "li" from line 18 */ ;
if (null !== ($_tmp_1 = ('102'))):  ;
$_tmp_1 = ' alt="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<li class="Domain"<?php echo $_tmp_1 ?>
>
					<?php /* tag "a" from line 19 */; ?>
<a><?php /* tag "i" from line 19 */; ?>
<i class="glyphicons-show_big_thumbnails"></i>ĐANG CÓ KHÁCH</a>
				</li>
			</ul>
		</div>
		<?php /* tag "div" from line 23 */; ?>
<div id="content">
			<?php 
/* tag "div" from line 24 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/ContentHeader', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php 
/* tag "div" from line 25 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/LocationBar', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php /* tag "div" from line 26 */; ?>
<div class="row">
				<?php /* tag "div" from line 27 */; ?>
<div class="col-4">
					<?php /* tag "div" from line 28 */; ?>
<div id="TableAll"></div>
					<?php /* tag "div" from line 29 */; ?>
<div class="widget-box">
						<?php /* tag "div" from line 30 */; ?>
<div class="controls">
							<?php /* tag "input" from line 31 */; ?>
<input id="SearchName" type="text" placeholder="Nhập tìm món ..." style="width:55%;"/>
							<?php 
/* tag "a" from line 32 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->ConfigCategoryAuto, 'getValue')))):  ;
$_tmp_2 = ' data-id-category="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a href="#DialogInsCourse" class="btn" data-toggle="modal"<?php echo $_tmp_2 ?>
>
								<?php /* tag "i" from line 33 */; ?>
<i class="glyphicons-plus"></i>
							</a>
							<?php /* tag "a" from line 35 */; ?>
<a class="btn RemoveCourseSearch">
								<?php /* tag "i" from line 36 */; ?>
<i class="glyphicons-circle_remove"></i>
							</a>							
						</div>
					</div>
					<?php /* tag "div" from line 40 */; ?>
<div id="CourseF"></div>
				</div>
				
				<!-- BẬT / TẮT MÀN HÌNH GỌI MÓN !-->
				<?php 
/* tag "div" from line 44 */ ;
if (!($ctx->path($ctx->ConfigSwitchBoardCall, 'getValue'))):  ;
?>
<div class="col-8"><?php /* tag "div" from line 44 */; ?>
<div id="Session"></div></div><?php endif; ?>

				<?php 
/* tag "div" from line 45 */ ;
if ($ctx->path($ctx->ConfigSwitchBoardCall, 'getValue')):  ;
?>
<div class="col-5"><?php /* tag "div" from line 45 */; ?>
<div id="Session"></div></div><?php endif; ?>

				
				<?php 
/* tag "div" from line 47 */ ;
if ($ctx->path($ctx->ConfigSwitchBoardCall, 'getValue')):  ;
?>
<div class="col-3">
					<?php /* tag "div" from line 48 */; ?>
<div class="accordion widget-box" id="collapse-group">						
						<?php /* tag "div" from line 49 */; ?>
<div class="accordion-group widget-box">
							<?php /* tag "div" from line 50 */; ?>
<div class="accordion-heading">
								<?php /* tag "div" from line 51 */; ?>
<div class="widget-title">
									<?php 
/* tag "a" from line 52 */ ;
if (null !== ($_tmp_1 = ('#Top10'))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a data-parent="#collapse-group" data-toggle="collapse"<?php echo $_tmp_1 ?>
>
										<?php /* tag "span" from line 53 */; ?>
<span class="icon"><?php /* tag "i" from line 53 */; ?>
<i class="glyphicons-fast_food"></i></span><?php /* tag "h5" from line 53 */; ?>
<h5><?php echo 'Top10'; ?>
</h5>
									</a>
								</div>
							</div>							
							<?php /* tag "div" from line 57 */; ?>
<div class="collapse in accordion-body" id="Top10">
								<?php /* tag "div" from line 58 */; ?>
<div class="widget-content nopadding size-12">
									<?php /* tag "ul" from line 59 */; ?>
<ul class="activity-list">
										<?php 
/* tag "li" from line 60 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->T = new PHPTAL_RepeatController($ctx->Top10)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->T as $ctx->T): ;
?>
<li>											
											<?php 
/* tag "a" from line 61 */ ;
if (null !== ($_tmp_1 = ($ctx->T->getCourse()->getName() . ' ' . $ctx->T->getCourse()->getPrice1Print()))):  ;
$_tmp_1 = ' data-original-title="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a class="course-item tip-left"<?php echo $_tmp_1 ?>
>
												<?php 
/* tag "strong" from line 62 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->T, 'getCourse/getId')))):  ;
$_tmp_3 = ' alt="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
if (null !== ($_tmp_4 = ('plus'))):  ;
$_tmp_4 = ' data-delta="'.phptal_escape($_tmp_4).'"' ;
else:  ;
$_tmp_4 = '' ;
endif ;
?>
<strong class="Course"<?php echo $_tmp_3 ?>
<?php echo $_tmp_4 ?>
><?php echo phptal_escape($ctx->path($ctx->T, 'getCourse/getShortName')); ?>
</strong>
											</a>
										</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</ul>
								</div>
							</div>
						</div>
						<?php 
/* tag "div" from line 69 */ ;
$_tmp_3 = $ctx->repeat ;
$_tmp_3->Category = new PHPTAL_RepeatController($ctx->CategoryAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_3->Category as $ctx->Category): ;
?>
<div class="accordion-group widget-box">
							<?php 
/* tag "div" from line 70 */ ;
if ($ctx->path($ctx->Category, 'getEnable')):  ;
?>
<div class="accordion-heading">
								<?php /* tag "div" from line 71 */; ?>
<div class="widget-title">
									<?php 
/* tag "a" from line 72 */ ;
if (null !== ($_tmp_4 = ('#'.$ctx->Category->getIdString()))):  ;
$_tmp_4 = ' href="'.phptal_escape($_tmp_4).'"' ;
else:  ;
$_tmp_4 = '' ;
endif ;
?>
<a data-parent="#collapse-group" data-toggle="collapse"<?php echo $_tmp_4 ?>
>
										<?php /* tag "span" from line 73 */; ?>
<span class="icon"><?php /* tag "i" from line 73 */; ?>
<i class="glyphicons-fast_food"></i></span><?php /* tag "h5" from line 73 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Category, 'getName')); ?>
</h5>
									</a>
								</div>
							</div><?php endif; ?>

							<?php 
/* tag "div" from line 77 */ ;
if ($ctx->path($ctx->Category, 'getEnable')):  ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->Category, 'getIdString')))):  ;
$_tmp_1 = ' id="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<div class="collapse accordion-body"<?php echo $_tmp_1 ?>
>
								<?php /* tag "div" from line 78 */; ?>
<div class="widget-content nopadding size-12">
									<?php /* tag "ul" from line 79 */; ?>
<ul class="activity-list">
										<?php 
/* tag "li" from line 80 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->Course = new PHPTAL_RepeatController($ctx->path($ctx->Category, 'getCourseAll'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->Course as $ctx->Course): ;
?>
<li>
											<?php /* tag "a" from line 81 */; ?>
<a class="course-item">
												<?php 
/* tag "button" from line 82 */ ;
if (null !== ($_tmp_4 = ($ctx->path($ctx->Course, 'getId')))):  ;
$_tmp_4 = ' alt="'.phptal_escape($_tmp_4).'"' ;
else:  ;
$_tmp_4 = '' ;
endif ;
if (null !== ($_tmp_5 = ('plus'))):  ;
$_tmp_5 = ' data-delta="'.phptal_escape($_tmp_5).'"' ;
else:  ;
$_tmp_5 = '' ;
endif ;
?>
<button class="Course pull-left"<?php echo $_tmp_4 ?>
<?php echo $_tmp_5 ?>
>+</button>
												<?php /* tag "strong" from line 83 */; ?>
<strong><?php echo phptal_escape($ctx->path($ctx->Course, 'getName')); ?>
</strong>
												<?php 
/* tag "button" from line 84 */ ;
if (null !== ($_tmp_4 = ($ctx->path($ctx->Course, 'getId')))):  ;
$_tmp_4 = ' alt="'.phptal_escape($_tmp_4).'"' ;
else:  ;
$_tmp_4 = '' ;
endif ;
if (null !== ($_tmp_5 = ('minus'))):  ;
$_tmp_5 = ' data-delta="'.phptal_escape($_tmp_5).'"' ;
else:  ;
$_tmp_5 = '' ;
endif ;
?>
<button class="Course pull-right"<?php echo $_tmp_4 ?>
<?php echo $_tmp_5 ?>
>-</button>
											</a>											
										</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

									</ul>
								</div>
							</div><?php endif; ?>

						</div><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

					</div>
				</div><?php endif; ?>

			</div>			
		</div>
		<?php /* tag "div" from line 95 */; ?>
<div id="TableActive"></div>
		<?php 
/* tag "div" from line 96 */ ;
if (null !== ($_tmp_4 = ($ctx->path($ctx->Domain, 'getId')))):  ;
$_tmp_4 = ' alt="'.phptal_escape($_tmp_4).'"' ;
else:  ;
$_tmp_4 = '' ;
endif ;
?>
<div id="DomainActive"<?php echo $_tmp_4 ?>
></div>
									
		<!-- END INSERT DIALOG  -->
		<?php 
/* tag "div" from line 99 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php 
/* tag "div" from line 100 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mAdmin.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

        <?php /* tag "script" from line 101 */; ?>
<script>			
			var nCountNotify = 0;
			$.extend($.gritter.options, { 
				position: 'bottom-left',
				fade_in_speed: 'medium', 
				fade_out_speed: 2000 
			});
						
			//NẠP DANH SÁCH CÁC BÀN			
			$('.Domain').click(function(){
				var IdDomain = $(this).attr('alt');				
				$("#DomainActive").attr('alt', IdDomain);
				$("#TableAll").load("/selling/load/domain/"+IdDomain);
				$(this).toggleClass('active').siblings().removeClass('active');
				$("#SearchName").focus();
			});
			$('.Domain:first').click();
			
			//-----------------------------------------------------------------------------------
			//Insert 1 COURSE
			$('#URLInsCourseButton').click(function(){
				var Data = [];
				Data[0] = 'null';								
				Data[1] = 22;
				Data[2] = $('#CName1').val();
				Data[3] = $('#CShortName1').val();
				Data[4] = $('#CUnit1').val();
				Data[5] = $('#CPrice1').val();
				Data[6] = $('#CPrice1').val();
				Data[7] = $('#CPrice1').val();
				Data[8] = $('#CPrice1').val();
				Data[9] = "";
				Data[10] = $('#CPrepare1').val();
				Data[11] = 0;
				
				var URL = "/object/ins/Course";
				$.ajax({
					type: "POST",
					data: {Data:Data},
					url: URL,
					success: function(msg){
						location.reload();
					}
				});
			});
			
			//---------------------------------------------------------------------------
			//Xử lí search tên			
			$('#SearchName').keyup(function(e){
				var Name 		= $(this).val();										
				$("#CourseF").load("/selling/search/course", { Name: Name });
			});
			
			//-----------------------------------------------------------------------------------
			//CALL COURSE
			$(".RemoveCourseSearch").click(function(){
				$("#CourseF").html("");
			});
									
			//Mặc định vào ô tìm kiếm
			$("#SearchName").focus();
			
        </script>
	</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcafe_cafecoirieng/mvc/templates/Selling.html (edit that file instead) */; ?>