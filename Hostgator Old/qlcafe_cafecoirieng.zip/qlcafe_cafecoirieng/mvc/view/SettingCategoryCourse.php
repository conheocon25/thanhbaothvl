<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingCategoryCourse.html");
	$Out = $Viewer->html();
	unset($Viewer);
	echo $Out;
?>
