<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/SettingTermCollect.html");
	echo $Viewer->html();
?>
