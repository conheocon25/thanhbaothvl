<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/Import.html");
	echo $Viewer->html();
?>
