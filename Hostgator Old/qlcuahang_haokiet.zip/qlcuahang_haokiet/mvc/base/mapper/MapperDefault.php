<?php		
	$mEmployee 		= new \MVC\Mapper\Employee();
	$mDomain 		= new \MVC\Mapper\Domain();
	$mSupplier 		= new \MVC\Mapper\Supplier();			
	$mResource 		= new \MVC\Mapper\Resource();	
	$mOrderImport 	= new \MVC\Mapper\OrderImport();
	$mCustomer 		= new \MVC\Mapper\Customer();
	$mTermPaid 		= new \MVC\Mapper\TermPaid();
	$mTermCollect 	= new \MVC\Mapper\TermCollect();
	$mUser 			= new \MVC\Mapper\User();			
	$mConfig 		= new \MVC\Mapper\Config();
?>