<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/ASettingTermPaid.html");
	echo $Viewer->html();
?>
