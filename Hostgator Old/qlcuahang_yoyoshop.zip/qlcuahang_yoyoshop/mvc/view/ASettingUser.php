<?php
	require_once("mvc/base/Viewer.php");
	$Viewer = new Viewer("mvc/templates/ASettingUser.html");
	echo $Viewer->html();
?>
