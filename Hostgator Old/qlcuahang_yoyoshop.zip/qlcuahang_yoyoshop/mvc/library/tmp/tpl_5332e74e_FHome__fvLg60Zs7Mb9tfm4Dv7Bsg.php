<?php 
function tpl_5332e74e_FHome__fvLg60Zs7Mb9tfm4Dv7Bsg(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
  <?php /* tag "head" from line 3 */; ?>
<head>
	<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

	<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </head>

  <?php /* tag "body" from line 8 */; ?>
<body>
	<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

    <?php /* tag "div" from line 10 */; ?>
<div class="container">
        <?php 
/* tag "div" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/PageTitle', $_thistpl) ;
$ctx->popSlots() ;
?>

        <?php 
/* tag "div" from line 12 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Menu', $_thistpl) ;
$ctx->popSlots() ;
?>


      <?php /* tag "div" from line 14 */; ?>
<div class="row-fluid">
        <?php /* tag "div" from line 15 */; ?>
<div class="span12">
        <?php /* tag "div" from line 16 */; ?>
<div class="carousel slide" id="myCarousel">
            <?php /* tag "div" from line 17 */; ?>
<div class="carousel-inner">
              <?php /* tag "div" from line 18 */; ?>
<div class="item">
                <?php /* tag "img" from line 19 */; ?>
<img alt="" src="/mvc/templates/front/img/slider1.png"/>
                <?php /* tag "div" from line 20 */; ?>
<div class="carousel-caption">
                  <?php /* tag "h4" from line 21 */; ?>
<h4>First Thumbnail label</h4>
                  <?php /* tag "p" from line 22 */; ?>
<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                </div>
              </div>
              <?php /* tag "div" from line 25 */; ?>
<div class="item active">
                <?php /* tag "img" from line 26 */; ?>
<img alt="" src="/mvc/templates/front/img/slider2.png"/>
                <?php /* tag "div" from line 27 */; ?>
<div class="carousel-caption">
                  <?php /* tag "h4" from line 28 */; ?>
<h4>Second Thumbnail label</h4>
                  <?php /* tag "p" from line 29 */; ?>
<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                </div>
              </div>
              <?php /* tag "div" from line 32 */; ?>
<div class="item">
                <?php /* tag "img" from line 33 */; ?>
<img alt="" src="/mvc/templates/front/img/slider3.png"/>
                <?php /* tag "div" from line 34 */; ?>
<div class="carousel-caption">
                  <?php /* tag "h4" from line 35 */; ?>
<h4>Third Thumbnail label</h4>
                  <?php /* tag "p" from line 36 */; ?>
<p>Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id elit non mi porta gravida at eget metus. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                </div>
              </div>
            </div>
            <?php /* tag "a" from line 40 */; ?>
<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
            <?php /* tag "a" from line 41 */; ?>
<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
          </div>
        </div>
      </div>
      
      <?php /* tag "div" from line 46 */; ?>
<div class="row-fluid">
        <?php /* tag "div" from line 47 */; ?>
<div class="span12">
            <?php /* tag "div" from line 48 */; ?>
<div class="page-header">
                <?php /* tag "h1" from line 49 */; ?>
<h1>Bán chạy <?php /* tag "small" from line 49 */; ?>
<small>Các sản phẩm bán chạy nhất trong tháng này</small></h1>
            </div>
        </div>
      </div>      
      <?php /* tag "div" from line 53 */; ?>
<div class="row-fluid">
        <?php /* tag "ul" from line 54 */; ?>
<ul class="thumbnails">
			<?php 
/* tag "li" from line 55 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Resource = new PHPTAL_RepeatController($ctx->ResourceAll1)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Resource as $ctx->Resource): ;
?>
<li class="span3">
              <?php /* tag "div" from line 56 */; ?>
<div class="thumbnail">
                <?php 
/* tag "a" from line 57 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Resource, 'getURLView')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>
					<?php 
/* tag "img" from line 58 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Resource, 'getImageAll/current/getURL')))):  ;
$_tmp_3 = ' src="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<img alt=""<?php echo $_tmp_3 ?>
/>
				</a>
                <?php /* tag "div" from line 60 */; ?>
<div class="caption">
                  <?php /* tag "h5" from line 61 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Resource, 'getName')); ?>
</h5>
                  <?php /* tag "p" from line 62 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->Resource, 'getPrice2Print')); ?>
</p>
                  <?php /* tag "p" from line 63 */; ?>
<p>Có sẵn</p>
                </div>
              </div>
            </li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

        </ul>
      </div>
      
      <?php /* tag "div" from line 70 */; ?>
<div class="row-fluid">
        <?php /* tag "div" from line 71 */; ?>
<div class="span12">
            <?php /* tag "div" from line 72 */; ?>
<div class="page-header">
                <?php /* tag "h1" from line 73 */; ?>
<h1>Hàng mới về <?php /* tag "small" from line 73 */; ?>
<small>Sản phẩm mới nhất trong tháng</small></h1>
            </div>
        </div>
      </div>
      
      <?php /* tag "div" from line 78 */; ?>
<div class="row-fluid">
        <?php /* tag "ul" from line 79 */; ?>
<ul class="thumbnails">
			<?php 
/* tag "li" from line 80 */ ;
$_tmp_3 = $ctx->repeat ;
$_tmp_3->Resource = new PHPTAL_RepeatController($ctx->ResourceAll2)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_3->Resource as $ctx->Resource): ;
?>
<li class="span3">
              <?php /* tag "div" from line 81 */; ?>
<div class="thumbnail">
                <?php 
/* tag "a" from line 82 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Resource, 'getURLView')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>
					<?php 
/* tag "img" from line 83 */ ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->Resource, 'getImageAll/current/getURL')))):  ;
$_tmp_1 = ' src="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<img alt=""<?php echo $_tmp_1 ?>
/>
				</a>
                <?php /* tag "div" from line 85 */; ?>
<div class="caption">
                  <?php /* tag "h5" from line 86 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Resource, 'getName')); ?>
</h5>
                  <?php /* tag "p" from line 87 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->Resource, 'getPrice2Print')); ?>
</p>
                  <?php /* tag "p" from line 88 */; ?>
<p>Có sẵn</p>
                </div>
              </div>
            </li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

        </ul>
      </div>
      
		<?php /* tag "div" from line 95 */; ?>
<div class="row-fluid">
			<?php /* tag "div" from line 96 */; ?>
<div class="span12">
				<?php /* tag "div" from line 97 */; ?>
<div class="page-header">
					<?php /* tag "h1" from line 98 */; ?>
<h1>Sản phẩm  ngẫu nhiên <?php /* tag "small" from line 98 */; ?>
<small>Các sản phẩm khác</small></h1>
				</div>
			</div>
		</div>      
		<?php /* tag "div" from line 102 */; ?>
<div class="row-fluid">
			<?php /* tag "ul" from line 103 */; ?>
<ul class="thumbnails">
				<?php 
/* tag "li" from line 104 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Resource = new PHPTAL_RepeatController($ctx->ResourceAll3)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Resource as $ctx->Resource): ;
?>
<li class="span3">
				  <?php /* tag "div" from line 105 */; ?>
<div class="thumbnail">
					<?php 
/* tag "a" from line 106 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Resource, 'getURLView')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>
						<?php 
/* tag "img" from line 107 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Resource, 'getImageAll/current/getURL')))):  ;
$_tmp_3 = ' src="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<img alt=""<?php echo $_tmp_3 ?>
/>
					</a>
					<?php /* tag "div" from line 109 */; ?>
<div class="caption">
					  <?php /* tag "h5" from line 110 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Resource, 'getName')); ?>
</h5>
					  <?php /* tag "p" from line 111 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->Resource, 'getPrice2Print')); ?>
</p>
					  <?php /* tag "p" from line 112 */; ?>
<p>Có sẵn</p>
					</div>
				  </div>
				</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

			</ul>
		</div>
		<?php 
/* tag "div" from line 118 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

    </div> <!-- /container -->
	<?php 
/* tag "div" from line 120 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_yoyoshop/mvc/templates/FHome.html (edit that file instead) */; ?>