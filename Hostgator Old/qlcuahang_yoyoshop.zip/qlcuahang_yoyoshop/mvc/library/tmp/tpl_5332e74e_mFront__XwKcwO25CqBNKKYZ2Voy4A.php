<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_Footer(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div>
		<?php /* tag "hr" from line 123 */; ?>
<hr/>      
		<?php /* tag "div" from line 124 */; ?>
<div class="row-fluid footer">
			<?php /* tag "div" from line 125 */; ?>
<div class="span3">
				<?php /* tag "h3" from line 126 */; ?>
<h3>Thông tin</h3>
				<?php /* tag "ul" from line 127 */; ?>
<ul>					
					<?php /* tag "li" from line 128 */; ?>
<li><?php /* tag "a" from line 128 */; ?>
<a href="/faq">FAQ</a></li>
					<?php /* tag "li" from line 129 */; ?>
<li><?php /* tag "a" from line 129 */; ?>
<a href="/chinh-sach">Chính sách điều khoản</a></li>
				</ul>
			</div>
			<?php /* tag "div" from line 132 */; ?>
<div class="span3">
				<?php /* tag "h3" from line 133 */; ?>
<h3>Nhận email</h3>
				<?php /* tag "ul" from line 134 */; ?>
<ul>					
					<?php /* tag "li" from line 135 */; ?>
<li>
						<?php /* tag "div" from line 136 */; ?>
<div class="control-group">
							<?php /* tag "div" from line 137 */; ?>
<div class="controls">
							  <?php /* tag "div" from line 138 */; ?>
<div class="input-prepend input-append">
								<?php /* tag "span" from line 139 */; ?>
<span class="add-on"><?php /* tag "i" from line 139 */; ?>
<i class="icon-envelope"></i></span><?php /* tag "input" from line 139 */; ?>
<input type="text" size="16" id="appendedPrependedInput" class="span6" placeholder="Nhập email bạn"/><?php /* tag "input" from line 139 */; ?>
<input type="submit" name="submit" value="Gửi" class="btn"/>
							  </div>
							</div>
						</div>
					</li>
					
				</ul>
				<?php /* tag "p" from line 146 */; ?>
<p></p>
			</div>
			<?php /* tag "div" from line 148 */; ?>
<div class="span3">
				<?php /* tag "h3" from line 149 */; ?>
<h3>Chi nhánh</h3>
				<?php /* tag "ul" from line 150 */; ?>
<ul>
					<?php /* tag "li" from line 151 */; ?>
<li><?php /* tag "a" from line 151 */; ?>
<a href="#">Chi nhánh 1</a></li>
					<?php /* tag "li" from line 152 */; ?>
<li><?php /* tag "a" from line 152 */; ?>
<a href="#">Chi nhánh 2</a></li>					
				</ul>
			</div>
			<?php /* tag "div" from line 155 */; ?>
<div class="span3">
				<?php /* tag "h3" from line 156 */; ?>
<h3>Kho hàng</h3>
				<?php /* tag "ul" from line 157 */; ?>
<ul>
					<?php /* tag "li" from line 158 */; ?>
<li><?php /* tag "a" from line 158 */; ?>
<a href="#">TP HCM</a></li>
					<?php /* tag "li" from line 159 */; ?>
<li><?php /* tag "a" from line 159 */; ?>
<a href="#">Đồng Nai</a></li>					
				</ul>
			</div>
		</div>
		<?php /* tag "hr" from line 163 */; ?>
<hr/>
		<?php /* tag "footer" from line 164 */; ?>
<footer>
			<?php /* tag "p" from line 165 */; ?>
<p>&copy; YoYoShop - Bản quyền 2009 - 2014</p>
		</footer>
	</div><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_Menu(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div class="row-fluid">
		<?php /* tag "div" from line 91 */; ?>
<div class="span12 nav-menus">
			<?php /* tag "ul" from line 92 */; ?>
<ul class="nav nav-pills">
				<?php 
/* tag "li" from line 93 */ ;
if (null !== ($_tmp_1 = ($ctx->Active=='Home'?'active':''))):  ;
$_tmp_1 = ' class="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<li<?php echo $_tmp_1 ?>
>
					<?php /* tag "a" from line 94 */; ?>
<a href="/trang-chu">Trang chủ</a>
				</li>
				<?php 
/* tag "li" from line 96 */ ;
if (null !== ($_tmp_1 = ($ctx->Active=='Introduction'?'active':''))):  ;
$_tmp_1 = ' class="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<li<?php echo $_tmp_1 ?>
>
					<?php /* tag "a" from line 97 */; ?>
<a href="/gioi-thieu">Giới thiệu</a>
				</li>
				<?php 
/* tag "li" from line 99 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Category = new PHPTAL_RepeatController($ctx->CategoryAll)
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Category as $ctx->Category): ;
?>
<li class="dropdown">
					<?php /* tag "a" from line 100 */; ?>
<a href="#" data-toggle="dropdown" class="dropdown-toggle">
						<?php /* tag "span" from line 101 */; ?>
<span><?php echo phptal_escape($ctx->path($ctx->Category, 'getName')); ?>
</span> <?php /* tag "b" from line 101 */; ?>
<b class="caret"></b>
						<?php /* tag "ul" from line 102 */; ?>
<ul class="dropdown-menu" id="menu1">							
							<?php 
/* tag "li" from line 103 */ ;
$_tmp_2 = $ctx->repeat ;
$_tmp_2->Category1 = new PHPTAL_RepeatController($ctx->path($ctx->Category, 'getCategoryAll'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_2->Category1 as $ctx->Category1): ;
?>
<li>
								<?php 
/* tag "a" from line 104 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Category1, 'getURLView')))):  ;
$_tmp_3 = ' href="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<a<?php echo $_tmp_3 ?>
><?php echo phptal_escape($ctx->path($ctx->Category1, 'getName')); ?>
</a>
							</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

						</ul>
					</a>
				</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>
				
				<?php 
/* tag "li" from line 109 */ ;
if (null !== ($_tmp_3 = ($ctx->Active=='Dealer'?'active':''))):  ;
$_tmp_3 = ' class="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<li<?php echo $_tmp_3 ?>
>
					<?php /* tag "a" from line 110 */; ?>
<a href="/khuyen-mai">Khuyến mãi</a>
				</li>
				<?php 
/* tag "li" from line 112 */ ;
if (null !== ($_tmp_2 = ($ctx->Active=='Contact'?'active':''))):  ;
$_tmp_2 = ' class="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<li<?php echo $_tmp_2 ?>
>
					<?php /* tag "a" from line 113 */; ?>
<a href="/lien-he">Liên hệ</a>
				</li>
			</ul>
		</div>
	</div><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_PageTitle(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div class="row-fluid">
		<?php /* tag "div" from line 71 */; ?>
<div class="span6 logo">
			<?php /* tag "h1" from line 72 */; ?>
<h1><?php /* tag "a" from line 72 */; ?>
<a href="#"><?php echo phptal_escape($ctx->path($ctx->ConfigName, 'getValue')); ?>
</a></h1>
			<?php /* tag "p" from line 73 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->ConfigSlogan, 'getValue')); ?>
</p>
		</div>
		<?php /* tag "div" from line 75 */; ?>
<div class="span6 account">
			<?php /* tag "ul" from line 76 */; ?>
<ul>
				<?php /* tag "li" from line 77 */; ?>
<li id="your-account"><?php /* tag "h4" from line 77 */; ?>
<h4><?php /* tag "a" from line 77 */; ?>
<a href="#">KHÁCH</a></h4>
					<?php /* tag "p" from line 78 */; ?>
<p>Chào mừng, <?php /* tag "a" from line 78 */; ?>
<a href="/dang-nhap">đăng nhập</a></p>
				</li>
				<?php /* tag "li" from line 80 */; ?>
<li><?php /* tag "h4" from line 80 */; ?>
<h4><?php /* tag "a" from line 80 */; ?>
<a href="/gio-hang">Giỏ hàng</a></h4>
					<?php /* tag "p" from line 81 */; ?>
<p><?php /* tag "strong" from line 81 */; ?>
<strong>1 Sản phẩm</strong></p>
				</li>
			</ul>
		</div>
	</div><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_Header(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<div class="navbar navbar-fixed-top">
		<?php /* tag "div" from line 44 */; ?>
<div class="navbar-inner">
			<?php /* tag "div" from line 45 */; ?>
<div class="container">
				<?php /* tag "a" from line 46 */; ?>
<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<?php /* tag "span" from line 47 */; ?>
<span class="icon-bar"></span>
					<?php /* tag "span" from line 48 */; ?>
<span class="icon-bar"></span>
					<?php /* tag "span" from line 49 */; ?>
<span class="icon-bar"></span>
				</a>

				<?php /* tag "div" from line 52 */; ?>
<div class="nav-collapse">
					<?php /* tag "ul" from line 53 */; ?>
<ul class="nav pull-right">
						<?php /* tag "li" from line 54 */; ?>
<li class="dropdown">
							<?php /* tag "a" from line 55 */; ?>
<a data-toggle="dropdown" class="dropdown-toggle" href="#">Tài khoản <?php /* tag "b" from line 55 */; ?>
<b class="caret"></b></a>
							<?php /* tag "ul" from line 56 */; ?>
<ul class="dropdown-menu">
								<?php /* tag "li" from line 57 */; ?>
<li><?php /* tag "a" from line 57 */; ?>
<a href="/dang-ki">Đăng ký</a></li>
								<?php /* tag "li" from line 58 */; ?>
<li><?php /* tag "a" from line 58 */; ?>
<a href="/dang-nhap">Đăng nhập</a></li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_IncludeJS(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>						
		<?php /* tag "script" from line 35 */; ?>
<script src="/mvc/templates/front/js/jquery-1.7.2.min.js"></script>
		<?php /* tag "script" from line 36 */; ?>
<script src="/mvc/templates/front/js/bootstrap.min.js"></script>
		<?php /* tag "script" from line 37 */; ?>
<script src="/mvc/templates/front/js/script.js"></script>
	</span><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_IncludeCSS(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>	
		<?php /* tag "link" from line 26 */; ?>
<link href="/mvc/templates/front/css/bootstrap.css" rel="stylesheet"/>
		<?php /* tag "link" from line 27 */; ?>
<link href="/mvc/templates/front/css/style.css" rel="stylesheet"/>
		<?php /* tag "link" from line 28 */; ?>
<link href="/mvc/templates/front/css/bootstrap-responsive.css" rel="stylesheet"/>
	</span><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A_IncludeMETA(PHPTAL $_thistpl, PHPTAL $tpl) {
$tpl = clone $tpl ;
$ctx = $tpl->getContext() ;
$_translator = $tpl->getTranslator() ;
?>
<span>
		<?php /* tag "title" from line 7 */; ?>
<title><?php echo 'Hệ thống quản lý cửa hàng quần áo'; ?>
</title>
		<?php /* tag "base" from line 8 */; ?>
<base href="http://yoyoshop.quanly-cuahang.com"/>
		<?php /* tag "meta" from line 9 */; ?>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		<?php /* tag "meta" from line 10 */; ?>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
		<?php /* tag "meta" from line 11 */; ?>
<meta http-equiv="Pragma" content="no-cache"/>
		<?php /* tag "meta" from line 12 */; ?>
<meta http-equiv="Expires" content="-1"/>
		<?php /* tag "meta" from line 13 */; ?>
<meta http-equiv="Cache-Control" content="no-cache"/>
		<?php /* tag "meta" from line 14 */; ?>
<meta name="keywords" content="Hệ thống quản lý cửa hàng quần áo"/>
		<?php /* tag "meta" from line 15 */; ?>
<meta name="description" content="Hệ thống quản lý cửa hàng quần áo"/>
		<?php /* tag "meta" from line 16 */; ?>
<meta name="page-topic" content="Hệ thống quản lý cửa hàng quần áo"/>
		<?php /* tag "meta" from line 17 */; ?>
<meta name="Abstract" content="Hệ thống quản lý cửa hàng quần áo"/>
		<?php /* tag "meta" from line 18 */; ?>
<meta name="classification" content="Hệ thống quản lý cửa hàng quần áo"/>
		<?php /* tag "link" from line 19 */; ?>
<link rel="shortcut icon" type="image/png" href="/data/images/icon.ico"/>
	</span><?php 
}

 ?>
<?php 
function tpl_5332e74e_mFront__XwKcwO25CqBNKKYZ2Voy4A(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
/* tag "html" from line 1 */ ;
?>
<html lang="en" xml:lang="en">
<?php /* tag "body" from line 2 */; ?>
<body>
	<!-- ======================================================================== -->
	<!-- META TAG INCLUDE														  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 6 */; ?>

	
	<!-- ======================================================================== -->
	<!-- CASCADING STYLE SHEETS INCLUDE											  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 25 */; ?>

	
	<!-- ======================================================================== -->
	<!-- JAVASCRIPT INCLUDE														  -->
	<!-- ======================================================================== -->
	<?php /* tag "span" from line 34 */; ?>

	
	<!-- ======================================================================== -->
	<!-- HEADER																	  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 43 */; ?>

	
	<!-- ======================================================================== -->
	<!-- PAGE TITLE																  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 70 */; ?>

	
	<!-- ======================================================================== -->
	<!-- MENU																	  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 90 */; ?>

	
	<!-- ======================================================================== -->
	<!-- FOOTER																	  -->
	<!-- ======================================================================== -->
	<?php /* tag "div" from line 122 */; ?>

	
</body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_yoyoshop/mvc/templates/mFront.xhtml (edit that file instead) */; ?>