<?php 
function tpl_5332e74e_FProduct__dJlBgryeFZiiImGeaZRaGQ(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
  <?php /* tag "head" from line 3 */; ?>
<head>
	<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

	<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </head>

  <?php /* tag "body" from line 8 */; ?>
<body>
	<?php 
/* tag "div" from line 9 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

    

    <?php /* tag "div" from line 12 */; ?>
<div class="container">
        <?php 
/* tag "div" from line 13 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/PageTitle', $_thistpl) ;
$ctx->popSlots() ;
?>

        <?php 
/* tag "div" from line 14 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Menu', $_thistpl) ;
$ctx->popSlots() ;
?>

           
		<?php /* tag "div" from line 16 */; ?>
<div class="row-fluid">
			<?php /* tag "div" from line 17 */; ?>
<div class="span3">
				<?php /* tag "div" from line 18 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 19 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 20 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 21 */; ?>
<li>Cart</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 25 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 26 */; ?>
<div class="span12 cart">
						<?php /* tag "ul" from line 27 */; ?>
<ul>
							<?php /* tag "li" from line 28 */; ?>
<li>
								<?php /* tag "div" from line 29 */; ?>
<div class="span8 pull-left">1 <?php /* tag "a" from line 29 */; ?>
<a href="product_detail.html" rel="tooltip" title="See detail">Blackbox</a> <?php /* tag "span" from line 29 */; ?>
<span>[ 26 ]</span></div>
								<?php /* tag "div" from line 30 */; ?>
<div class="span4 pull-right">$54.00 <?php /* tag "a" from line 30 */; ?>
<a href="#" class="t-right no-underline" rel="tooltip" title="Remove this product from my cart">X</a></div>
							</li>
							<?php /* tag "li" from line 32 */; ?>
<li>
								<?php /* tag "div" from line 33 */; ?>
<div class="span8 pull-left">1 <?php /* tag "a" from line 33 */; ?>
<a href="product_detail.html" rel="tooltip" title="See detail">JunkShirt</a> <?php /* tag "span" from line 33 */; ?>
<span>[ M ]</span></div>
								<?php /* tag "div" from line 34 */; ?>
<div class="span4 pull-right">$16.00 <?php /* tag "a" from line 34 */; ?>
<a href="#" class="t-right no-underline" rel="tooltip" title="Remove this product from my cart">X</a></div>
							</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 39 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 40 */; ?>
<div class="span12 total-price">
						<?php /* tag "ul" from line 41 */; ?>
<ul>
							<?php /* tag "li" from line 42 */; ?>
<li>
								<?php /* tag "div" from line 43 */; ?>
<div class="span8 pull-left">Shipping</div>
								<?php /* tag "div" from line 44 */; ?>
<div class="span4 pull-right">$1.00</div>
							</li>
							<?php /* tag "li" from line 46 */; ?>
<li>
								<?php /* tag "div" from line 47 */; ?>
<div class="span8 pull-left">Total</div>
								<?php /* tag "div" from line 48 */; ?>
<div class="span4 pull-right">$71.00</div>
							</li>
							<?php /* tag "li" from line 50 */; ?>
<li class="form-inline">
								<?php /* tag "div" from line 51 */; ?>
<div class="span12"><?php /* tag "a" from line 51 */; ?>
<a href="cart.html" class="btn pull-left">Cart</a><?php /* tag "a" from line 51 */; ?>
<a href="login.html" class="btn btn-inverse pull-right">Checkout</a></div>
							</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 56 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 57 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 58 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 59 */; ?>
<li>Special Offers</li>
						</ul>
					</div>
				</div>
				
				<?php /* tag "div" from line 64 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 65 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 66 */; ?>
<ul class="thumbnails">
							<?php /* tag "li" from line 67 */; ?>
<li class="span12">
								<?php /* tag "div" from line 68 */; ?>
<div class="thumbnail">
									<?php 
/* tag "a" from line 69 */ ;
if (null !== ($_tmp_1 = ($ctx->path($ctx->Resource, 'getURLView')))):  ;
$_tmp_1 = ' href="'.phptal_escape($_tmp_1).'"' ;
else:  ;
$_tmp_1 = '' ;
endif ;
?>
<a<?php echo $_tmp_1 ?>
>
										<?php 
/* tag "img" from line 70 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Resource, 'getImageAll/current/getURL')))):  ;
$_tmp_2 = ' src="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<img alt=""<?php echo $_tmp_2 ?>
/>
									</a>
									<?php /* tag "div" from line 72 */; ?>
<div class="caption">
										<?php /* tag "h5" from line 73 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Resource, 'getName')); ?>
</h5>
										<?php /* tag "p" from line 74 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->Resource, 'getPrice2Print')); ?>
</p>
										<?php /* tag "p" from line 75 */; ?>
<p>Có sẵn</p>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 82 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 83 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 84 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 85 */; ?>
<li>Category</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 89 */; ?>
<div class="row-fluid">
					<?php /* tag "ul" from line 90 */; ?>
<ul class="nav nav-tabs nav-stacked">
						<?php /* tag "li" from line 91 */; ?>
<li class="active"><?php /* tag "a" from line 91 */; ?>
<a href="#">Acessories</a></li>
						<?php /* tag "li" from line 92 */; ?>
<li><?php /* tag "a" from line 92 */; ?>
<a href="categories.html">Girl</a></li>
						<?php /* tag "li" from line 93 */; ?>
<li><?php /* tag "a" from line 93 */; ?>
<a href="categories.html">Boy</a></li>
						<?php /* tag "li" from line 94 */; ?>
<li><?php /* tag "a" from line 94 */; ?>
<a href="categories.html">Edition</a></li>
					</ul>
				</div>
				<?php /* tag "div" from line 97 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 98 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 99 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 100 */; ?>
<li>Payment Confirmation</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 104 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 105 */; ?>
<div class="span12">
						<?php /* tag "p" from line 106 */; ?>
<p>Already make a payment ? please confirm your payment by filling <?php /* tag "a" from line 106 */; ?>
<a href="confirm.html">this form</a></p>
					</div>
				</div>
			</div>
			<?php /* tag "div" from line 110 */; ?>
<div class="span9">
				<?php /* tag "div" from line 111 */; ?>
<div class="row-fluid">
					<?php /* tag "ul" from line 112 */; ?>
<ul class="breadcrumb">
						<?php /* tag "li" from line 113 */; ?>
<li><?php /* tag "a" from line 113 */; ?>
<a href="#">Home</a> <?php /* tag "span" from line 113 */; ?>
<span class="divider">/</span></li>
						<?php /* tag "li" from line 114 */; ?>
<li><?php /* tag "a" from line 114 */; ?>
<a href="#">Girl</a> <?php /* tag "span" from line 114 */; ?>
<span class="divider">/</span></li>
						<?php /* tag "li" from line 115 */; ?>
<li><?php /* tag "a" from line 115 */; ?>
<a href="#">Pants</a> <?php /* tag "span" from line 115 */; ?>
<span class="divider">/</span></li>
						<?php /* tag "li" from line 116 */; ?>
<li class="active">Blackbox</li>
					</ul>
				</div>
				<?php /* tag "div" from line 119 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 120 */; ?>
<div class="span6 product">
						<?php /* tag "div" from line 121 */; ?>
<div class="carousel slide" id="myCarousel">
							<?php /* tag "div" from line 122 */; ?>
<div class="carousel-inner">
								<?php /* tag "div" from line 123 */; ?>
<div class="item">
									<?php /* tag "img" from line 124 */; ?>
<img alt="" src="/mvc/templates/front/img/product1.jpg"/>
								</div>
								<?php /* tag "div" from line 126 */; ?>
<div class="item active">
									<?php /* tag "img" from line 127 */; ?>
<img alt="" src="/mvc/templates/front/img/product11.jpg"/>
								</div>
								<?php /* tag "div" from line 129 */; ?>
<div class="item">
									<?php /* tag "img" from line 130 */; ?>
<img alt="" src="/mvc/templates/front/img/product12.jpg"/>
								</div>
							</div>
							<?php /* tag "a" from line 133 */; ?>
<a class="left carousel-control" href="#myCarousel" data-slide="prev">&lsaquo;</a>
							<?php /* tag "a" from line 134 */; ?>
<a class="right carousel-control" href="#myCarousel" data-slide="next">&rsaquo;</a>
						</div>
					</div>
					<?php /* tag "div" from line 137 */; ?>
<div class="span6 product-detail">
						<?php /* tag "h3" from line 138 */; ?>
<h3>Blackbox</h3>
						<?php /* tag "p" from line 139 */; ?>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras quis mi quis purus consectetur adipiscing vel eget nibh. 
						Vivamus sed tortor massa, ac consequat sem. Suspendisse potenti. Donec blandit nibh luctus nibh dignissim vulputate. 
						Sed interdum, augue at pulvinar dapibus, libero nibh semper massa, ut feugiat leo tortor vitae ante. 
						Aliquam erat volutpat. Suspendisse luctus felis sit amet ipsum ornare eget commodo urna pharetra. 
						Duis hendrerit risus ac nulla mattis rhoncus. Praesent iaculis egestas purus et varius.</p>
						<?php /* tag "p" from line 144 */; ?>
<p><?php /* tag "h2" from line 144 */; ?>
<h2>$54.00</h2></p>
						<?php /* tag "p" from line 145 */; ?>
<p>
							<?php /* tag "form" from line 146 */; ?>
<form class="form-horizontal">
								<?php /* tag "div" from line 147 */; ?>
<div class="control-group">
									<?php /* tag "label" from line 148 */; ?>
<label for="select01" class="control-label t-left">Size</label>
									<?php /* tag "div" from line 149 */; ?>
<div class="controls">
										<?php /* tag "select" from line 150 */; ?>
<select id="select01" class="span10">
											<?php /* tag "option" from line 151 */; ?>
<option>- Choose your size -</option>
											<?php /* tag "option" from line 152 */; ?>
<option>26</option>
											<?php /* tag "option" from line 153 */; ?>
<option>27</option>
											<?php /* tag "option" from line 154 */; ?>
<option>28</option>
											<?php /* tag "option" from line 155 */; ?>
<option>29</option>
										</select>
									</div>
								</div>
								<?php /* tag "div" from line 159 */; ?>
<div class="control-group">
									<?php /* tag "label" from line 160 */; ?>
<label for="select01" class="control-label t-left">Quantity</label>
									<?php /* tag "div" from line 161 */; ?>
<div class="controls">
										<?php /* tag "input" from line 162 */; ?>
<input type="text" class="span4" value="1"/>
									</div>
								</div>
								<?php /* tag "div" from line 165 */; ?>
<div class="form-actions">
									<?php /* tag "button" from line 166 */; ?>
<button class="btn" type="submit">Add to Cart</button>
								</div>
							</form>
						</p>
					</div>
				</div>
			</div>
		</div>
      
     <?php 
/* tag "div" from line 175 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>


    </div> <!-- /container -->
	<?php 
/* tag "div" from line 178 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_yoyoshop/mvc/templates/FProduct.html (edit that file instead) */; ?>