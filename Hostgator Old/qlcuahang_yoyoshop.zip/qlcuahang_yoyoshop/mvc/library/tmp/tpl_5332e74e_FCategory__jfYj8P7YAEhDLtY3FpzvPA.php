<?php 
function tpl_5332e74e_FCategory__jfYj8P7YAEhDLtY3FpzvPA(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
  <?php /* tag "head" from line 3 */; ?>
<head>
	<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

	<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </head>
  <?php /* tag "body" from line 7 */; ?>
<body>
	<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 9 */; ?>
<div class="container">
			<?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/PageTitle', $_thistpl) ;
$ctx->popSlots() ;
?>

			<?php 
/* tag "div" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Menu', $_thistpl) ;
$ctx->popSlots() ;
?>

        
		<?php /* tag "div" from line 13 */; ?>
<div class="row-fluid">
			<?php /* tag "div" from line 14 */; ?>
<div class="span3">
				<?php /* tag "div" from line 15 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 16 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 17 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 18 */; ?>
<li>Cart</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 22 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 23 */; ?>
<div class="span12 cart">
						<?php /* tag "ul" from line 24 */; ?>
<ul>
							<?php /* tag "li" from line 25 */; ?>
<li>
								<?php /* tag "div" from line 26 */; ?>
<div class="span8 pull-left">1 <?php /* tag "a" from line 26 */; ?>
<a href="product_detail.html" rel="tooltip" title="See detail">Blackbox</a> <?php /* tag "span" from line 26 */; ?>
<span>[ 26 ]</span></div>
								<?php /* tag "div" from line 27 */; ?>
<div class="span4 pull-right">$54.00 <?php /* tag "a" from line 27 */; ?>
<a href="#" class="t-right no-underline" rel="tooltip" title="Remove this product from my cart">X</a></div>
							</li>
							<?php /* tag "li" from line 29 */; ?>
<li>
								<?php /* tag "div" from line 30 */; ?>
<div class="span8 pull-left">1 <?php /* tag "a" from line 30 */; ?>
<a href="product_detail.html" rel="tooltip" title="See detail">JunkShirt</a> <?php /* tag "span" from line 30 */; ?>
<span>[ M ]</span></div>
								<?php /* tag "div" from line 31 */; ?>
<div class="span4 pull-right">$16.00 <?php /* tag "a" from line 31 */; ?>
<a href="#" class="t-right no-underline" rel="tooltip" title="Remove this product from my cart">X</a></div>
							</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 36 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 37 */; ?>
<div class="span12 total-price">
						<?php /* tag "ul" from line 38 */; ?>
<ul>
							<?php /* tag "li" from line 39 */; ?>
<li>
								<?php /* tag "div" from line 40 */; ?>
<div class="span8 pull-left">Shipping</div>
								<?php /* tag "div" from line 41 */; ?>
<div class="span4 pull-right">$1.00</div>
							</li>
							<?php /* tag "li" from line 43 */; ?>
<li>
								<?php /* tag "div" from line 44 */; ?>
<div class="span8 pull-left">Total</div>
								<?php /* tag "div" from line 45 */; ?>
<div class="span4 pull-right">$71.00</div>
							</li>
								<?php /* tag "li" from line 47 */; ?>
<li class="form-inline">
								<?php /* tag "div" from line 48 */; ?>
<div class="span12"><?php /* tag "a" from line 48 */; ?>
<a href="cart.html" class="btn pull-left">Cart</a><?php /* tag "a" from line 48 */; ?>
<a href="login.html" class="btn btn-inverse pull-right">Checkout</a></div>
							</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 53 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 54 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 55 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 56 */; ?>
<li>Category</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 60 */; ?>
<div class="row-fluid">
					<?php /* tag "ul" from line 61 */; ?>
<ul class="nav nav-tabs nav-stacked">
						<?php /* tag "li" from line 62 */; ?>
<li class="active"><?php /* tag "a" from line 62 */; ?>
<a href="#">Acessories</a></li>
						<?php /* tag "li" from line 63 */; ?>
<li><?php /* tag "a" from line 63 */; ?>
<a href="#">Girl</a></li>
						<?php /* tag "li" from line 64 */; ?>
<li><?php /* tag "a" from line 64 */; ?>
<a href="#">Boy</a></li>
						<?php /* tag "li" from line 65 */; ?>
<li><?php /* tag "a" from line 65 */; ?>
<a href="#">Edition</a></li>
					</ul>
				</div>
				<?php /* tag "div" from line 68 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 69 */; ?>
<div class="span12">
						<?php /* tag "ul" from line 70 */; ?>
<ul class="breadcrumb">
							<?php /* tag "li" from line 71 */; ?>
<li>Payment Confirmation</li>
						</ul>
					</div>
				</div>
				<?php /* tag "div" from line 75 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 76 */; ?>
<div class="span12">
						<?php /* tag "p" from line 77 */; ?>
<p>Already make a payment ? please confirm your payment by filling <?php /* tag "a" from line 77 */; ?>
<a href="confirm.html">this form</a></p>
					</div>
				</div>
			</div>
			<?php /* tag "div" from line 81 */; ?>
<div class="span9">
				<?php /* tag "ul" from line 82 */; ?>
<ul class="breadcrumb">
					<?php /* tag "li" from line 83 */; ?>
<li><?php /* tag "a" from line 83 */; ?>
<a href="#">Home</a> <?php /* tag "span" from line 83 */; ?>
<span class="divider">/</span></li>
					<?php /* tag "li" from line 84 */; ?>
<li><?php /* tag "a" from line 84 */; ?>
<a href="#">Categories</a> <?php /* tag "span" from line 84 */; ?>
<span class="divider">/</span></li>
					<?php /* tag "li" from line 85 */; ?>
<li><?php /* tag "a" from line 85 */; ?>
<a href="#">Girl</a> <?php /* tag "span" from line 85 */; ?>
<span class="divider">/</span></li>
					<?php /* tag "li" from line 86 */; ?>
<li class="active">Pants</li>
				</ul>

				<?php /* tag "div" from line 89 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 90 */; ?>
<div class="span12">
						<?php /* tag "h3" from line 91 */; ?>
<h3>Pants</h3>
						<?php /* tag "hr" from line 92 */; ?>
<hr/>
						<?php /* tag "ul" from line 93 */; ?>
<ul class="thumbnails">
							<?php 
/* tag "li" from line 94 */ ;
$_tmp_1 = $ctx->repeat ;
$_tmp_1->Resource = new PHPTAL_RepeatController($ctx->path($ctx->Category, 'getResourceAll'))
 ;
$ctx = $tpl->pushContext() ;
foreach ($_tmp_1->Resource as $ctx->Resource): ;
?>
<li class="span4">
								<?php /* tag "div" from line 95 */; ?>
<div class="thumbnail">
									<?php 
/* tag "a" from line 96 */ ;
if (null !== ($_tmp_2 = ($ctx->path($ctx->Resource, 'getURLView')))):  ;
$_tmp_2 = ' href="'.phptal_escape($_tmp_2).'"' ;
else:  ;
$_tmp_2 = '' ;
endif ;
?>
<a<?php echo $_tmp_2 ?>
>
										<?php 
/* tag "img" from line 97 */ ;
if (null !== ($_tmp_3 = ($ctx->path($ctx->Resource, 'getImageAll/current/getURL')))):  ;
$_tmp_3 = ' src="'.phptal_escape($_tmp_3).'"' ;
else:  ;
$_tmp_3 = '' ;
endif ;
?>
<img alt=""<?php echo $_tmp_3 ?>
/>
									</a>
									<?php /* tag "div" from line 99 */; ?>
<div class="caption">
										<?php /* tag "h5" from line 100 */; ?>
<h5><?php echo phptal_escape($ctx->path($ctx->Resource, 'getName')); ?>
</h5>
										<?php /* tag "p" from line 101 */; ?>
<p><?php echo phptal_escape($ctx->path($ctx->Resource, 'getPrice2Print')); ?>
</p>
										<?php /* tag "p" from line 102 */; ?>
<p>Có sẵn</p>
									</div>
								</div>
							</li><?php 
endforeach ;
$ctx = $tpl->popContext() ;
?>

						</ul>
						<?php /* tag "div" from line 107 */; ?>
<div class="pagination">
							<?php /* tag "ul" from line 108 */; ?>
<ul>
								<?php /* tag "li" from line 109 */; ?>
<li class="disabled"><?php /* tag "a" from line 109 */; ?>
<a href="#">&laquo;</a></li>
								<?php /* tag "li" from line 110 */; ?>
<li class="active"><?php /* tag "a" from line 110 */; ?>
<a href="#">1</a></li>
								<?php /* tag "li" from line 111 */; ?>
<li><?php /* tag "a" from line 111 */; ?>
<a href="#">2</a></li>
								<?php /* tag "li" from line 112 */; ?>
<li><?php /* tag "a" from line 112 */; ?>
<a href="#">3</a></li>
								<?php /* tag "li" from line 113 */; ?>
<li><?php /* tag "a" from line 113 */; ?>
<a href="#">4</a></li>
								<?php /* tag "li" from line 114 */; ?>
<li><?php /* tag "a" from line 114 */; ?>
<a href="#">&raquo;</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
        <?php 
/* tag "div" from line 121 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		</div> <!-- /container -->
	<?php 
/* tag "div" from line 123 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_yoyoshop/mvc/templates/FCategory.html (edit that file instead) */; ?>