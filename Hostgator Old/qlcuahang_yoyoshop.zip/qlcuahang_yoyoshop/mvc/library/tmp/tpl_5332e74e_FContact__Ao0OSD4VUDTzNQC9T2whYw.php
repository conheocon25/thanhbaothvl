<?php 
function tpl_5332e74e_FContact__Ao0OSD4VUDTzNQC9T2whYw(PHPTAL $tpl, PHPTAL_Context $ctx) {
$_thistpl = $tpl ;
$_translator = $tpl->getTranslator() ;
/* tag "documentElement" from line 1 */ ;
$ctx->setDocType('<!DOCTYPE html>',false) ;
?>

<?php /* tag "html" from line 2 */; ?>
<html lang="en">
  <?php /* tag "head" from line 3 */; ?>
<head>
	<?php 
/* tag "div" from line 4 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeMETA', $_thistpl) ;
$ctx->popSlots() ;
?>

	<?php 
/* tag "div" from line 5 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeCSS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </head>
  <?php /* tag "body" from line 7 */; ?>
<body>
	<?php 
/* tag "div" from line 8 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Header', $_thistpl) ;
$ctx->popSlots() ;
?>
    
    <?php /* tag "div" from line 9 */; ?>
<div class="container">
        <?php 
/* tag "div" from line 10 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/PageTitle', $_thistpl) ;
$ctx->popSlots() ;
?>

        <?php 
/* tag "div" from line 11 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Menu', $_thistpl) ;
$ctx->popSlots() ;
?>

		<?php /* tag "div" from line 12 */; ?>
<div class="row-fluid">
			<?php /* tag "div" from line 13 */; ?>
<div class="span3">
				<?php /* tag "div" from line 14 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 15 */; ?>
<div class="span12">
						<?php /* tag "h2" from line 16 */; ?>
<h2>Địa chỉ liên lạc</h2>
						<?php /* tag "address" from line 17 */; ?>
<address>
							Trường Chinh<?php /* tag "br" from line 18 */; ?>
<br/>
							Q.Tân Bình<?php /* tag "br" from line 19 */; ?>
<br/>
							TP HCM.<?php /* tag "br" from line 20 */; ?>
<br/>
							info@yoyoshop.com<?php /* tag "br" from line 21 */; ?>
<br/>
							0803 111 333<?php /* tag "br" from line 22 */; ?>
<br/>
							<?php /* tag "abbr" from line 23 */; ?>
<abbr title="Phone">Di động:</abbr> 0919 11 22 33<?php /* tag "br" from line 23 */; ?>
<br/>
						</address>
						<?php /* tag "h2" from line 25 */; ?>
<h2>Chăm sóc KH</h2>
						<?php /* tag "address" from line 26 */; ?>
<address>
							<?php /* tag "strong" from line 27 */; ?>
<strong>Nguyễn Thị A</strong><?php /* tag "br" from line 27 */; ?>
<br/>
							0919 123 456<?php /* tag "br" from line 28 */; ?>
<br/>
							<?php /* tag "a" from line 29 */; ?>
<a href="mailto:#">nguyenthia@yoyoshop.com</a>
						</address>
						<?php /* tag "address" from line 31 */; ?>
<address>
							<?php /* tag "strong" from line 32 */; ?>
<strong>Trần Văn B</strong><?php /* tag "br" from line 32 */; ?>
<br/>
							0919 111 222<?php /* tag "br" from line 33 */; ?>
<br/>
							<?php /* tag "a" from line 34 */; ?>
<a href="mailto:#">tranvanb@yoyoshop.com</a>
						</address>
					</div>
				</div>
			</div>
			<?php /* tag "div" from line 39 */; ?>
<div class="span9">
				<?php /* tag "div" from line 40 */; ?>
<div class="row-fluid">
					<?php /* tag "ul" from line 41 */; ?>
<ul class="breadcrumb">
						<?php /* tag "li" from line 42 */; ?>
<li><?php /* tag "a" from line 42 */; ?>
<a href="#">Trang chủ</a> <?php /* tag "span" from line 42 */; ?>
<span class="divider">/</span></li>
						<?php /* tag "li" from line 43 */; ?>
<li class="active">Liên hệ</li>
					</ul>
				</div>
				<?php /* tag "div" from line 46 */; ?>
<div class="row-fluid">
					<?php /* tag "div" from line 47 */; ?>
<div class="span12">
						<?php /* tag "div" from line 48 */; ?>
<div class="page-header">
							<?php /* tag "h1" from line 49 */; ?>
<h1>Liên lạc nhanh với chúng tôi <?php /* tag "small" from line 49 */; ?>
<small>sẽ được mức giá ưu đãi</small></h1>
						</div>

						<?php /* tag "iframe" from line 52 */; ?>
<iframe width="100%" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=vi&amp;geocode=&amp;q=V%C4%A9nh+Long,+Vi%E1%BB%87t+Nam&amp;aq=0&amp;oq=V%C4%A9nh+Long&amp;sll=37.0625,-95.677068&amp;sspn=37.683309,86.572266&amp;t=m&amp;ie=UTF8&amp;hq=&amp;hnear=V%C4%A9nh+Long,+Vi%E1%BB%87t+Nam&amp;z=13&amp;ll=10.244844,105.958865&amp;output=embed"></iframe>						
						<?php /* tag "p" from line 53 */; ?>
<p>Mọi thắc mắc giao dịch trên hệ thống bạn có thể liên lạc trực tiếp qua điện thoại hoặc qua
						tin nhắn trực tiếp.</p>						
						<?php /* tag "form" from line 55 */; ?>
<form>
							<?php /* tag "label" from line 56 */; ?>
<label class="control-label">Tên</label>
							<?php /* tag "input" from line 57 */; ?>
<input type="text" class="input-xxlarge" required="true"/>
							<?php /* tag "label" from line 58 */; ?>
<label class="control-label">Email</label>
							<?php /* tag "input" from line 59 */; ?>
<input type="text" class="input-xxlarge" required="true"/>
							<?php /* tag "label" from line 60 */; ?>
<label class="control-label">Chủ đề</label>
							<?php /* tag "input" from line 61 */; ?>
<input type="text" class="input-xxlarge" required="true"/>
							<?php /* tag "label" from line 62 */; ?>
<label class="control-label">Nội dung</label>
							<?php /* tag "textarea" from line 63 */; ?>
<textarea class="input-xxlarge" rows="5" style="resize: none;" required="true"></textarea><?php /* tag "br" from line 63 */; ?>
<br/>
							<?php /* tag "input" from line 64 */; ?>
<input type="submit" name="submit" value="Gửi đi" class="btn"/>
						</form>
					</div>
				</div>
			</div>
		</div>	  
		<?php 
/* tag "div" from line 70 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/Footer', $_thistpl) ;
$ctx->popSlots() ;
?>

		</div> <!-- /container -->
	<?php 
/* tag "div" from line 72 */ ;
$ctx->pushSlots() ;
$tpl->_executeMacroOfTemplate('mFront.xhtml/IncludeJS', $_thistpl) ;
$ctx->popSlots() ;
?>

  </body>
</html><?php 
/* end */ ;

}

?>
<?php /* 
*** DO NOT EDIT THIS FILE ***

Generated by PHPTAL from /home2/tuanbt/public_html/qlcuahang_yoyoshop/mvc/templates/FContact.html (edit that file instead) */; ?>